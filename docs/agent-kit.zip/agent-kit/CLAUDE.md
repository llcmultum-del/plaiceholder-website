# Agent Kit (PlAIceholder): instructions for Claude Code

This folder builds, delivers and maintains preset AI agents for small and mid-size clients.
The person running it is the agent builder, not a full-time developer. Speak plainly and
never show code unless asked.

## Layout
- `kit.py`: the only command anyone needs. `python kit.py --help`.
- `core/`: shared plumbing (connectors, AI platforms, approvals, checks, scoring, dashboard,
  builder, portable export). Agents never call APIs directly.
- `agents/<name>/`: shared templates. Each one has `agent.yaml`, `settings.yaml`, `prompts/`, `steps.py`,
  `portable.md.j2` (the chat-mode spec), `interview.md` and `sample_data/`.
- `clients/<client>/`: one folder per client. It holds `client.yaml` (tools, AI platform, care plan, delivery
  history), `.env` (keys, never read aloud), `agents/<agent>.yaml` (tuned settings), `pinned/<agent>/`
  (that client's private copy of the template), and `runs/`.
- `deliveries/<client>/<agent>/vN/`: immutable, versioned deliveries plus a zip. Never edit them; build a new version.
- `docs/`: SOPs, legal templates, policies, brand guide and business documents.
- `tests/run_tests.py`: end-to-end tests. Run after any code change.

## The worker (start here for any new build)
"Build <agent> for <company>" means: follow `docs/builder/BUILDER.md` (the formula). Inputs live in a request file
(`requests/_TEMPLATE.yaml`): agent (catalog or custom), company info, connections, AI platform. Run
`/build <request.yaml or a sentence>` → `python kit.py build-request <file>`. `python kit.py intake <agent>` lists what to
collect. Custom agents with no template: `python kit.py new-template <slug> --from <closest>`, then BUILDER.md part C.

## Rules
1. **One client at a time.** Every client request names a client. Only change `clients/<that client>/`
   and `deliveries/<that client>/`. Never edit `agents/` (shared) for a single client's request; change that
   client's settings, or as a last resort its `pinned/` copy.
2. **Deliveries are immutable.** Changes mean `python kit.py build <client> <agent> --note "..."`, which makes vN+1.
3. **Template upgrades are per client and opt-in:** `python kit.py upgrade <client> <agent>` shows the changes;
   `--apply` only after the person agrees. Then build.
4. **Keys never enter the chat.** Ask the person to run `! python kit.py set-key <client> <KEY>` themselves.
   Never print `.env`.
5. **Every paid or writing step needs a yes from the person.** On `NEEDS APPROVAL [step]`, explain, wait, then
   `--resume --approve <step>`. Never `--yes` on a live client unless told "approve everything for this run".
6. **Pilot first** (`--limit 20`). **No made-up facts:** keep each agent's checks.
7. Exit codes from `kit.py run`: 0 done, 2 failed (read log.jsonl), 3 needs approval, 4 batch still running.

## Commands (also as slash commands)
`/build` (the worker: request → tested delivery) · `/agent-build` (build + test + package) · `/agent-edit` (change one client, new version) · `/agent-setup` ·
`/agent-tune` · `/agent-run` · `/agent-status` · `/agent-new` (new template for a custom agent)
Plus `python kit.py clients | diff | upgrade | care`.

## AI platforms
Runtime providers: anthropic (Claude, default, batch half price), openai (ChatGPT), perplexity, xai (Grok),
gemini (no web search: refuses research agents). Copilot = chat files only. Model names change: confirm on the
provider's site and set `llm.model` in client.yaml.
