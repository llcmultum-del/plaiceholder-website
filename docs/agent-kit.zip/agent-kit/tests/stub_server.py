"""A stand-in for HubSpot, Salesforce, Apollo, Zendesk, Slack, QuickBooks and the Anthropic API.

It speaks the same URLs and JSON shapes the connectors use, so the real connector
code (not the fakes) is exercised end to end. It proves the code is consistent with
the documented APIs; it does NOT prove the live services behave identically.
Run a live trial-account test before the first client.
"""
from __future__ import annotations

import json
import re
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlsplit

STATE = {}


def reset():
    base = STATE.get("base")
    STATE.clear()
    if base:
        STATE["base"] = base
    STATE.update({
        "hs_groups": set(), "hs_props": {"companies": {"name", "domain", "renewal_date", "annual_value", "account_owner"},
                                         "contacts": {"email", "firstname", "lastname", "jobtitle"}},
        "hs": {"companies": {}, "contacts": {}, "notes": {}, "tickets": {}}, "hs_assoc": [], "hs_next": 100,
        "slack": [], "batches": {}, "calls": [], "throttle_once": {"/crm/v3/objects/companies/search"},
        "sf": {"Account": {}, "Contact": {}, "Task": {}, "Case": {}}, "sf_fields": {"Account": set(), "Contact": set()},
        "sf_next": 1,
    })


reset()


def _nid(prefix=""):
    STATE["hs_next"] += 1
    return f"{prefix}{STATE['hs_next']}"


def seed_hubspot(companies=(), tickets=(), notes=()):
    for c in companies:
        STATE["hs"]["companies"][c["id"]] = {"id": c["id"], "properties": {k: v for k, v in c.items() if k != "id"}}
    for t in tickets:
        STATE["hs"]["tickets"][t["id"]] = {"id": t["id"], "properties": t["properties"]}
        STATE["hs_assoc"].append(("companies", t["company"], "tickets", t["id"]))
    for n in notes:
        STATE["hs"]["notes"][n["id"]] = {"id": n["id"], "properties": n["properties"]}
        STATE["hs_assoc"].append(("companies", n["company"], "notes", n["id"]))


# ------------------------------------------------------------ fake Claude
def claude_answer(prompt: str) -> dict:
    m = re.search(r"Website: (\S+)", prompt)
    if m:  # prospector research
        dom = m.group(1)
        real = f"https://news.example/{dom}/deal"
        body = {"company": dom, "summary": f"{dom} was acquired.", "reasoning": "Change event.", "buyer_role": "COO",
                "signals": [{"type": "acquisition", "summary": "Acquired by a PE firm.", "source_url": real,
                             "date": "2026-10-01", "confidence": "high"},
                            {"type": "funding", "summary": "Invented.", "source_url": "https://invented.example/x",
                             "date": "2026-10-02", "confidence": "high"}]}
        return {"content": [
            {"type": "server_tool_use", "id": "srvtoolu_1", "name": "web_search", "input": {"query": dom}},
            {"type": "web_search_tool_result", "tool_use_id": "srvtoolu_1",
             "content": [{"type": "web_search_result", "url": real, "title": "Deal"}]},
            {"type": "text", "text": "```json\n" + json.dumps(body) + "\n```"}],
            "usage": {"input_tokens": 5000, "output_tokens": 400, "server_tool_use": {"web_search_requests": 2}}}
    m = re.search(r"Exception (E-\d+)", prompt)
    if m:  # invoice review
        body = {"exception_id": m.group(1), "verdict": "likely_fine", "reason": "Same company.", "check": "Tax ID."}
        return {"content": [{"type": "text", "text": json.dumps(body)}], "usage": {"input_tokens": 600, "output_tokens": 80}}
    ids = re.findall(r"\[([TNU]-[\w-]+)\]", prompt)  # renewal assessment
    body = {"risk_level": "high", "summary": "Outages and a competitor.", "next_action": "Call the sponsor.",
            "reasons": [{"category": "product_problem", "reason": "Outage", "evidence_id": ids[0] if ids else "T-0", "weight": "high"},
                        {"category": "competitor", "reason": "Made up", "evidence_id": "T-NOPE", "weight": "high"}],
            "positives": []}
    return {"content": [{"type": "text", "text": json.dumps(body)}], "usage": {"input_tokens": 900, "output_tokens": 150}}


class H(BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def _send(self, code, body=None, ctype="application/json"):
        data = b"" if body is None else (body.encode() if isinstance(body, str) else json.dumps(body).encode())
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(data)))
        if code == 429:
            self.send_header("Retry-After", "0")
        self.end_headers()
        self.wfile.write(data)

    def _body(self):
        n = int(self.headers.get("Content-Length") or 0)
        raw = self.rfile.read(n) if n else b""
        if "x-www-form-urlencoded" in (self.headers.get("Content-Type") or ""):
            return {k: v[0] for k, v in parse_qs(raw.decode()).items()}
        return json.loads(raw) if raw else {}

    def do_GET(self):
        self.route("GET")

    def do_POST(self):
        self.route("POST")

    def do_PATCH(self):
        self.route("PATCH")

    def do_PUT(self):
        self.route("PUT")

    def route(self, method):
        u = urlsplit(self.path)
        p, q = u.path, {k: v[0] for k, v in parse_qs(u.query).items()}
        body = self._body() if method != "GET" else {}
        STATE["calls"].append((method, p))
        if p in STATE["throttle_once"]:
            STATE["throttle_once"].discard(p)
            return self._send(429, {"message": "too fast"})
        for prefix, fn in [("/openai", self.openai), ("/pplx", self.compat), ("/xai", self.compat),
                           ("/gemini", self.compat), ("/hs", self.hubspot), ("/apollo", self.apollo), ("/anthropic", self.anthropic),
                           ("/slack", self.slack), ("/zd", self.zendesk), ("/sf", self.salesforce)]:
            if p.startswith(prefix):
                return fn(method, p[len(prefix):], q, body)
        self._send(404, {"error": "no route"})

    # ---------------- OpenAI Responses API
    def openai(self, m, p, q, b):
        assert p == "/responses", p
        STATE.setdefault("llm_calls", []).append(("openai", b))
        ans = claude_answer(b["input"])
        text = "".join(c.get("text", "") for c in ans["content"] if c["type"] == "text")
        urls = [r["url"] for c in ans["content"] if c["type"] == "web_search_tool_result" for r in c["content"]]
        out = []
        if b.get("tools"):
            out.append({"type": "web_search_call", "id": "ws_1", "status": "completed",
                        "action": {"type": "search", "sources": [{"url": u} for u in urls]}})
        out.append({"type": "message", "role": "assistant", "content": [
            {"type": "output_text", "text": text, "annotations": [{"type": "url_citation", "url": u} for u in urls]}]})
        return self._send(200, {"id": "resp_1", "output": out, "usage": {"input_tokens": 1000, "output_tokens": 200}})

    # ---------------- OpenAI-compatible chat (Perplexity, Grok, Gemini)
    def compat(self, m, p, q, b):
        assert p.endswith("/chat/completions"), p
        who = self.path.split("/")[1]
        STATE.setdefault("llm_calls", []).append((who, b))
        prompt = b["messages"][-1]["content"]
        ans = claude_answer(prompt)
        text = "".join(c.get("text", "") for c in ans["content"] if c["type"] == "text")
        urls = [r["url"] for c in ans["content"] if c["type"] == "web_search_tool_result" for r in c["content"]]
        body = {"id": "c1", "choices": [{"index": 0, "message": {"role": "assistant", "content": text}}],
                "usage": {"prompt_tokens": 900, "completion_tokens": 150}}
        if who == "pplx" and urls:
            body["citations"] = urls
            body["search_results"] = [{"url": u, "title": "x"} for u in urls]
        if who == "xai" and b.get("search_parameters"):
            body["citations"] = urls
        return self._send(200, body)

    # ---------------- HubSpot
    def hubspot(self, m, p, q, b):
        hs = STATE["hs"]
        if m == "GET" and (mm := re.fullmatch(r"/crm/v3/properties/(\w+)/groups/(\w+)", p)):
            return self._send(200 if mm.group(2) in STATE["hs_groups"] else 404, {})
        if m == "POST" and (mm := re.fullmatch(r"/crm/v3/properties/(\w+)/groups", p)):
            STATE["hs_groups"].add(b["name"]); return self._send(201, b)
        if m == "GET" and (mm := re.fullmatch(r"/crm/v3/properties/(\w+)/(\w+)", p)):
            return self._send(200 if mm.group(2) in STATE["hs_props"][mm.group(1)] else 404, {"name": mm.group(2)})
        if m == "POST" and (mm := re.fullmatch(r"/crm/v3/properties/(\w+)", p)):
            assert {"name", "label", "type", "fieldType", "groupName"} <= set(b), b
            STATE["hs_props"][mm.group(1)].add(b["name"]); return self._send(201, b)
        if m == "GET" and p == "/crm/v3/objects/companies":
            return self._send(200, {"results": list(hs["companies"].values())[:1]})
        if m == "POST" and (mm := re.fullmatch(r"/crm/v3/objects/(\w+)/search", p)):
            objs = list(hs[mm.group(1)].values())
            for fg in b.get("filterGroups", []):
                for f in fg["filters"]:
                    if f["operator"] == "EQ":
                        objs = [o for o in objs if str(o["properties"].get(f["propertyName"], "")).lower() == str(f["value"]).lower()]
                    elif f["operator"] == "BETWEEN":
                        from datetime import datetime, timezone
                        lo, hi = int(f["value"]), int(f["highValue"])
                        def ms(v):
                            return int(datetime.fromisoformat(v).replace(tzinfo=timezone.utc).timestamp() * 1000) if v else -1
                        objs = [o for o in objs if lo <= ms(o["properties"].get(f["propertyName"])) <= hi]
            start = int(b.get("after") or 0)
            page = objs[start:start + b.get("limit", 10)]
            res = {"results": page}
            if start + len(page) < len(objs):
                res["paging"] = {"next": {"after": str(start + len(page))}}
            return self._send(200, res)
        if m == "POST" and (mm := re.fullmatch(r"/crm/v3/objects/(\w+)/batch/read", p)):
            return self._send(200, {"results": [hs[mm.group(1)][i["id"]] for i in b["inputs"] if i["id"] in hs[mm.group(1)]]})
        if m == "POST" and (mm := re.fullmatch(r"/crm/v3/objects/(\w+)", p)):
            obj = mm.group(1); oid = _nid()
            unknown = set(b["properties"]) - STATE["hs_props"].get(obj, set(b["properties"]))
            if obj in ("companies", "contacts") and unknown:
                return self._send(400, {"message": f"Property values were not valid: {sorted(unknown)}"})
            hs[obj][oid] = {"id": oid, "properties": b["properties"]}
            for a in b.get("associations", []):
                STATE["hs_assoc"].append(("companies", a["to"]["id"], obj, oid))
            return self._send(201, hs[obj][oid])
        if (mm := re.fullmatch(r"/crm/v3/objects/(\w+)/(\w+)", p)):
            obj, oid = mm.groups()
            if oid not in hs[obj]:
                return self._send(404, {"message": "not found"})
            if m == "PATCH":
                unknown = set(b["properties"]) - STATE["hs_props"][obj]
                if unknown:
                    return self._send(400, {"message": f"Property values were not valid: {sorted(unknown)}"})
                hs[obj][oid]["properties"].update(b["properties"])
            return self._send(200, hs[obj][oid])
        if m == "PUT" and (mm := re.fullmatch(r"/crm/v4/objects/contacts/(\w+)/associations/default/companies/(\w+)", p)):
            STATE["hs_assoc"].append(("contacts", mm.group(1), "companies", mm.group(2))); return self._send(200, {})
        if m == "GET" and (mm := re.fullmatch(r"/crm/v4/objects/companies/(\w+)/associations/(\w+)", p)):
            ids = [t for (f, fid, to, t) in STATE["hs_assoc"] if f == "companies" and fid == mm.group(1) and to == mm.group(2)]
            return self._send(200, {"results": [{"toObjectId": int(i) if i.isdigit() else i} for i in ids]})
        self._send(404, {"error": f"hubspot route {m} {p}"})

    # ---------------- Apollo
    def apollo(self, m, p, q, b):
        if p == "/v1/auth/health":
            return self._send(200, {"is_logged_in": True})
        if p == "/api/v1/mixed_companies/search":
            orgs = [{"id": f"o{i}", "name": f"Target {i}", "primary_domain": f"target{i}.example", "industry": "Software",
                     "estimated_num_employees": 100 + i, "city": "Austin", "country": "United States"} for i in range(1, 8)]
            orgs.append(dict(orgs[0]))  # duplicate to be removed
            per = b.get("per_page", 25); pg = b.get("page", 1)
            return self._send(200, {"organizations": orgs[(pg - 1) * per: pg * per],
                                    "pagination": {"total_pages": (len(orgs) + per - 1) // per}})
        if p == "/api/v1/mixed_people/api_search":
            dom = b["q_organization_domains_list"][0]
            return self._send(200, {"people": [{"id": f"{dom}-p{i}", "first_name": f"Pat{i}", "last_name_obfuscated": "S***",
                                                "title": t} for i, t in enumerate(["CEO", "VP Operations", "Intern"])]})
        if p == "/api/v1/people/match":
            return self._send(200, {"person": {"email": f"{b['id']}@mail.example", "email_status": "verified", "last_name": "Smith"}})
        self._send(404, {})

    # ---------------- Anthropic
    def anthropic(self, m, p, q, b):
        if p == "/v1/messages" and m == "POST":
            ans = claude_answer(b["messages"][0]["content"])
            return self._send(200, {"id": "msg_1", "type": "message", "role": "assistant", **ans})
        if p == "/v1/messages/batches" and m == "POST":
            bid = f"msgbatch_{len(STATE['batches']) + 1}"
            for r in b["requests"]:
                assert re.fullmatch(r"[a-zA-Z0-9_-]{1,64}", r["custom_id"]), r["custom_id"]
                assert r["params"]["model"] and r["params"]["max_tokens"]
            STATE["batches"][bid] = {"requests": b["requests"], "polls": 0}
            return self._send(200, {"id": bid, "processing_status": "in_progress"})
        if (mm := re.fullmatch(r"/v1/messages/batches/(\w+)", p)):
            bt = STATE["batches"][mm.group(1)]
            bt["polls"] += 1
            done = bt["polls"] >= STATE.get("polls_needed", 2)
            return self._send(200, {"id": mm.group(1), "processing_status": "ended" if done else "in_progress",
                                    "request_counts": {"processing": 0 if done else len(bt["requests"])},
                                    "results_url": f"{STATE['base']}/anthropic/v1/messages/batches/{mm.group(1)}/results" if done else None})
        if (mm := re.fullmatch(r"/v1/messages/batches/(\w+)/results", p)):
            lines = []
            for i, r in enumerate(STATE["batches"][mm.group(1)]["requests"]):
                if i == 0 and STATE.get("fail_first"):
                    lines.append({"custom_id": r["custom_id"], "result": {"type": "errored", "error": {"type": "overloaded_error"}}})
                    continue
                ans = claude_answer(r["params"]["messages"][0]["content"])
                lines.append({"custom_id": r["custom_id"], "result": {"type": "succeeded", "message": {"type": "message", **ans}}})
            return self._send(200, "\n".join(json.dumps(x) for x in lines), "application/binary")
        self._send(404, {})

    # ---------------- Slack
    def slack(self, m, p, q, b):
        STATE["slack"].append(b["text"])
        self._send(200, "ok", "text/plain")

    # ---------------- Zendesk
    def zendesk(self, m, p, q, b):
        if p == "/api/v2/users/me.json":
            return self._send(200, {"user": {"email": "admin@client.example"}})
        if p == "/api/v2/search.json" and q["query"].startswith("type:organization"):
            dom = q["query"].split()[-1]
            return self._send(200, {"results": [{"id": 77, "domain_names": [dom]}]})
        if p == "/api/v2/search.json" and q["query"].startswith("type:ticket"):
            assert "organization:77" in q["query"]
            return self._send(200, {"results": [
                {"id": 5001, "subject": "Outage", "description": "Down all day", "status": "open", "priority": "urgent",
                 "created_at": "2026-10-10T10:00:00Z", "updated_at": "2026-10-11T10:00:00Z"}]})
        if p == "/api/v2/organizations/autocomplete.json":
            return self._send(200, {"organizations": []})
        self._send(404, {})

    # ---------------- Salesforce
    def salesforce(self, m, p, q, b):
        sf = STATE["sf"]
        if p == "/services/oauth2/token":
            assert b.get("grant_type") == "client_credentials"
            return self._send(200, {"access_token": "tok", "instance_url": STATE["base"] + "/sf"})
        v = "/services/data/v62.0"
        if not p.startswith(v):
            return self._send(404, {})
        p = p[len(v):]
        if p == "/limits":
            return self._send(200, {"DailyApiRequests": {"Remaining": 14000}})
        if (mm := re.fullmatch(r"/sobjects/(\w+)/describe", p)):
            return self._send(200, {"fields": [{"name": n} for n in ["Id", "Name", "Website"] + sorted(STATE["sf_fields"][mm.group(1)])]})
        if p == "/tooling/sobjects/CustomField":
            obj, fld = b["FullName"].split(".")
            assert fld.endswith("__c") and len(fld) <= 43
            STATE["sf_fields"][obj].add(fld); return self._send(201, {"id": "fld", "success": True})
        if p == "/query":
            soql = q["q"]
            obj = re.search(r"FROM (\w+)", soql).group(1)
            recs = [dict(r) for r in sf[obj].values()]
            if (mm := re.search(r"Website LIKE '%(.+?)%'", soql)):
                recs = [r for r in recs if mm.group(1) in (r.get("Website") or "")]
            if (mm := re.search(r"Email = '(.+?)'", soql)):
                recs = [r for r in recs if r.get("Email") == mm.group(1)]
            if (mm := re.search(r"Id = '(.+?)'", soql)):
                recs = [r for r in recs if r["Id"] == mm.group(1)]
            if (mm := re.search(r"(\w+__c) >= (\S+) AND \w+__c <= (\S+)", soql)):
                recs = [r for r in recs if r.get(mm.group(1)) and mm.group(2) <= r[mm.group(1)] <= mm.group(3)]
            if (mm := re.search(r"WhatId = '(.+?)'", soql)):
                recs = [r for r in recs if r.get("WhatId") == mm.group(1)]
            if (mm := re.search(r"AccountId = '(.+?)'", soql)):
                recs = [r for r in recs if r.get("AccountId") == mm.group(1)]
            return self._send(200, {"records": recs, "done": True})
        if (mm := re.fullmatch(r"/sobjects/(\w+)", p)) and m == "POST":
            obj = mm.group(1)
            bad = [k for k in b if k.endswith("__c") and k not in STATE["sf_fields"].get(obj, set())]
            if bad:
                return self._send(400, [{"errorCode": "INVALID_FIELD", "message": f"No such column {bad}"}])
            STATE["sf_next"] += 1
            rid = f"001SF{STATE['sf_next']:05d}"
            sf[obj][rid] = {"Id": rid, **b}
            return self._send(201, {"id": rid, "success": True})
        if (mm := re.fullmatch(r"/sobjects/(\w+)/(\w+)", p)) and m == "PATCH":
            obj, rid = mm.groups()
            bad = [k for k in b if k.endswith("__c") and k not in STATE["sf_fields"].get(obj, set())]
            if bad:
                return self._send(400, [{"errorCode": "INVALID_FIELD", "message": f"No such column {bad}"}])
            sf[obj][rid].update(b)
            return self._send(204)
        self._send(404, {"error": f"sf route {m} {p}"})


def start(port=0):
    srv = ThreadingHTTPServer(("127.0.0.1", port), H)
    STATE["base"] = f"http://127.0.0.1:{srv.server_address[1]}"
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    return srv, STATE["base"]
