"""Invoice Checker steps. Rules find every exception; Claude only reviews the fuzzy ones."""
from __future__ import annotations

import csv
import json
import re
from datetime import date, timedelta
from pathlib import Path

from core.checks import parse_date, validate
from core.dashboard import render
from core.llm import estimate_cost

HERE = Path(__file__).parent
SUFFIXES = r"\b(inc|llc|ltd|co|corp|corporation|company|the)\b"
VERDICT = {"type": "object", "required": ["exception_id", "verdict", "reason"],
           "properties": {"verdict": {"type": "string", "enum": ["likely_fine", "real_problem", "unclear"]}}}
SEV_ORDER = {"High": 0, "Medium": 1, "Low": 2}


def risk_total(exc) -> float:
    """Dollars at risk, counting each invoice once at its largest exposure (never above its total)."""
    worst = {}
    for e in exc:
        worst[e["invoice_id"]] = min(max(worst.get(e["invoice_id"], 0.0), e["at_risk"]), e["amount"])
    return round(sum(worst.values()), 2)


def norm_vendor(v: str) -> str:
    v = re.sub(r"[^a-z0-9 ]", " ", (v or "").lower())
    return " ".join(re.sub(SUFFIXES, " ", v).split())


def step_pull(ctx):
    acc = ctx.conn("accounting")
    since = (date.today() - timedelta(days=ctx.settings["lookback_days"])).isoformat()
    inv = sorted(acc.list_invoices(since), key=lambda i: (i["date"], i["id"]))
    ctx.data["invoices"] = ctx.records(inv)
    ctx.data["pos"] = acc.list_purchase_orders()
    ctx.data["vendors"] = acc.list_vendors() if ctx.settings.get("check_approved_vendors") else []
    return f"{len(ctx.data['invoices'])} invoices, {len(ctx.data['pos'])} POs, {len(ctx.data['vendors'])} vendors"


def step_match(ctx):
    s, tol = ctx.settings, ctx.settings["tolerances"]
    pos = {p["number"]: p for p in ctx.data["pos"]}
    approved = {norm_vendor(v["vendor"]) for v in ctx.data["vendors"] if v.get("approved")}
    sev = s["severity"]
    exc, seen_num, by_vendor_amt, billed = [], {}, [], {}

    def add(kind, inv, detail, at_risk=0.0, po=None):
        exc.append({"id": f"E-{len(exc) + 1}", "kind": kind, "severity": sev.get(kind, "Medium"),
                    "invoice_id": inv["id"], "invoice_number": inv["number"], "vendor": inv["vendor"],
                    "date": inv["date"], "po_number": inv.get("po_number") or "", "po_id": (po or {}).get("id"),
                    "amount": inv["amount"], "detail": detail, "at_risk": round(at_risk, 2),
                    "reviewable": kind in s["review_types"]})

    for inv in ctx.data["invoices"]:
        nv = norm_vendor(inv["vendor"])
        key = (nv, inv["number"])
        exact_dup = key in seen_num
        if exact_dup:
            add("duplicate", inv, f"Invoice {inv['number']} from {inv['vendor']} was already entered on {seen_num[key]}.",
                inv["amount"])
        else:
            seen_num[key] = inv["date"]
            d0 = parse_date(inv["date"])
            for (v2, amt2, d2, num2) in by_vendor_amt:
                if v2 == nv and abs(amt2 - inv["amount"]) < 0.01 and num2 != inv["number"] \
                        and abs((d0 - d2).days) <= tol["duplicate_window_days"]:
                    add("possible_duplicate", inv, f"Same vendor and same amount (${inv['amount']:,.2f}) as invoice "
                                                   f"{num2} dated {d2}.", inv["amount"])
                    break
            by_vendor_amt.append((nv, inv["amount"], d0, inv["number"]))

        if approved and nv not in approved:
            add("unapproved_vendor", inv, f"{inv['vendor']} is not on the approved vendor list.", inv["amount"])

        po = pos.get(inv.get("po_number") or "")
        if not inv.get("po_number"):
            if inv["amount"] >= s["require_po_over"]:
                add("no_po", inv, f"${inv['amount']:,.2f} invoice has no PO (PO needed at ${s['require_po_over']:,.0f}+).",
                    inv["amount"])
            continue
        if not po:
            add("po_not_found", inv, f"PO {inv['po_number']} doesn't exist in the system.", inv["amount"])
            continue
        if inv["vendor"].strip().lower() != po["vendor"].strip().lower():
            add("vendor_mismatch", inv, f"Invoice vendor '{inv['vendor']}' vs PO vendor '{po['vendor']}'.", 0.0, po)
        po_lines = {l["sku"]: l for l in po["lines"]}
        for ln in inv["lines"]:
            pl = po_lines.get(ln["sku"])
            if not pl:
                add("item_not_on_po", inv, f"Line '{ln['sku']} {ln['description']}' ({ln['qty']:g} x ${ln['unit_price']:,.2f}) "
                                           f"isn't on PO {po['number']}.", ln["qty"] * ln["unit_price"], po)
                continue
            if pl["unit_price"] and ln["unit_price"] > pl["unit_price"] * (1 + tol["price_pct"] / 100):
                pct = (ln["unit_price"] / pl["unit_price"] - 1) * 100
                add("price_over", inv, f"{ln['sku']} billed at ${ln['unit_price']:,.2f} vs PO ${pl['unit_price']:,.2f} "
                                       f"(+{pct:.1f}%).", (ln["unit_price"] - pl["unit_price"]) * ln["qty"], po)
            if exact_dup:
                continue  # don't count a duplicate twice against the PO quantity
            k = (po["number"], ln["sku"])
            before = billed.get(k, 0.0)
            billed[k] = before + ln["qty"]
            limit = pl["qty"] * (1 + tol["qty_pct"] / 100)
            if billed[k] > limit + 1e-9:
                over = billed[k] - max(limit, before)
                add("qty_over", inv, f"{ln['sku']}: {billed[k]:g} billed so far against {pl['qty']:g} ordered on "
                                     f"PO {po['number']}.", over * ln["unit_price"], po)

    ctx.data["exceptions"] = exc
    flagged = {e["invoice_id"] for e in exc}
    ctx.data["clean"] = [i["id"] for i in ctx.data["invoices"] if i["id"] not in flagged]
    ctx.save()
    risk = risk_total(exc)
    return f"{len(exc)} exceptions on {len(flagged)} invoices (${risk:,.2f} at risk); {len(ctx.data['clean'])} clean"


def _fmt_doc(doc):
    if not doc:
        return "(none)"
    lines = "\n".join(f"  - {l['sku']} | {l['description']} | qty {l['qty']:g} | ${l['unit_price']:,.2f}" for l in doc["lines"])
    return f"{doc['vendor']} · {doc['date']} · total ${doc['amount']:,.2f}\n{lines}"


def _task(ctx, e):
    inv = next(i for i in ctx.data["invoices"] if i["id"] == e["invoice_id"])
    po = next((p for p in ctx.data["pos"] if p["id"] == e.get("po_id")), None)
    related = [i for i in ctx.data["invoices"] if norm_vendor(i["vendor"]) == norm_vendor(inv["vendor"]) and i["id"] != inv["id"]]
    prompt = ctx.agent.prompt("review.md").format(
        company=ctx.settings["company_profile"]["company"], exception_id=e["id"], kind=e["kind"], detail=e["detail"],
        invoice_id=inv["number"], invoice=_fmt_doc(inv), po_id=(po or {}).get("number", "n/a"), po=_fmt_doc(po),
        related="\n".join(f"- {i['number']} {i['date']} ${i['amount']:,.2f}" for i in related) or "(none)")
    return {"id": e["id"], "prompt": prompt, "max_tokens": 600, "meta": {"exception": e, "invoice": inv, "po": po}}


def step_review(ctx):
    done = ctx.data.setdefault("reviews", {})
    todo = [e for e in ctx.data["exceptions"] if e["reviewable"] and e["id"] not in done]
    if not todo:
        return "no fuzzy exceptions to review"
    bs = ctx.state.setdefault("review_batch", {})
    if not bs.get("batch_id"):
        ctx.require("review", f"have Claude review {len(todo)} fuzzy exception(s)",
                    len(todo) * ctx.settings["review"]["est_cost_per_exception"])
    out = ctx.llm.run([_task(ctx, e) for e in todo], bs, ctx.log)
    for k, r in out.items():
        if r["ok"]:
            done[k] = r
    ctx.add_cost("review", estimate_cost([r["usage"] for r in out.values() if r["ok"]], ctx.llm.cfg,
                                         ctx.llm.cfg.get("use_batch", True)))
    ctx.state["review_batch"] = {}
    ctx.save()
    return f"{len(done)} reviewed"


def step_verify(ctx):
    by_id = {e["id"]: e for e in ctx.data["exceptions"]}
    kept = dropped = 0
    for eid, r in ctx.data.get("reviews", {}).items():
        j = r.get("json")
        e = by_id.get(eid)
        if not isinstance(j, dict) or validate(j, VERDICT) or j.get("exception_id") != eid or not e or not e["reviewable"]:
            dropped += 1
            continue
        e["ai_verdict"] = j["verdict"]
        e["ai_reason"] = j["reason"]
        e["ai_check"] = j.get("check", "")
        kept += 1
    ctx.save()
    return f"{kept} verdicts kept, {dropped} discarded"


def _status(e):
    return {"likely_fine": "Likely fine, confirm", "real_problem": "Hold payment", "unclear": "Needs a look"}.get(
        e.get("ai_verdict"), "Hold payment" if e["severity"] == "High" else "Needs a look")


def step_report(ctx):
    exc = sorted(ctx.data["exceptions"], key=lambda e: (SEV_ORDER.get(e["severity"], 9), -e["at_risk"]))
    with open(ctx.run.dir / "exceptions.csv", "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["exception", "severity", "status", "type", "invoice", "vendor", "date", "po", "invoice_total",
                    "at_risk", "detail", "ai_verdict", "ai_reason", "check_before_paying"])
        for e in exc:
            w.writerow([e["id"], e["severity"], _status(e), e["kind"], e["invoice_number"], e["vendor"], e["date"],
                        e["po_number"], e["amount"], e["at_risk"], e["detail"], e.get("ai_verdict", ""),
                        e.get("ai_reason", ""), e.get("ai_check", "")])
    names = {"duplicate": "Duplicate", "possible_duplicate": "Possible duplicate", "price_over": "Price over PO",
             "qty_over": "Quantity over PO", "no_po": "No PO", "po_not_found": "PO not found",
             "unapproved_vendor": "Unapproved vendor", "vendor_mismatch": "Vendor name mismatch",
             "item_not_on_po": "Item not on PO"}
    label = lambda k: names.get(k, k.replace("_", " ").capitalize())
    rows = [{"_id": e["id"], "invoice": e["invoice_number"], "vendor": e["vendor"], "type": label(e["kind"]),
             "severity": e["severity"], "status": _status(e), "at_risk": e["at_risk"], "date": e["date"],
             "detail": e["detail"],
             "_detail": [
                 {"heading": "What the rules found", "kind": "text", "text": e["detail"]},
                 {"heading": "Claude's review", "kind": "text",
                  "text": e.get("ai_reason") or "Not sent for review: a hard rule, so a person decides."},
                 {"heading": "Check before paying", "kind": "text", "text": e.get("ai_check") or "Confirm with the vendor or requester."},
                 {"heading": "Invoice", "kind": "kv", "items": {"Number": e["invoice_number"], "Date": e["date"],
                                                               "Total": f"${e['amount']:,.2f}", "PO": e["po_number"] or "none",
                                                               "Exception": e["id"]}},
             ]} for e in exc]
    hold = [e for e in exc if _status(e) == "Hold payment"]
    data = {
        "kpis": [
            {"label": "Invoices checked", "value": len(ctx.data["invoices"])},
            {"label": "Clean, ready to pay", "value": len(ctx.data["clean"])},
            {"label": "Exceptions", "value": len(exc)},
            {"label": "Dollars at risk", "value": f"${risk_total(exc):,.2f}",
             "note": f"${risk_total(hold):,.2f} on invoices to hold"},
            {"label": "Likely fine (confirm)", "value": sum(e.get("ai_verdict") == "likely_fine" for e in exc)},
        ],
        "columns": [{"key": "invoice", "label": "Invoice"}, {"key": "vendor", "label": "Vendor"},
                    {"key": "type", "label": "Problem", "hide_sm": True},
                    {"key": "severity", "label": "Severity", "kind": "badge"},
                    {"key": "status", "label": "Status", "hide_sm": True},
                    {"key": "at_risk", "label": "At risk", "kind": "money"}],
        "filters": [{"key": "severity", "label": "Severity", "options": ["High", "Medium"]},
                    {"key": "status", "label": "Status", "options": ["Hold payment", "Needs a look", "Likely fine, confirm"]},
                    {"key": "type", "label": "Problem", "options": sorted({r["type"] for r in rows})}],
        "badges": {"High": "hot", "Medium": "warm", "Low": "cold"},
        "search_keys": ["invoice", "vendor", "type", "detail"], "sort": {"key": "at_risk", "dir": "desc"}, "rows": rows,
    }
    out = render(HERE, "base.html.j2", ctx.run.dir / "dashboard.html", title="Invoices to check before paying",
                 eyebrow="Invoice Checker", data=data, client=ctx.client.config.get("client", ctx.client.name),
                 subtitle=f"Invoices from the last {ctx.settings['lookback_days']} days matched to purchase orders. "
                          "Nothing was changed in the accounting system.",
                 footer="Rules flag every exception. Claude only reviews fuzzy ones and can't clear them; a person decides what gets paid.")
    latest = ctx.client.runs_dir / f"{ctx.agent.name}-dashboard.html"
    latest.write_text(out.read_text(encoding="utf-8"), encoding="utf-8")
    ctx.data["summary"] = {"exceptions": len(exc), "hold": len(hold), "at_risk": risk_total(exc),
                           "clean": len(ctx.data["clean"]), "invoices": len(ctx.data["invoices"])}
    ctx.save()
    return f"report: {ctx.run.dir / 'exceptions.csv'}; dashboard: {latest}"


def step_notify(ctx):
    n = ctx.settings["notify"]
    sm = ctx.data["summary"]
    worst = [e for e in ctx.data["exceptions"] if SEV_ORDER.get(e["severity"], 9) <= SEV_ORDER[n["min_severity"]]]
    if not worst:
        return "nothing to report"
    ctx.require("notify", f"post an AP summary to Slack ({len(worst)} exception(s))")
    lines = [f"{n.get('mention', '')} *Invoice check: {sm['invoices']} invoices, {sm['clean']} clean, "
             f"{sm['exceptions']} exceptions, ${sm['at_risk']:,.2f} at risk*".strip()]
    for e in sorted(worst, key=lambda e: -e["at_risk"])[:10]:
        lines.append(f"• {_status(e)}: {e['vendor']} #{e['invoice_number']} (${e['at_risk']:,.2f}): {e['detail']}")
    ctx.conn("notify").send("\n".join(lines))
    return f"summary sent ({len(worst)} exceptions)"


def status_summary(state):
    sm = (state.get("data") or {}).get("summary")
    return [f"last result: {sm['exceptions']} exceptions, ${sm['at_risk']:,.2f} at risk, {sm['clean']} clean"] if sm else []


def test_prompt(ctx, record):
    step_pull(ctx)
    step_match(ctx)
    hits = [e for e in ctx.data["exceptions"] if e["invoice_number"] == record and e["reviewable"]]
    if not hits:
        return {"error": f"No reviewable exception on invoice {record}"}
    r = ctx.llm.run([_task(ctx, hits[0])], {}, ctx.log)[hits[0]["id"]]
    return {"exception": hits[0], "answer": r.get("json") or r.get("text"), "error": r.get("error")}


# ---------------------------------------------------------------- demo mode
def fake_responder(task):
    e, inv, po = task["meta"]["exception"], task["meta"]["invoice"], task["meta"]["po"]
    if e["kind"] == "vendor_mismatch":
        same = norm_vendor(inv["vendor"]) == norm_vendor((po or {}).get("vendor", ""))
        v = ("likely_fine", f"'{inv['vendor']}' and '{po['vendor']}' are the same company written two ways.",
             "Vendor's tax ID or remit-to address matches the vendor record.") if same else \
            ("real_problem", "The invoice comes from a different company than the one on the PO.",
             "Who approved buying from this vendor.")
    elif e["kind"] == "item_not_on_po":
        sku = e["detail"].split("'")[1].split()[0]
        close = [l for l in (po or {}).get("lines", []) if re.sub(r"[^A-Z0-9]", "", l["sku"]) == re.sub(r"[^A-Z0-9]", "", sku)]
        v = ("likely_fine", f"'{sku}' matches PO line {close[0]['sku']} with the same price and quantity; looks like a SKU typo.",
             "Quantity received matches the PO line.") if close else \
            ("real_problem", "This item was never ordered on the PO.", "Who requested it, and whether it was received.")
    else:  # possible_duplicate
        v = ("unclear", "Same vendor, same amount, four days apart. Could be a standing reorder or a double bill.",
             "Whether two separate deliveries were received.")
    return "```json\n" + json.dumps({"exception_id": e["id"], "verdict": v[0], "reason": v[1], "check": v[2]}) + "\n```", []
