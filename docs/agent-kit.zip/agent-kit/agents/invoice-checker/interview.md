# Invoice Checker tuning interview

Run with the AP lead or controller (about 30 minutes). Write answers to
`clients/<client>/agents/invoice-checker.yaml` (only what differs from defaults).

## 1. Data → client.yaml `connectors.accounting` and `connector_settings.csv`
- Which system holds bills and POs? QuickBooks Online (beta connector) or anything that
  exports CSV (NetSuite, Xero, Sage, Bill.com, Excel...).
- Get one export of each: invoice lines, PO lines, approved vendors. Map their column
  headers in `connector_settings.csv.columns` if they differ.
- How often will they export? (Weekly before the payment run is typical.)

## 2. Rules → `tolerances`, `require_po_over`, `check_approved_vendors`
- How much over the PO price do you accept before asking? (%) → `price_pct`
- Can a vendor bill more units than ordered? By how much? → `qty_pct`
- Which invoices need a PO at all? (dollar threshold) → `require_po_over`
- Is there an approved vendor list? → `check_approved_vendors`
- How close together do two same-amount bills have to be to look like a double bill? → `duplicate_window_days`

## 3. What Claude may review → `review_types`
- Default: vendor name differences, items not on the PO, possible duplicates.
- Hard rules (exact duplicates, overbilling, unapproved vendor) always go to a person.

## 4. Severity and alerts → `severity`, `notify`
- Which problems mean "hold payment" (High) vs "take a look" (Medium)?
- Which Slack channel, and what's the minimum severity to post? → `min_severity`, `mention`

## 5. Calibrate
- Run on last month's invoices. Walk through every exception with the AP lead:
  real problem, or noise? Loosen tolerances that only produce noise.
- Record the result: invoices checked, exceptions, real problems found, dollars caught.
  That number is the case study.
