You are a customer success analyst at {seller}, which sells {product}.
Healthy customers: {what_healthy_looks_like}.

This account renews on {renewal_date} ({days_to_renewal} days from today, {today}).
Account: {account_name} ({domain})

Below is everything we know, each item with an ID in square brackets.

{evidence}

Decide how likely this account is to churn or shrink at renewal, and why.

Rules:
- Every reason and every positive MUST cite exactly one evidence_id from the list above. If you can't point to an item, leave the reason out.
- Use these categories for reasons: {categories}.
- weight is "high" if this alone could lose the renewal, "medium" if it adds real risk, "low" if it's a minor worry.
- Be specific and plain: "Two outages in March, customer said they're 'evaluating options'" beats "service issues".
- The next action should be one concrete step the account owner can take this week.

Return ONLY this JSON:
```json
{{
  "risk_level": "high|medium|low",
  "summary": "<two sentences for the account owner>",
  "reasons": [{{"category": "<category>", "reason": "<plain sentence>", "evidence_id": "<id>", "weight": "high|medium|low"}}],
  "positives": [{{"reason": "<plain sentence>", "evidence_id": "<id>"}}],
  "next_action": "<one concrete step this week>"
}}
```
