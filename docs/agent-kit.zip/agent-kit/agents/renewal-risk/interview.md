# Renewal Risk Radar tuning interview

Run with the head of customer success and one CSM (about 40 minutes). Write answers
to `clients/<client>/agents/renewal-risk.yaml` (only what differs from defaults).

## 1. The business → `company_profile`
- What do you sell, in a sentence? → `seller`, `product`
- What does a healthy customer look like, in their behavior? → `what_healthy_looks_like`

## 2. Where renewal data lives → `renewal`
- Which CRM field holds the renewal date? (Open a customer record together and find it.) → `date_field`
  - HubSpot: the property's internal name. Salesforce: write it in snake_case;
    `renewal_date` maps to `Renewal_Date__c`. If it's a standard field, note it and ask for help mapping.
- Contract value field? Account owner field? → `value_field`, `owner_field`
- How far ahead do you start working a renewal? → `window_days`

## 3. Evidence → `evidence`
- Which help desk? Are tickets linked to companies/organizations? (Check one together.)
- How far back do tickets matter? → `ticket_days`
- Can you export product usage monthly? (domain, active users last 30 days, previous 30) → `usage_file`

## 4. What actually predicts churn → `scoring.points`, `scoring.rules`
- Think of the last 3 customers who left. What did you see 2 to 3 months before?
- Rank these: product problems, support experience, competitor interest, budget, champion
  leaving, low usage, unhappy tone. Most predictive gets the most points.
- How many urgent tickets is "too many"? What usage drop worries you? How long without
  contact is a red flag?

## 5. Levels and alerts → `scoring.levels`, `alerts`
- What should High mean in practice? (e.g. "VP calls this week")
- Who gets the Slack alert, and should it mention a group? → `mention`
- Should the agent add a note to the CRM each run? → `write_note`

## 6. Calibrate
- Pick 3 accounts that churned and 3 that renewed happily (ideally still inside the window,
  or temporarily widen it). Run `python kit.py test-prompt <client> renewal-risk <account id>`
  on each and compare to what the team expected. Adjust points until the order matches.
