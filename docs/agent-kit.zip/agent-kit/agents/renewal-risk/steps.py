"""Renewal Risk Radar steps."""
from __future__ import annotations

import csv
import json
from datetime import date, timedelta
from pathlib import Path

from core.checks import days_ago, norm_domain, parse_date, validate, verify_evidence
from core.dashboard import render
from core.llm import estimate_cost
from core.scoring import tier

HERE = Path(__file__).parent

SCHEMA = {
    "type": "object", "required": ["summary", "reasons", "next_action"],
    "properties": {
        "risk_level": {"type": "string"}, "summary": {"type": "string"}, "next_action": {"type": "string"},
        "reasons": {"type": "array", "items": {"type": "object", "required": ["category", "reason", "evidence_id"],
                                               "properties": {"weight": {"type": "string", "enum": ["high", "medium", "low"]}}}},
        "positives": {"type": "array", "items": {"type": "object", "required": ["reason", "evidence_id"]}},
    },
}
CLOSED = {"solved", "closed", "resolved", "4", "closed won"}


def _accounts(ctx):
    return ctx.data.setdefault("accounts", [])


def step_fields(ctx):
    fields = ctx.agent.manifest["crm_fields"]["company"]
    if not ctx.approve("fields", f"add up to {len(fields)} AI risk fields to CRM companies"):
        return "skipped (dry run)"
    created = ctx.conn("crm").ensure_fields("company", fields)
    return f"{len(created)} fields created, {len(fields) - len(created)} already there"


def step_pull(ctx):
    r = ctx.settings["renewal"]
    today = date.today()
    extra = [f for f in (r.get("value_field"), r.get("owner_field")) if f]
    rows = ctx.conn("crm").list_companies(
        [r["date_field"]] + extra, date_field=r["date_field"],
        date_from=today.isoformat(), date_to=(today + timedelta(days=r["window_days"])).isoformat())
    accts = []
    for c in rows:
        d = parse_date(c.get(r["date_field"]))
        if not d:
            continue
        accts.append({"id": c["id"], "name": c.get("name"), "domain": norm_domain(c.get("domain", "")),
                      "renewal_date": d.isoformat(), "days_to_renewal": (d - today).days,
                      "value": c.get(r.get("value_field") or "", None), "owner": c.get(r.get("owner_field") or "", "")})
    accts.sort(key=lambda a: a["days_to_renewal"])
    ctx.data["accounts"] = ctx.records(accts)
    return f"{len(ctx.data['accounts'])} accounts renew in the next {r['window_days']} days"


def _usage(ctx) -> dict:
    f = ctx.settings["evidence"].get("usage_file")
    path = ctx.client.resolve(f) if f else (HERE / "sample_data" / "usage.csv" if ctx.fake else None)
    if not path or not path.exists():
        return {}
    out = {}
    with open(path, newline="", encoding="utf-8-sig") as fh:
        for row in csv.DictReader(fh):
            try:
                out[norm_domain(row["domain"])] = (float(row["active_users_last_30"]), float(row["active_users_prev_30"]))
            except (KeyError, ValueError):
                continue
    return out


def _eid(prefix, raw):
    raw = str(raw)
    return raw if raw.startswith(prefix + "-") else f"{prefix}-{raw}"


def step_gather(ctx):
    e = ctx.settings["evidence"]
    crm, desk, usage = ctx.conn("crm"), ctx.conn("helpdesk"), _usage(ctx)
    for a in _accounts(ctx):
        items = []
        for t in desk.tickets_for_company(a, e["ticket_days"], e["max_tickets"]):
            items.append({"id": _eid("T", t["id"]), "kind": "ticket", "date": str(t.get("created_at", ""))[:10],
                          "status": t.get("status"), "priority": t.get("priority"),
                          "text": f"\"{t.get('subject', '')}\": {(t.get('description') or '')[:600]}"})
        for n in crm.company_notes(a["id"], e["max_notes"]):
            items.append({"id": _eid("N", n["id"]), "kind": "note", "date": str(n.get("date", ""))[:10],
                          "text": (n.get("body") or "")[:600]})
        if a["domain"] in usage:
            last, prev = usage[a["domain"]]
            pct = round((last - prev) / prev * 100) if prev else 0
            a["usage_change_pct"] = pct
            items.append({"id": "U-1", "kind": "usage", "date": date.today().isoformat(),
                          "text": f"{int(last)} active users in the last 30 days vs {int(prev)} the 30 days before ({pct:+d}%)"})
        a["evidence"] = items
    ctx.save()
    n = sum(len(a["evidence"]) for a in _accounts(ctx))
    return f"{n} pieces of evidence across {len(_accounts(ctx))} accounts"


def _fmt(items):
    lines = []
    for i in items:
        meta = " · ".join(x for x in [i.get("date"), i["kind"], i.get("priority"), i.get("status")] if x)
        lines.append(f"[{i['id']}] ({meta}) {i['text']}")
    return "\n".join(lines) or "(no tickets, notes or usage on file)"


def _task(ctx, a):
    p = ctx.settings["company_profile"]
    prompt = ctx.agent.prompt("assess.md").format(
        seller=p["seller"], product=p["product"], what_healthy_looks_like=p["what_healthy_looks_like"],
        renewal_date=a["renewal_date"], days_to_renewal=a["days_to_renewal"], today=date.today().isoformat(),
        account_name=a["name"], domain=a["domain"], evidence=_fmt(a["evidence"]),
        categories=", ".join(ctx.settings["scoring"]["points"].keys()))
    return {"id": a["id"], "prompt": prompt, "max_tokens": 1500,
            "meta": {"evidence": a["evidence"], "usage_change_pct": a.get("usage_change_pct")}}


def step_assess(ctx):
    res = ctx.data.setdefault("assessments", {})
    todo = [a for a in _accounts(ctx) if a["id"] not in res]
    if not todo:
        return "nothing new to assess"
    bs = ctx.state.setdefault("assess_batch", {})
    if not bs.get("batch_id"):
        ctx.require("assess", f"have Claude assess {len(todo)} accounts",
                    len(todo) * ctx.settings["assess"]["est_cost_per_account"])
    out = ctx.llm.run([_task(ctx, a) for a in todo], bs, ctx.log)
    for k, r in out.items():
        if r["ok"]:
            res[k] = r
    ctx.add_cost("assess", estimate_cost([r["usage"] for r in out.values() if r["ok"]], ctx.llm.cfg,
                                         ctx.llm.cfg.get("use_batch", True)), f"{len(out)} accounts")
    ctx.state["assess_batch"] = {}
    ctx.save()
    bad = [k for k, r in out.items() if not r["ok"]]
    return f"{len(out) - len(bad)} assessed, {len(bad)} failed (rerun to retry)"


def step_verify(ctx):
    cats = set(ctx.settings["scoring"]["points"])
    audit = []
    for a in _accounts(ctx):
        r = ctx.data.get("assessments", {}).get(a["id"])
        j = (r or {}).get("json")
        if not isinstance(j, dict):
            audit.append({"account": a["name"], "problem": "no valid JSON answer"})
            continue
        for e in validate(j, SCHEMA)[:3]:
            audit.append({"account": a["name"], "problem": e})
        ids = {i["id"] for i in a["evidence"]}
        reasons, dropped = verify_evidence([x for x in j.get("reasons", []) if isinstance(x, dict)], ids)
        pos, dropped2 = verify_evidence([x for x in j.get("positives", []) if isinstance(x, dict)], ids)
        for x in reasons:
            if x.get("category") not in cats:
                x["category"] = "unhappy_sentiment"  # unknown labels fall back to the mildest category
        for d in dropped + dropped2:
            audit.append({"account": a["name"], "problem": d["_reason"], "reason": d.get("reason"),
                          "evidence_id": d.get("evidence_id")})
        a["ai"] = {"summary": j.get("summary", ""), "reasons": reasons, "positives": pos,
                   "next_action": j.get("next_action", "")}
    ctx.run.save_json("verify_audit.json", audit)
    ctx.save()
    n = sum(1 for x in audit if "evidence_id" in x)
    return f"{sum('ai' in a for a in _accounts(ctx))} checked, {n} unsupported reasons thrown out"


def _score(ctx, a):
    s = ctx.settings["scoring"]
    rules = s["rules"]
    parts = []
    for r in a["ai"]["reasons"]:
        pts = s["points"].get(r["category"], 0) * s["weight"].get(r.get("weight", "medium"), 0.7)
        parts.append({"why": r["reason"], "points": round(pts, 1), "source": r["evidence_id"]})
    for p in a["ai"]["positives"][:3]:
        parts.append({"why": f"Positive: {p['reason']}", "points": -s["positive_credit"], "source": p["evidence_id"]})
    urgent = [i for i in a["evidence"] if i["kind"] == "ticket" and str(i.get("priority", "")).lower() in ("urgent", "high")
              and str(i.get("status", "")).lower() not in CLOSED]
    if urgent:
        parts.append({"why": f"Rule: {len(urgent)} urgent/high ticket(s) still open",
                      "points": rules["urgent_open_ticket"] * min(len(urgent), 3), "source": urgent[0]["id"]})
    pct = a.get("usage_change_pct")
    if pct is not None and pct <= -rules["usage_drop_pct"]:
        parts.append({"why": f"Rule: usage down {abs(pct)}% month over month", "points": rules["usage_drop_points"], "source": "U-1"})
    notes = [i for i in a["evidence"] if i["kind"] == "note"]
    last = min([days_ago(n["date"]) for n in notes if days_ago(n["date"]) is not None] or [None]) if notes else None
    if last is None or last > rules["no_contact_days"]:
        parts.append({"why": f"Rule: no logged contact in {last if last is not None else 'any'} days",
                      "points": rules["no_contact_points"], "source": ""})
    total = max(0, min(s["cap"], round(sum(p["points"] for p in parts))))
    return total, parts


def step_score(ctx):
    levels = ctx.settings["scoring"]["levels"]
    counts = {}
    for a in _accounts(ctx):
        if "ai" not in a:
            continue
        a["score"], a["parts"] = _score(ctx, a)
        a["level"] = tier(a["score"], levels)
        counts[a["level"]] = counts.get(a["level"], 0) + 1
    ctx.save()
    return f"risk levels: {counts}"


def step_write(ctx):
    todo = [a for a in _accounts(ctx) if "score" in a and not a.get("written")]
    if not todo:
        return "nothing to write"
    ctx.require("write", f"update risk fields on {len(todo)} CRM companies"
                + (" and add a note to each" if ctx.settings.get("write_note") else ""))
    crm = ctx.conn("crm")
    names = [f["name"] for f in ctx.agent.manifest["crm_fields"]["company"]]
    ctx.run.backup("companies_before", [crm.get_company(a["id"], names) for a in todo])
    for a in todo:
        reasons = "\n".join(f"- {p['why']} [{p['source']}]" for p in a["parts"])
        crm.update_company(a["id"], {"ai_risk_score": a["score"], "ai_risk_level": a["level"], "ai_risk_drivers": reasons,
                                     "ai_risk_action": a["ai"]["next_action"], "ai_risk_checked": date.today().isoformat()})
        if ctx.settings.get("write_note"):
            crm.add_note(a["id"], f"Renewal risk: {a['level']} ({a['score']}/100)\n{a['ai']['summary']}\n\n"
                                  f"Reasons:\n{reasons}\n\nSuggested next step: {a['ai']['next_action']}")
        a["written"] = True
        ctx.save()
    return f"{len(todo)} accounts updated"


def step_alert(ctx):
    al = ctx.settings["alerts"]
    hits = [a for a in _accounts(ctx) if a.get("level") in al["levels"] and not a.get("alerted")]
    if not hits:
        return "no accounts at alert level"
    ctx.require("alert", f"post {len(hits)} high-risk account(s) to Slack")
    lines = [f"{al.get('mention', '')} *Renewal risk: {len(hits)} account(s) need attention*".strip()]
    for a in sorted(hits, key=lambda a: -a["score"]):
        val = f" · ${float(a['value']):,.0f}" if a.get("value") else ""
        lines.append(f"• *{a['name']}* ({a['score']}/100, renews in {a['days_to_renewal']} days{val}, owner {a.get('owner') or 'n/a'})\n"
                     f"   {a['ai']['summary']}\n   Next step: {a['ai']['next_action']}")
    ctx.conn("notify").send("\n".join(lines))
    for a in hits:
        a["alerted"] = True
    ctx.save()
    return f"alert sent for {len(hits)} account(s)"


def step_dashboard(ctx):
    rows = []
    for a in _accounts(ctx):
        if "score" not in a:
            continue
        ev = {i["id"]: i for i in a["evidence"]}
        rows.append({
            "_id": a["id"], "name": a["name"], "score": a["score"], "level": a["level"],
            "renews": a["renewal_date"], "days": a["days_to_renewal"],
            "value": float(a["value"]) if a.get("value") not in (None, "") else None, "owner": a.get("owner") or "",
            "summary": a["ai"]["summary"],
            "_detail": [
                {"heading": "Summary", "kind": "text", "text": a["ai"]["summary"]},
                {"heading": "Next step this week", "kind": "text", "text": a["ai"]["next_action"]},
                {"heading": "What drives the score", "kind": "table", "cols": ["Reason", "Points", "Evidence"],
                 "rows": [[p["why"], p["points"], p["source"]] for p in sorted(a["parts"], key=lambda p: -p["points"])]},
                {"heading": "Evidence", "kind": "list", "empty": "Nothing on file",
                 "items": [f"[{i['id']}] {i.get('date', '')} {i['kind']}: {i['text'][:220]}" for i in ev.values()]},
            ]})
    rows.sort(key=lambda r: -r["score"])
    at_risk = [r for r in rows if r["level"] == "High"]
    data = {
        "kpis": [
            {"label": "Renewals reviewed", "value": len(rows)},
            {"label": "High risk", "value": len(at_risk)},
            {"label": "Value at high risk", "value": f"${sum(r['value'] or 0 for r in at_risk):,.0f}"},
            {"label": "Medium risk", "value": sum(r["level"] == "Medium" for r in rows)},
            {"label": "Est. usage cost", "value": f"${sum(c.get('usd', 0) for c in ctx.costs):,.2f}"},
        ],
        "columns": [
            {"key": "name", "label": "Account"}, {"key": "score", "label": "Risk", "kind": "score"},
            {"key": "level", "label": "Level", "kind": "badge"}, {"key": "days", "label": "Days to renewal"},
            {"key": "value", "label": "Annual value", "kind": "money", "hide_sm": True},
            {"key": "owner", "label": "Owner", "kind": "muted", "hide_sm": True},
        ],
        "filters": [{"key": "level", "label": "Level", "options": ["High", "Medium", "Low"]},
                    {"key": "owner", "label": "Owner", "options": sorted({r["owner"] for r in rows if r["owner"]})}],
        "badges": {"High": "hot", "Medium": "warm", "Low": "good"},
        "search_keys": ["name", "summary", "owner"], "sort": {"key": "score", "dir": "desc"}, "rows": rows,
    }
    out = render(HERE, "base.html.j2", ctx.run.dir / "dashboard.html", title="Renewals at risk",
                 eyebrow="Renewal Risk Radar", data=data, client=ctx.client.config.get("client", ctx.client.name),
                 subtitle=f"Every account renewing in the next {ctx.settings['renewal']['window_days']} days. "
                          "Click a row for the reasons, the evidence behind them and a next step.")
    latest = ctx.client.runs_dir / f"{ctx.agent.name}-dashboard.html"
    latest.write_text(out.read_text(encoding="utf-8"), encoding="utf-8")
    return f"dashboard: {latest}"


def test_prompt(ctx, record):
    """Run the assessment live on one account (by CRM id or domain); nothing is written."""
    step_pull(ctx)
    accts = [a for a in _accounts(ctx) if record in (a["id"], a["domain"])]
    if not accts:
        return {"error": f"{record} is not renewing inside the window"}
    ctx.data["accounts"] = accts
    step_gather(ctx)
    r = ctx.llm.run([_task(ctx, accts[0])], {}, ctx.log)[accts[0]["id"]]
    return {"prompt_evidence": accts[0]["evidence"], "answer": r.get("json") or r.get("text"), "error": r.get("error")}


# ---------------------------------------------------------------- demo mode
KEYWORDS = [
    (("outage", "down", "unavailable"), "product_problem", "high", "Repeated outages are disrupting their daily work"),
    (("slow", "performance", "times out"), "product_problem", "medium", "Performance problems are slowing the team down"),
    (("evaluating other", "switch tools", "competitor", "30% off"), "competitor", "high", "They are actively looking at alternatives"),
    (("price went up", "pricing", "budget"), "budget", "medium", "Price and budget are under scrutiny"),
    (("leaving the company", "admin left", "superintendent changed"), "relationship", "high", "Their champion has left or changed"),
    (("frustrated", "escalating", "not acceptable", "no update"), "support_experience", "medium", "Frustration with how issues are being handled"),
]
POSITIVE = [("love", "Users say they love a recent improvement"), ("very happy", "Champion is very happy"),
            ("expanding", "They are expanding and asked about more seats"), ("uses it daily", "The team uses it daily")]


def fake_responder(task):
    ev = task["meta"]["evidence"]
    reasons, positives, used = [], [], set()
    for item in ev:
        low = item["text"].lower()
        for words, cat, wt, text in KEYWORDS:
            if any(w in low for w in words) and (cat, text) not in used:
                used.add((cat, text))
                reasons.append({"category": cat, "reason": text, "evidence_id": item["id"], "weight": wt})
        for w, text in POSITIVE:
            if w in low:
                positives.append({"reason": text, "evidence_id": item["id"]})
    pct = task["meta"].get("usage_change_pct")
    if pct is not None and pct <= -20:
        reasons.append({"category": "low_usage", "reason": f"Active users fell {abs(pct)}% last month", "evidence_id": "U-1", "weight": "high"})
    if task["id"] == "602":  # an unsupported claim the check should remove
        reasons.append({"category": "competitor", "reason": "Mentioned a rival vendor on a call", "evidence_id": "N-999", "weight": "high"})
    lvl = "high" if sum(r["weight"] == "high" for r in reasons) >= 2 else ("medium" if reasons else "low")
    top = reasons[0]["reason"].lower() if reasons else "no warning signs"
    summary = (f"Risk looks {lvl}: {top}." + (f" {len(reasons) - 1} other concern(s) on file." if len(reasons) > 1 else "")
               + (" Some good signs too." if positives else ""))
    action = {"high": "Book a call with the decision maker this week with a written fix plan and timeline.",
              "medium": "Have the owner check in with the champion and confirm renewal plans and budget.",
              "low": "Send a short value recap and ask about expansion."}[lvl]
    return "```json\n" + json.dumps({"risk_level": lvl, "summary": summary, "reasons": reasons,
                                     "positives": positives, "next_action": action}, indent=1) + "\n```", []
