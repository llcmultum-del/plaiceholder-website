# Signal Prospector tuning interview

Run with the sales leader and one or two reps (about 45 minutes). Ask one section at
a time, in plain words. Write answers to `clients/<client>/agents/signal-prospector.yaml`
(only what differs from the defaults). Read back each section before moving on.

## 1. Who they are → `company_profile`
- In one sentence, what do you sell, and to whom? → `seller`, `offer`
- Describe your best customer: size, industry, location, who signs. → `ideal_customer`
- Why do companies buy *right now* rather than next year? → `why_signals_matter`

## 2. Buying signals → `signals`
- Think of your last 5 deals. What was happening at that company when they called you?
- Which events make a company need you right away? (acquisitions, funding, new leader,
  audits, expansion, trouble, new regulation...)
- For each: how strong is it, 1 to 10? → `points` (multiply by 3; cap ~30)
- Any event that means "not now"? (Leave it out, or add with low points and note it.)
- Write each as `{type, points, label, look_for}`. `type` is a short snake_case name.

## 3. Who to target → `source`, `apollo_filters`, `max_companies`
- Employee range, countries/states, industries or keywords? → Apollo filters
- Or do they already have a target list? → `source: list`, `list_file`
- How many companies per month can the team actually work? → `max_companies`

## 4. Who to call → `contacts`
- Which job titles own the problem? In order of preference. → `titles`
- How many people per company? → `per_company`
- Apollo credits per month you're OK spending? → `credit_cap`
- Which tiers get contacts? → `for_tiers`

## 5. Keep out → `do_not_contact`
- Export of current customers, open deals, competitors and partners (domains). → `file`
- Should companies already in the CRM be rescored? → `existing_companies`
  (`rescore_ours` default, `skip`, or `rescore_all`)

## 6. Talk tracks → `battlecards`
- For each signal: what's the first thing a rep should say? One or two sentences.

## 7. Scoring check
- Show three past deals and three non-deals; ask what score each *should* get.
- Adjust `tiers` so Hot = "call this week", Warm = "sequence", Cold = "recheck next quarter".

After the interview: `python kit.py check <client>`, then `python kit.py test-prompt <client>
signal-prospector <a past customer's domain>` to see if the research finds what you expect.
