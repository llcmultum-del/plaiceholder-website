"""Agent Kit core: shared plumbing every preset agent uses.

Pull -> Think -> Check -> Write back -> Show and ask.
"""
__version__ = "0.1.0"
