"""The worker: turns one build request (requests/<client>-<agent>.yaml) into a tested delivery.

    python kit.py build-request requests/acme-signal-prospector.yaml

A request says: which agent (catalog slug or custom), the company and what we know about it,
which tools it connects to, and which AI platform it runs on. The worker:
  1. checks the request (required fields, known tools, known AI platform);
  2. for a custom agent with no template yet, writes a spec and stops (Claude Code then
     builds the template by following docs/builder/BUILDER.md, part C);
  3. sets up the client folder (only that client), connection settings and AI platform;
  4. pours the company info and discovery answers into the agent's settings using the
     template's intake.yaml map;
  5. runs the build tests and writes a versioned delivery;
  6. writes BUILD_SUMMARY-vN.md (internal, never zipped): what went in, which defaults were kept,
     and the questions to ask the client before going live.
"""
from __future__ import annotations

import re
import shutil
from datetime import datetime
from pathlib import Path

import yaml

from .config import AGENTS_DIR, CLIENTS_DIR, KIT_ROOT, ConfigError, deep_merge, get_agent, load_yaml, save_yaml
from .builder import AI_ALIASES, PLATFORM_ROLES, IGNORE, build

REQUESTS_DIR = KIT_ROOT / "requests"
PLACEHOLDERS = ["Your Company", "YOUR_", "CHANGE_ME"]
CONN_SETTINGS = {"salesforce_instance_url": ("salesforce", "instance_url"),
                 "zendesk_subdomain": ("zendesk", "subdomain")}
SLUG = re.compile(r"^[a-z0-9][a-z0-9-]{1,40}$")


# ------------------------------------------------------------------ small helpers
def _get(d: dict, dotted: str):
    cur = d
    for part in dotted.split("."):
        if not isinstance(cur, dict) or part not in cur:
            return None
        cur = cur[part]
    return cur


def _set(d: dict, dotted: str, value):
    parts = dotted.split(".")
    cur = d
    for part in parts[:-1]:
        if not isinstance(cur.get(part), dict):
            cur[part] = {}
        cur = cur[part]
    cur[parts[-1]] = value


def _empty(v) -> bool:
    return v is None or (isinstance(v, (str, list, dict)) and len(v) == 0)


def _placeholder(v) -> bool:
    return any(p in str(v) for p in PLACEHOLDERS)


def load_intake(agent_name: str, client_name: str | None = None) -> list[dict]:
    """The intake map, from the client's pinned copy when there is one, else the shared template."""
    for base in ([CLIENTS_DIR / client_name / "pinned" / agent_name] if client_name else []) + [AGENTS_DIR / agent_name]:
        p = base / "intake.yaml"
        if p.exists():
            return load_yaml(p).get("fields") or []
    return []


def intake_questions(agent_name: str) -> str:
    """Printable list of what to collect for one agent (also the schema for a future web form)."""
    ag = get_agent(agent_name)
    fields = load_intake(agent_name)
    lines = [f"{ag.title} (v{ag.manifest.get('version')}): what to collect",
             f"Tools it can use: " + ", ".join(f"{k}: {'/'.join(v)}" for k, v in (ag.manifest.get('needs') or {}).items()),
             f"Needs an AI platform with web search: {'yes' if ag.manifest.get('needs_web_search') else 'no'}", "",
             "Always: agent, client.folder, client.name, connections, ai_platform", ""]
    if not fields:
        lines.append("(no intake.yaml yet: the worker only fills client info; tune the rest with /agent-tune)")
    for f in fields:
        lines.append(f"  {'*' if f.get('live') else ' '} {f['from']:<32} {f.get('ask', '')}")
    lines += ["", "* = needed before going live (the build still works without it; it becomes a question)"]
    return "\n".join(lines)


# ------------------------------------------------------------------ request checks
def load_request(path: str | Path) -> dict:
    p = Path(path)
    if not p.exists() and (REQUESTS_DIR / p).exists():
        p = REQUESTS_DIR / p
    if not p.exists():
        raise ConfigError(f"Request file not found: {path}")
    try:
        req = yaml.safe_load(p.read_text(encoding="utf-8")) or {}
    except yaml.YAMLError as e:
        raise ConfigError(f"Request file is not valid YAML: {e}")
    req["_path"] = str(p)
    return req


def validate_request(req: dict) -> list[str]:
    probs = []
    client = req.get("client") or {}
    agent = (req.get("agent") or "").strip()
    if not agent:
        probs.append("agent is missing (a catalog slug from `python kit.py list`, or custom)")
    folder = str(client.get("folder") or "")
    if not SLUG.match(folder) or folder.startswith("_"):
        probs.append("client.folder must be lowercase letters, numbers and dashes, e.g. acme-corp")
    if _empty(client.get("name")):
        probs.append("client.name is missing")
    conns = req.get("connections") or []
    if not conns:
        probs.append("connections is empty (e.g. [hubspot, apollo])")
    bad = [c for c in conns if str(c).lower() not in PLATFORM_ROLES]
    if bad:
        probs.append(f"unknown connections {bad}; known: {', '.join(sorted(PLATFORM_ROLES))}")
    ai = str(req.get("ai_platform") or "").lower()
    if ai not in AI_ALIASES:
        probs.append(f"ai_platform '{ai}' unknown; known: {', '.join(AI_ALIASES)}")
    if agent == "custom":
        c = req.get("custom") or {}
        if not SLUG.match(str(c.get("slug") or "")):
            probs.append("custom.slug is missing or not lowercase-with-dashes")
        if _empty(c.get("job")):
            probs.append("custom.job is missing (what slow task does it take over?)")
    elif agent and not (AGENTS_DIR / agent).exists():
        probs.append(f"'{agent}' is not in the catalog; use agent: custom with a custom: block")
    return probs


# ------------------------------------------------------------------ custom agents
def write_spec(req: dict) -> Path:
    """A custom agent with no template yet: write the spec Claude Code builds from."""
    c = req.get("custom") or {}
    cl = req.get("client") or {}
    closest = c.get("closest_template") or _guess_closest(c)
    p = REQUESTS_DIR / f"{cl.get('folder')}-{c.get('slug')}.spec.md"
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(
        f"# Spec: {c.get('name') or c.get('slug')} (custom agent for {cl.get('name')})\n\n"
        f"Status: **template not built yet**. Follow docs/builder/BUILDER.md part C, then run\n"
        f"`python kit.py build-request {req['_path']}` again.\n\n"
        f"- Slug: `{c.get('slug')}`\n- Start from: `{closest}`\n"
        f"  (`python kit.py new-template {c.get('slug')} --from {closest} --title \"{c.get('name') or c.get('slug')}\"`)\n"
        f"- The job: {c.get('job')}\n- Reads from: {', '.join(c.get('reads_from') or []) or '(ask)'}\n"
        f"- Writes to: {', '.join(c.get('writes_to') or []) or '(ask)'}\n"
        f"- A person approves: {c.get('people_approve') or '(ask; default: every paid or writing step)'}\n"
        f"- A wrong answer looks like: {c.get('wrong_answer') or '(ask; this drives the checks)'}\n"
        f"- Client connections: {', '.join(req.get('connections') or [])} · AI platform: {req.get('ai_platform')}\n\n"
        "## Pattern to fill in\n| Part | This agent |\n|---|---|\n| Pull | |\n| Think | |\n| Check | |\n"
        "| Write back | |\n| Show and ask | |\n", encoding="utf-8")
    return p


def _guess_closest(c: dict) -> str:
    text = " ".join(str(v) for v in c.values()).lower()
    if any(w in text for w in ("invoice", "bill", "payable", "expense", "po ", "purchase order", "reconcil", "csv", "quickbooks")):
        return "invoice-checker"
    if any(w in text for w in ("renewal", "churn", "ticket", "support", "health", "account", "customer success")):
        return "renewal-risk"
    return "signal-prospector"


def new_template(slug: str, base: str, title: str | None = None, area: str | None = None,
                 tier: str | None = None) -> Path:
    if not SLUG.match(slug):
        raise ConfigError("Template name must be lowercase letters, numbers and dashes")
    src, dest = AGENTS_DIR / base, AGENTS_DIR / slug
    if not src.exists():
        raise ConfigError(f"No template '{base}' to start from")
    if dest.exists():
        raise ConfigError(f"agents/{slug} already exists")
    shutil.copytree(src, dest, ignore=IGNORE)
    man_path = dest / "agent.yaml"
    text = man_path.read_text(encoding="utf-8")
    man = yaml.safe_load(text)
    man["title"] = title or slug.replace("-", " ").title()
    if area:
        man["area"] = area
    if tier:
        man["tier"] = tier
    man["version"] = "0.1.0"
    man["summary"] = f"DRAFT copied from {base}. Rewrite: what it does, in two or three plain sentences."
    man["based_on"] = base
    save_yaml(man_path, man)
    (dest / "TODO.md").write_text(
        f"# Building {man['title']} (draft, copied from {base})\n\n"
        "Follow docs/builder/BUILDER.md part C. Tick each line.\n\n"
        "- [ ] agent.yaml: summary, needs, needs_web_search, pattern, steps (read/local/spend/write)\n"
        "- [ ] settings.yaml: generic defaults with 'Your Company' placeholders\n"
        "- [ ] prompts/: the AI step(s), evidence-tied JSON output\n"
        "- [ ] steps.py: one function per step; ctx.require() before every spend/write; backups before writes;\n"
        "      checks that throw out anything not tied to real evidence; fake_responder; status_summary\n"
        "- [ ] sample_data/world.json (and news.json if it researches): realistic fake records incl. bad cases\n"
        "- [ ] intake.yaml: every client fact and tuning answer mapped to a setting; mark live: true ones\n"
        "- [ ] interview.md: the discovery questions\n"
        "- [ ] portable.md.j2: Your role, What you work on, Procedure, Rules, Scoring, Output format, Stop and ask\n"
        f"- [ ] `python kit.py demo {slug}` runs clean; dashboard looks right\n"
        "- [ ] a test in tests/run_tests.py; all tests pass\n"
        "- [ ] docs/CATALOG.md entry\n"
        "- [ ] set version: 1.0.0 in agent.yaml (the builder refuses to deliver 0.x)\n", encoding="utf-8")
    return dest


# ------------------------------------------------------------------ the worker
def build_from_request(path: str | Path, force: bool = False, out=print) -> dict:
    """Returns {'status': 'delivered'|'blocked'|'needs_template'|'invalid', ...}."""
    req = load_request(path)
    probs = validate_request(req)
    if probs:
        out("The request needs fixing before anything is built:")
        for p in probs:
            out(f"  - {p}")
        return {"status": "invalid", "problems": probs}

    cl = req["client"]
    folder = cl["folder"]
    agent_name = req["agent"]
    if agent_name == "custom":
        agent_name = req["custom"]["slug"]
        if not (AGENTS_DIR / agent_name).exists():
            spec = write_spec(req)
            out(f"Custom agent '{agent_name}' has no template yet. Spec written to {spec.relative_to(KIT_ROOT)}.")
            out("Next: build the template by following docs/builder/BUILDER.md part C, then run this request again.")
            return {"status": "needs_template", "spec": str(spec)}

    out(f"Request: {get_agent(agent_name).title} for {cl['name']} · tools: {', '.join(req['connections'])} · "
        f"AI: {req['ai_platform']}")

    # 1. client folder, connections, AI platform (builder.prepare_client via build) — but first
    #    write what only the request knows, so the build tests see it.
    from .builder import prepare_client
    client = prepare_client(folder, agent_name, [str(c).lower() for c in req["connections"]],
                            req["ai_platform"], cl["name"], out)
    cfg = load_yaml(client.path / "client.yaml")
    cs = cfg.setdefault("connector_settings", {}) or {}
    for key, (kind, field) in CONN_SETTINGS.items():
        val = (req.get("connection_settings") or {}).get(key)
        if not _empty(val):
            cs.setdefault(kind, {})[field] = val
    cfg["connector_settings"] = cs
    if not _empty(req.get("model")):
        cfg.setdefault("llm", {})["model"] = req["model"]
    cfg["profile"] = {k: cl.get(k) for k in ("website", "industry", "size", "what_they_sell",
                                              "ideal_customer", "contact", "notes") if not _empty(cl.get(k))}
    cfg["modes"] = req.get("modes") or ["chat", "automated"]
    save_yaml(client.path / "client.yaml", cfg)

    # 2. intake map -> client settings (merged over what is already tuned; never wipes earlier answers)
    fields = load_intake(agent_name, folder)
    agent = get_agent(agent_name, client)
    sp = client.agent_settings_path(agent)
    existing = load_yaml(sp)
    poured, filled, kept, questions = {}, [], [], []
    for f in fields:
        val = _get(req, f["from"])
        if not _empty(val):
            _set(poured, f["to"], val)
            filled.append(f)
    merged_overrides = deep_merge(existing, poured)
    header = (f"# Client-specific settings for {agent.title}.\n"
              f"# Only values that differ from pinned/{agent_name}/settings.yaml.\n"
              f"# Last filled from {Path(req['_path']).name} on {datetime.now():%Y-%m-%d}.\n")
    sp.write_text(header + yaml.safe_dump(merged_overrides, sort_keys=False, allow_unicode=True), encoding="utf-8")

    final = deep_merge(agent.default_settings, merged_overrides)
    for f in fields:
        if f in filled:
            continue
        cur = _get(final, f["to"])
        client_set = not _empty(_get(merged_overrides, f["to"])) and not _placeholder(cur)
        # live-required answers must come from the client (now or in an earlier request/tuning),
        # never from a template default, which is only a guess at their setup
        if f.get("live") and not client_set:
            questions.append(f)
        elif _empty(_get(merged_overrides, f["to"])):
            kept.append((f, cur))

    warnings = []
    try:
        from .pipeline import load_steps_module
        fn = getattr(load_steps_module(agent), "intake_warnings", None)
        warnings = fn(final) if fn else []
    except Exception as e:  # a broken check must not stop a build; it shows up in the summary
        warnings = [f"intake_warnings could not run: {e}"]

    # keep a copy of the request with the client (history; the original can be reused or deleted)
    hist = client.path / "requests"
    hist.mkdir(exist_ok=True)
    shutil.copy(req["_path"], hist / f"{datetime.now():%Y%m%d-%H%M%S}-{Path(req['_path']).name}")

    # 3. tests + delivery
    note = req.get("note") or f"Built from request {Path(req['_path']).name}"
    d = build(folder, agent_name, note=note, force=force, out=out)
    if d is None:
        return {"status": "blocked", "questions": [q["ask"] for q in questions]}

    # 4. internal summary, next to the delivery (not inside it: the zip already went out clean)
    summary = d.parent / f"BUILD_SUMMARY-{d.name}.md"
    status = load_yaml(client.path / "client.yaml").get("deliveries", [{}])[-1].get("status", "")

    def show(v):
        s = v if isinstance(v, str) else yaml.safe_dump(v, default_flow_style=True, allow_unicode=True, width=100000).strip()
        return (s[:110] + "…") if len(s) > 110 else s

    lines = [f"# Build summary: {agent.title} for {cl['name']} ({d.name})", "",
             f"**Status: {status}** · built {datetime.now():%Y-%m-%d %H:%M} from `{Path(req['_path']).name}`", "",
             f"- Delivery: `deliveries/{folder}/{agent_name}/{d.name}/` and the zip next to it",
             f"- Tools: {', '.join(req['connections'])} · AI platform: {req['ai_platform']}"
             + (f" · model {req['model']}" if req.get('model') else ""), "",
             "## Filled from the request", ""]
    lines += [f"- {f['ask']} → `{f['to']}`: {show(_get(req, f['from']))}" for f in filled] or ["- (nothing)"]
    lines += ["", "## Questions to ask before going live", ""]
    lines += [f"- [ ] {q['ask']} (`{q['from']}` in the request)" for q in questions] or ["- None. Everything required is filled."]
    if warnings:
        lines += ["", "## Things to look at", ""] + [f"- {w}" for w in warnings]
    lines += ["", "## Defaults kept (fine for a pilot; tune if the client cares)", ""]
    lines += [f"- {f['ask']}: {show(v)}" for f, v in kept] or ["- None."]
    lines += ["", "## Next steps", "",
              "1. Send the zip (or the one platform file the client needs).",
              f"2. Answers to the questions above: add them to the request's `tuning:` and run "
              f"`python kit.py build-request {Path(req['_path']).name}` again (makes the next version)." if questions
              else "2. Book the setup call.",
              f"3. Client keys: they run `python kit.py set-key {folder} <KEY>` (see docs/KEYS.md); never in chat or email.",
              f"4. Pilot: `python kit.py run {folder} {agent_name} --limit 20 --live` with approvals, then review with the client.", ""]
    summary.write_text("\n".join(lines), encoding="utf-8")
    out(f"\nSummary for you (not sent to the client): {summary}")
    for w in warnings:
        out(f"Look at: {w}")
    if questions:
        out("Questions to ask before going live:")
        for q in questions:
            out(f"  - {q['ask']}")
    return {"status": "delivered", "delivery": str(d), "summary": str(summary),
            "questions": [q["ask"] for q in questions], "warnings": warnings, "delivery_status": status}
