"""Rules that catch AI mistakes before anyone sees them."""
from __future__ import annotations

from datetime import date, datetime
from urllib.parse import urlsplit


def norm_url(u: str) -> str:
    if not u:
        return ""
    u = u.strip()
    if "://" not in u:
        u = "https://" + u
    s = urlsplit(u)
    host = s.netloc.lower()
    if host.startswith("www."):
        host = host[4:]
    path = s.path.rstrip("/")
    q = f"?{s.query}" if s.query else ""
    return f"{host}{path}{q}"


def norm_domain(u: str) -> str:
    if not u:
        return ""
    return norm_url(u).split("/")[0].split("?")[0]


def verify_sources(items: list[dict], seen_urls: list[str], url_key: str = "source_url"):
    """Keep only items whose source link appeared in the real search results.

    Returns (kept, dropped). Claude can't invent a news story that survives this.
    """
    seen = {norm_url(u) for u in seen_urls}
    kept, dropped = [], []
    for it in items or []:
        if norm_url(it.get(url_key, "")) in seen:
            kept.append(it)
        else:
            dropped.append({**it, "_reason": "source link not in search results"})
    return kept, dropped


def verify_evidence(items: list[dict], valid_ids: set, id_key: str = "evidence_id"):
    """Keep only items that point at a real ticket/note/record we gave Claude."""
    kept, dropped = [], []
    for it in items or []:
        if str(it.get(id_key)) in valid_ids:
            kept.append(it)
        else:
            dropped.append({**it, "_reason": "evidence id not in provided records"})
    return kept, dropped


_TYPES = {"string": str, "number": (int, float), "integer": int, "array": list,
          "object": dict, "boolean": bool}


def validate(obj, schema: dict, path: str = "$") -> list[str]:
    """Tiny JSON-shape checker. schema = {"type", "required", "properties", "items", "enum"}."""
    errs = []
    t = schema.get("type")
    if t and not isinstance(obj, _TYPES[t]) or (t in ("number", "integer") and isinstance(obj, bool)):
        return [f"{path}: expected {t}, got {type(obj).__name__}"]
    if "enum" in schema and obj not in schema["enum"]:
        errs.append(f"{path}: {obj!r} not one of {schema['enum']}")
    if t == "object":
        for k in schema.get("required", []):
            if k not in obj:
                errs.append(f"{path}.{k}: missing")
        for k, sub in (schema.get("properties") or {}).items():
            if k in obj and obj[k] is not None:
                errs += validate(obj[k], sub, f"{path}.{k}")
    if t == "array" and "items" in schema:
        for i, it in enumerate(obj):
            errs += validate(it, schema["items"], f"{path}[{i}]")
    return errs


def parse_date(s) -> date | None:
    if not s:
        return None
    if isinstance(s, date):
        return s
    for fmt in ("%Y-%m-%d", "%Y-%m-%dT%H:%M:%S", "%Y-%m-%dT%H:%M:%S.%fZ", "%Y-%m-%dT%H:%M:%SZ",
                "%m/%d/%Y", "%Y/%m/%d"):
        try:
            return datetime.strptime(str(s)[:26], fmt).date()
        except ValueError:
            continue
    try:
        return datetime.fromisoformat(str(s).replace("Z", "+00:00")).date()
    except ValueError:
        return None


def days_ago(s, today: date | None = None) -> int | None:
    d = parse_date(s)
    if not d:
        return None
    return ((today or date.today()) - d).days
