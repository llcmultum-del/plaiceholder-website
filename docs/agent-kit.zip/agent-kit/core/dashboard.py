"""Builds a one-file HTML dashboard from a run's results. Opens in any browser,
can be emailed or dropped in a shared drive. No server needed."""
from __future__ import annotations

import json
from datetime import datetime
from pathlib import Path

from jinja2 import Environment, FileSystemLoader, select_autoescape
from markupsafe import Markup

CORE_TEMPLATES = Path(__file__).parent / "templates"


def render(agent_path: Path, template: str, out_path: Path, **ctx) -> Path:
    env = Environment(
        loader=FileSystemLoader([str(agent_path), str(CORE_TEMPLATES)]),
        autoescape=select_autoescape(["html", "j2"]),
    )
    # JSON for a <script> block: escape "<" so no value can close the tag, then mark safe
    env.filters["tojson_safe"] = lambda v: Markup(json.dumps(v, default=str).replace("<", "\\u003c"))
    env.filters["money"] = lambda v: f"${float(v or 0):,.2f}"
    tpl = env.get_template(template)
    ctx.setdefault("generated", datetime.now().strftime("%b %d, %Y %I:%M %p"))
    html = tpl.render(**ctx)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(html, encoding="utf-8")
    return out_path
