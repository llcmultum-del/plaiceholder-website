"""One HTTP helper for every connector: retries on 'too fast' and server errors."""
from __future__ import annotations

import time

import requests


class ApiError(Exception):
    def __init__(self, service: str, status: int, body: str, url: str = ""):
        self.service, self.status, self.body, self.url = service, status, body, url
        super().__init__(f"{service} returned {status} for {url}: {body[:400]}")


class Http:
    def __init__(self, service: str, base_url: str, headers: dict | None = None,
                 auth=None, max_retries: int = 5, timeout: int = 60):
        self.service = service
        self.base_url = base_url.rstrip("/")
        self.session = requests.Session()
        self.session.headers.update(headers or {})
        if auth:
            self.session.auth = auth
        self.max_retries = max_retries
        self.timeout = timeout
        self.calls = 0

    def url(self, path: str) -> str:
        if path.startswith("http://") or path.startswith("https://"):
            return path
        return f"{self.base_url}/{path.lstrip('/')}"

    def request(self, method: str, path: str, ok_404: bool = False, **kw):
        url = self.url(path)
        delay = 1.0
        for attempt in range(self.max_retries + 1):
            self.calls += 1
            try:
                r = self.session.request(method, url, timeout=self.timeout, **kw)
            except requests.RequestException as e:
                if attempt >= self.max_retries:
                    raise ApiError(self.service, 0, str(e), url) from e
                time.sleep(delay)
                delay = min(delay * 2, 30)
                continue
            if r.status_code == 404 and ok_404:
                return None
            if r.status_code == 429 or r.status_code >= 500:
                if attempt >= self.max_retries:
                    raise ApiError(self.service, r.status_code, r.text, url)
                wait = r.headers.get("Retry-After")
                try:
                    wait = float(wait) if wait else delay
                except ValueError:
                    wait = delay
                time.sleep(min(wait, 60))
                delay = min(delay * 2, 30)
                continue
            if r.status_code >= 400:
                raise ApiError(self.service, r.status_code, r.text, url)
            if not r.content:
                return {}
            ctype = r.headers.get("Content-Type", "")
            if "json" in ctype:
                return r.json()
            return r.text
        raise ApiError(self.service, 0, "retries exhausted", url)

    def get(self, path, **kw):
        return self.request("GET", path, **kw)

    def post(self, path, **kw):
        return self.request("POST", path, **kw)

    def patch(self, path, **kw):
        return self.request("PATCH", path, **kw)

    def put(self, path, **kw):
        return self.request("PUT", path, **kw)
