"""Run folders, logs, saved state and backups. Every run leaves a paper trail."""
from __future__ import annotations

import json
import time
from datetime import datetime
from pathlib import Path


class Run:
    def __init__(self, base: Path, agent: str, run_id: str | None = None):
        self.agent = agent
        if run_id:
            self.dir = base / agent / run_id
        else:
            stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
            self.dir = base / agent / stamp
            n = 2
            while self.dir.exists():  # two runs in the same second get separate folders
                self.dir = base / agent / f"{stamp}-{n}"
                n += 1
        self.dir.mkdir(parents=True, exist_ok=True)
        self.id = self.dir.name
        self.log_path = self.dir / "log.jsonl"
        self.state_path = self.dir / "state.json"

    @classmethod
    def latest(cls, base: Path, agent: str) -> "Run | None":
        d = base / agent
        if not d.exists():
            return None
        runs = sorted(p for p in d.iterdir() if p.is_dir())
        return cls(base, agent, runs[-1].name) if runs else None

    def log(self, event: str, **data) -> None:
        rec = {"t": time.strftime("%Y-%m-%dT%H:%M:%S"), "event": event, **data}
        with open(self.log_path, "a", encoding="utf-8") as f:
            f.write(json.dumps(rec, default=str) + "\n")

    def load_state(self) -> dict:
        if self.state_path.exists():
            return json.loads(self.state_path.read_text(encoding="utf-8"))
        return {"done_steps": [], "data": {}}

    def save_state(self, state: dict) -> None:
        tmp = self.state_path.with_suffix(".tmp")
        tmp.write_text(json.dumps(state, indent=2, default=str), encoding="utf-8")
        tmp.replace(self.state_path)

    def save_json(self, name: str, data) -> Path:
        p = self.dir / name
        p.write_text(json.dumps(data, indent=2, default=str), encoding="utf-8")
        return p

    def backup(self, name: str, data) -> Path:
        """Snapshot of records before we change them in a client system."""
        bdir = self.dir / "backups"
        bdir.mkdir(exist_ok=True)
        p = bdir / f"{name}.json"
        p.write_text(json.dumps(data, indent=2, default=str), encoding="utf-8")
        return p
