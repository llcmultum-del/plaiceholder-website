"""Loads a client's setup: client.yaml, secrets (.env) and per-agent settings."""
from __future__ import annotations

import copy
import os
from dataclasses import dataclass, field
from pathlib import Path

import yaml

KIT_ROOT = Path(__file__).resolve().parent.parent
AGENTS_DIR = KIT_ROOT / "agents"
CLIENTS_DIR = KIT_ROOT / "clients"


class ConfigError(Exception):
    pass


def deep_merge(base: dict, override: dict) -> dict:
    out = copy.deepcopy(base)
    for k, v in (override or {}).items():
        if isinstance(v, dict) and isinstance(out.get(k), dict):
            out[k] = deep_merge(out[k], v)
        else:
            out[k] = copy.deepcopy(v)
    return out


def load_yaml(path: Path) -> dict:
    if not path.exists():
        return {}
    with open(path, encoding="utf-8") as f:
        return yaml.safe_load(f) or {}


def save_yaml(path: Path, data: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        yaml.safe_dump(data, f, sort_keys=False, allow_unicode=True)


def read_env_file(path: Path) -> dict:
    """Minimal .env reader: KEY=value lines, # comments, optional quotes."""
    out = {}
    if not path.exists():
        return out
    for line in path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        k, v = line.split("=", 1)
        v = v.strip().strip('"').strip("'")
        out[k.strip()] = v
    return out


def write_env_value(path: Path, key: str, value: str) -> None:
    """Set one key in a .env file without disturbing the others."""
    lines = path.read_text(encoding="utf-8").splitlines() if path.exists() else []
    found = False
    for i, line in enumerate(lines):
        if line.split("=", 1)[0].strip() == key:
            lines[i] = f"{key}={value}"
            found = True
    if not found:
        lines.append(f"{key}={value}")
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    try:
        os.chmod(path, 0o600)
    except OSError:
        pass


DELIVERIES_DIR = KIT_ROOT / "deliveries"


@dataclass
class Agent:
    name: str
    path: Path
    manifest: dict

    @property
    def title(self) -> str:
        return self.manifest.get("title", self.name)

    @property
    def default_settings(self) -> dict:
        return load_yaml(self.path / "settings.yaml")

    def prompt(self, name: str) -> str:
        return (self.path / "prompts" / name).read_text(encoding="utf-8")


def list_agents() -> list[Agent]:
    agents = []
    for p in sorted(AGENTS_DIR.iterdir()):
        if (p / "agent.yaml").exists():
            agents.append(Agent(p.name, p, load_yaml(p / "agent.yaml")))
    return agents


def get_agent(name: str, client: "Client | None" = None) -> Agent:
    """A client's pinned copy of the template if it has one, else the shared template.

    Pinning means a template upgrade never changes a delivered client's agent by
    accident: each client runs the exact template version they were delivered.
    """
    if client is not None:
        pinned = client.path / "pinned" / name
        if (pinned / "agent.yaml").exists():
            return Agent(name, pinned, load_yaml(pinned / "agent.yaml"))
    p = AGENTS_DIR / name
    if not (p / "agent.yaml").exists():
        names = ", ".join(a.name for a in list_agents())
        raise ConfigError(f"No agent called '{name}'. Available: {names}")
    return Agent(name, p, load_yaml(p / "agent.yaml"))


@dataclass
class Client:
    name: str
    path: Path
    config: dict
    secrets: dict = field(default_factory=dict)

    @property
    def mode(self) -> str:
        return self.config.get("mode", "fake")

    @property
    def is_fake(self) -> bool:
        return self.mode == "fake"

    @property
    def runs_dir(self) -> Path:
        d = self.path / "runs"
        d.mkdir(parents=True, exist_ok=True)
        return d

    def secret(self, key: str, required: bool = True) -> str | None:
        val = self.secrets.get(key) or os.environ.get(key)
        if required and not val:
            raise ConfigError(
                f"Missing key {key}. Add it with: python kit.py set-key {self.name} {key}"
            )
        return val

    def connector_kind(self, role: str) -> str | None:
        if self.is_fake:
            return "fake"
        return (self.config.get("connectors") or {}).get(role)

    def connector_settings(self, kind: str) -> dict:
        return (self.config.get("connector_settings") or {}).get(kind, {}) or {}

    def agent_settings(self, agent: Agent) -> dict:
        override = load_yaml(self.path / "agents" / f"{agent.name}.yaml")
        return deep_merge(agent.default_settings, override)

    def agent_settings_path(self, agent: Agent) -> Path:
        return self.path / "agents" / f"{agent.name}.yaml"

    def resolve(self, rel: str) -> Path:
        p = Path(rel)
        return p if p.is_absolute() else (self.path / p)


def load_client(name: str) -> Client:
    path = CLIENTS_DIR / name
    if not (path / "client.yaml").exists():
        raise ConfigError(
            f"No client called '{name}'. Create one with: python kit.py new-client {name}"
        )
    return Client(name, path, load_yaml(path / "client.yaml"), read_env_file(path / ".env"))
