"""Portable agent files: one AGENT.md that works in any chat AI, plus a ready-to-paste
version for each platform the client might already use.

Two ways a client can use an agent:
  1. Chat mode (portable): AGENT.md loaded into their AI platform (a Claude Project,
     ChatGPT GPT, Perplexity Space, Grok project, Gemini Gem, Copilot agent). A person
     gives it data (paste, attach, or the platform's own connectors) and reads results.
  2. Automated mode (runtime): the Python runtime runs on a schedule, pulls from and
     writes back to their tools through APIs, using the same AI platform's API key.
The same tuned settings drive both, so the agent behaves the same either way.
"""
from __future__ import annotations

from datetime import date

from jinja2 import Environment, FileSystemLoader, StrictUndefined

SHORT_LIMIT = 7500  # stays under the ~8,000-character instruction boxes some platforms have

PLATFORMS = {
    "claude-project": {
        "label": "Claude Project (claude.ai)",
        "file": "claude-project.md",
        "steps": [
            "In Claude, create a new Project named after the agent.",
            "Open the project's instructions and paste everything below the line.",
            "Upload AGENT.md to the project's files/knowledge.",
            "Research agents: make sure web search is on. Data agents: attach the exports in each chat.",
            "If the client's CRM or help desk has a Claude connector, connect it so the agent can read records directly.",
        ],
    },
    "chatgpt": {
        "label": "ChatGPT custom GPT or Project",
        "file": "chatgpt.md",
        "steps": [
            "In ChatGPT, create a GPT (or a Project) and open its configuration.",
            "Paste everything below the line into Instructions. It's kept under 8,000 characters.",
            "Upload AGENT.md as a knowledge file.",
            "Turn on web search for research agents, and data analysis/code for agents that do math on files.",
            "Share the GPT only inside the client's workspace.",
        ],
    },
    "perplexity": {
        "label": "Perplexity Space",
        "file": "perplexity.md",
        "steps": [
            "In Perplexity, create a Space for the agent.",
            "Paste everything below the line into the Space's instructions.",
            "Add AGENT.md to the Space's files.",
            "Best fit: research agents (Signal Prospector, Competitor Watch). Perplexity always searches the web.",
        ],
    },
    "grok": {
        "label": "Grok (xAI) project or custom instructions",
        "file": "grok.md",
        "steps": [
            "In Grok, create a project (or open custom instructions).",
            "Paste everything below the line as the instructions.",
            "Attach AGENT.md as a file.",
            "Research agents: make sure web/X search is on for the chat.",
        ],
    },
    "gemini": {
        "label": "Gemini Gem",
        "file": "gemini.md",
        "steps": [
            "In Gemini, create a new Gem.",
            "Paste everything below the line into the Gem's instructions.",
            "Add AGENT.md as a knowledge file.",
            "Research agents: confirm the Gem can use Google Search grounding in the app; the automated runtime can't search with Gemini.",
        ],
    },
    "copilot": {
        "label": "Microsoft Copilot Studio agent",
        "file": "copilot.md",
        "steps": [
            "In Copilot Studio, create an agent.",
            "Paste everything below the line into Instructions. It's kept under 8,000 characters.",
            "Upload AGENT.md as knowledge.",
            "Add the client's Microsoft 365 or Dynamics data sources if they apply.",
        ],
    },
    "api": {
        "label": "Any AI API (developers)",
        "file": "api-system-prompt.md",
        "steps": [
            "Use everything below the line as the system prompt.",
            "Send the records as the user message. Ask for the JSON output format described.",
            "Research agents need a model with web search turned on.",
        ],
    },
}


def render_agent_md(agent, client, settings: dict, short: bool = False) -> str:
    tpl_path = agent.path / "portable.md.j2"
    if not tpl_path.exists():
        raise FileNotFoundError(f"{agent.name} has no portable.md.j2 template")
    env = Environment(loader=FileSystemLoader(str(agent.path)), undefined=StrictUndefined,
                      trim_blocks=False, lstrip_blocks=False, keep_trailing_newline=True)
    text = env.get_template("portable.md.j2").render(
        s=settings, client_name=client.config.get("client", client.name), short=short,
        version=f"v{agent.manifest.get('version', '1.0.0')}", built=date.today().isoformat())
    while "\n\n\n" in text:
        text = text.replace("\n\n\n", "\n\n")
    return text.strip() + "\n"


def platform_file(platform: str, agent, short_text: str) -> str:
    p = PLATFORMS[platform]
    steps = "\n".join(f"{i}. {s}" for i, s in enumerate(p["steps"], 1))
    tail = ("\n\nIf anything here is unclear, follow the full spec in the attached AGENT.md."
            if platform != "api" else "")
    return (f"# {agent.title}: setup for {p['label']}\n\n"
            f"Menu names change from time to time; the idea stays the same.\n\n{steps}\n\n"
            f"---------------- copy everything below this line ----------------\n\n"
            f"{short_text.strip()}{tail}\n")


def skill_file(agent, full_text: str) -> str:
    """Claude skill format (Claude Code / Claude apps): frontmatter plus the full spec."""
    desc = " ".join(agent.manifest.get("summary", agent.title).split())[:300]
    return f"---\nname: {agent.name}\ndescription: {desc}\n---\n\n{full_text}"


def check(full: str, short: str) -> list[str]:
    problems = []
    if len(short) > SHORT_LIMIT:
        problems.append(f"short instructions are {len(short)} characters (limit {SHORT_LIMIT})")
    for name, txt in (("full", full), ("short", short)):
        for bad in ("{{", "}}", "{%", "Your Company"):
            if bad in txt:
                problems.append(f"{name} spec contains '{bad}' (unfilled template or placeholder setting)")
        for section in ("## Your role", "## Rules you must follow", "## Output format"):
            if section not in txt:
                problems.append(f"{name} spec is missing '{section}'")
    return problems
