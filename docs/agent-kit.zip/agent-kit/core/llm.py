"""Claude client: one-off calls, the half-price Batch API, web search, and a fake for demos.

Talks to the Anthropic Messages API over plain HTTPS so the base URL can be pointed
at a test stub. Every result comes back in the same shape:

    {"id", "ok", "text", "json", "search_urls", "usage", "error"}
"""
from __future__ import annotations

import json
import re
import time
from typing import Callable

from .http import Http

DEFAULTS = {
    "model": "claude-sonnet-5-5",
    "max_tokens": 2000,
    "use_batch": True,
    "batch_wait_minutes": 20,       # how long one run waits before saving and exiting
    "poll_seconds": 30,
    "web_search_tool": "web_search_20250305",
    "web_search_max_uses": 5,
    # Prices for estimates only (USD per million tokens). Update from anthropic.com/pricing.
    "price_input_per_mtok": 3.0,
    "price_output_per_mtok": 15.0,
    "price_per_web_search": 0.01,
    "batch_discount": 0.5,
}


class BatchPending(Exception):
    """Research is still running at Anthropic. State is saved; run again later."""


def extract_json(text: str):
    if not text:
        return None
    m = re.search(r"```(?:json)?\s*(\{.*?\}|\[.*?\])\s*```", text, re.S)
    candidates = [m.group(1)] if m else []
    # fall back to the outermost {...}
    start, end = text.find("{"), text.rfind("}")
    if start != -1 and end > start:
        candidates.append(text[start:end + 1])
    for c in candidates:
        try:
            return json.loads(c)
        except json.JSONDecodeError:
            continue
    return None


def parse_message(msg: dict) -> dict:
    """Pull text and the URLs Claude actually saw in web search results."""
    text_parts, urls = [], []
    for block in msg.get("content", []) or []:
        btype = block.get("type")
        if btype == "text":
            text_parts.append(block.get("text", ""))
            for c in block.get("citations", []) or []:
                if c.get("url"):
                    urls.append(c["url"])
        elif btype == "web_search_tool_result":
            content = block.get("content")
            if isinstance(content, list):
                for r in content:
                    if r.get("url"):
                        urls.append(r["url"])
    text = "\n".join(text_parts)
    usage = msg.get("usage", {}) or {}
    return {
        "text": text,
        "json": extract_json(text),
        "search_urls": sorted(set(urls)),
        "usage": {
            "input_tokens": usage.get("input_tokens", 0),
            "output_tokens": usage.get("output_tokens", 0),
            "web_searches": (usage.get("server_tool_use") or {}).get("web_search_requests", 0),
        },
    }


def estimate_cost(usages: list[dict], cfg: dict, batch: bool) -> float:
    cin = sum(u.get("input_tokens", 0) for u in usages)
    cout = sum(u.get("output_tokens", 0) for u in usages)
    searches = sum(u.get("web_searches", 0) for u in usages)
    tok = cin / 1e6 * cfg["price_input_per_mtok"] + cout / 1e6 * cfg["price_output_per_mtok"]
    if batch:
        tok *= cfg["batch_discount"]
    return round(tok + searches * cfg["price_per_web_search"], 4)


class LLM:
    def __init__(self, api_key: str, cfg: dict | None = None, base_url: str = "https://api.anthropic.com"):
        self.cfg = {**DEFAULTS, **(cfg or {})}
        self.http = Http("Anthropic", base_url, headers={
            "x-api-key": api_key,
            "anthropic-version": "2023-06-01",
            "content-type": "application/json",
        })

    # --- request building -------------------------------------------------
    def _params(self, task: dict) -> dict:
        params = {
            "model": task.get("model") or self.cfg["model"],
            "max_tokens": task.get("max_tokens") or self.cfg["max_tokens"],
            "messages": [{"role": "user", "content": task["prompt"]}],
        }
        if task.get("system"):
            params["system"] = task["system"]
        if task.get("web_search"):
            params["tools"] = [{
                "type": self.cfg["web_search_tool"],
                "name": "web_search",
                "max_uses": task.get("max_searches") or self.cfg["web_search_max_uses"],
            }]
        return params

    def ping(self) -> str:
        msg = self.http.post("/v1/messages", json={
            "model": self.cfg["model"], "max_tokens": 5,
            "messages": [{"role": "user", "content": "Reply with OK"}],
        })
        return parse_message(msg)["text"]

    # --- running tasks ----------------------------------------------------
    def run(self, tasks: list[dict], state: dict, log=None) -> dict:
        """Run tasks; returns {task_id: result}. Uses Batch API when configured.

        `state` is a dict saved between runs so a long batch can be resumed.
        """
        if not tasks:
            return {}
        if self.cfg["use_batch"] and len(tasks) > 1:
            return self._run_batch(tasks, state, log)
        out = {}
        for t in tasks:
            try:
                msg = self.http.post("/v1/messages", json=self._params(t))
                r = parse_message(msg)
                out[t["id"]] = {"id": t["id"], "ok": True, "error": None, **r}
            except Exception as e:  # keep going; failed ids go to the retry list
                out[t["id"]] = {"id": t["id"], "ok": False, "error": str(e), "text": "",
                                "json": None, "search_urls": [], "usage": {}}
            if log:
                log("llm_call", id=t["id"], ok=out[t["id"]]["ok"])
        return out

    def _run_batch(self, tasks: list[dict], state: dict, log=None) -> dict:
        batch_id = state.get("batch_id")
        if not batch_id:
            body = {"requests": [{"custom_id": _safe_id(t["id"]), "params": self._params(t)} for t in tasks]}
            resp = self.http.post("/v1/messages/batches", json=body)
            batch_id = resp["id"]
            state["batch_id"] = batch_id
            state["id_map"] = {_safe_id(t["id"]): t["id"] for t in tasks}
            if log:
                log("batch_submitted", batch_id=batch_id, count=len(tasks))
        deadline = time.time() + self.cfg["batch_wait_minutes"] * 60
        while True:
            info = self.http.get(f"/v1/messages/batches/{batch_id}")
            if info.get("processing_status") == "ended":
                break
            if time.time() > deadline:
                raise BatchPending(
                    f"Research batch {batch_id} is still running "
                    f"({info.get('request_counts', {})}). Run the same command again later to collect it."
                )
            time.sleep(self.cfg["poll_seconds"])
        results_url = info.get("results_url") or f"/v1/messages/batches/{batch_id}/results"
        raw = self.http.get(results_url)
        lines = raw.splitlines() if isinstance(raw, str) else [json.dumps(x) for x in raw]
        id_map = state.get("id_map", {})
        out = {}
        for line in lines:
            if not line.strip():
                continue
            rec = json.loads(line)
            tid = id_map.get(rec["custom_id"], rec["custom_id"])
            res = rec.get("result", {})
            if res.get("type") == "succeeded":
                out[tid] = {"id": tid, "ok": True, "error": None, **parse_message(res["message"])}
            else:
                out[tid] = {"id": tid, "ok": False, "error": json.dumps(res)[:300], "text": "",
                            "json": None, "search_urls": [], "usage": {}}
        if log:
            log("batch_collected", batch_id=batch_id, ok=sum(r["ok"] for r in out.values()), total=len(out))
        return out


def _safe_id(s: str) -> str:
    # custom_id must match ^[a-zA-Z0-9_-]{1,64}$
    return re.sub(r"[^a-zA-Z0-9_-]", "_", str(s))[:64]


class FakeLLM:
    """Stands in for Claude in demo mode. Each agent supplies a responder function
    that turns a task into (text, search_urls). No network, no cost."""

    def __init__(self, responder: Callable[[dict], tuple[str, list[str]]], cfg: dict | None = None):
        self.responder = responder
        self.cfg = {**DEFAULTS, **(cfg or {})}

    def ping(self) -> str:
        return "OK (fake)"

    def run(self, tasks: list[dict], state: dict, log=None) -> dict:
        out = {}
        for t in tasks:
            text, urls = self.responder(t)
            out[t["id"]] = {
                "id": t["id"], "ok": True, "error": None, "text": text,
                "json": extract_json(text), "search_urls": urls,
                "usage": {"input_tokens": 1800, "output_tokens": 450,
                          "web_searches": 3 if t.get("web_search") else 0},
            }
        if log:
            log("fake_llm", count=len(tasks))
        return out


# ============================================================================
# Other AI platforms. Same interface as LLM: ping(), run(tasks, state, log), cfg.
# ============================================================================
#
# Model names change often. The defaults below are starting points: confirm the
# current model name on each provider's site and set llm.model in client.yaml.
PROVIDERS = {
    "anthropic":  {"label": "Claude (Anthropic)", "key": "ANTHROPIC_API_KEY", "search": True, "batch": True,
                   "base_url": "https://api.anthropic.com", "default_model": "claude-sonnet-5-5"},
    "openai":     {"label": "ChatGPT (OpenAI)", "key": "OPENAI_API_KEY", "search": True, "batch": False,
                   "api": "responses", "base_url": "https://api.openai.com/v1", "default_model": "gpt-5"},
    "perplexity": {"label": "Perplexity", "key": "PERPLEXITY_API_KEY", "search": True, "batch": False,
                   "api": "chat", "search_style": "builtin", "base_url": "https://api.perplexity.ai",
                   "default_model": "sonar-pro"},
    "xai":        {"label": "Grok (xAI)", "key": "XAI_API_KEY", "search": True, "batch": False,
                   "api": "chat", "search_style": "xai", "base_url": "https://api.x.ai/v1", "default_model": "grok-4"},
    "gemini":     {"label": "Gemini (Google)", "key": "GEMINI_API_KEY", "search": False, "batch": False,
                   "api": "chat", "base_url": "https://generativelanguage.googleapis.com/v1beta/openai",
                   "default_model": "gemini-2.5-pro"},
}


class CapabilityError(Exception):
    """The chosen AI platform can't do something this agent needs (e.g. web search)."""


class OpenAICompatLLM:
    """ChatGPT, Perplexity, Grok and Gemini. No batch discount: tasks run one by one.

    Web search links (needed by research agents' source check) come from:
      openai      Responses API web_search tool -> url_citation annotations / sources
      perplexity  'citations' and 'search_results' on every answer
      xai         search_parameters with return_citations -> 'citations'
      gemini      not available through this adapter -> research agents refuse to run
    """

    def __init__(self, provider: str, api_key: str, cfg: dict | None = None, base_url: str | None = None):
        if provider not in PROVIDERS or provider == "anthropic":
            raise ValueError(f"unknown provider {provider}")
        self.provider = provider
        self.p = PROVIDERS[provider]
        self.cfg = {**DEFAULTS, "model": self.p["default_model"], "use_batch": False, **(cfg or {})}
        if (cfg or {}).get("model", "").startswith("claude"):
            self.cfg["model"] = self.p["default_model"]
        self.cfg["use_batch"] = False
        self.http = Http(self.p["label"], base_url or self.p["base_url"], headers={
            "Authorization": f"Bearer {api_key}", "Content-Type": "application/json"})

    def _check(self, task):
        if task.get("web_search") and not self.p["search"]:
            raise CapabilityError(f"{self.p['label']} can't search the web through its API here; "
                                  "this agent needs web search. Use Claude, ChatGPT, Perplexity or Grok.")

    def ping(self) -> str:
        r = self._call({"id": "ping", "prompt": "Reply with OK", "max_tokens": 16})
        return r["text"] or "OK"

    def _call(self, task: dict) -> dict:
        self._check(task)
        model = task.get("model") or self.cfg["model"]
        if self.p.get("api") == "responses":
            body = {"model": model, "input": task["prompt"],
                    "max_output_tokens": task.get("max_tokens") or self.cfg["max_tokens"]}
            if task.get("system"):
                body["instructions"] = task["system"]
            if task.get("web_search"):
                body["tools"] = [{"type": "web_search"}]
            return parse_responses(self.http.post("/responses", json=body))
        msgs = ([{"role": "system", "content": task["system"]}] if task.get("system") else []) + \
               [{"role": "user", "content": task["prompt"]}]
        body = {"model": model, "messages": msgs, "max_tokens": task.get("max_tokens") or self.cfg["max_tokens"]}
        if task.get("web_search") and self.p.get("search_style") == "xai":
            body["search_parameters"] = {"mode": "on", "return_citations": True,
                                         "max_search_results": task.get("max_searches") or 10}
        return parse_chat(self.http.post("/chat/completions", json=body))

    def run(self, tasks: list[dict], state: dict, log=None) -> dict:
        out = {}
        for t in tasks:
            self._check(t)  # capability problems stop the run instead of failing every task
            try:
                out[t["id"]] = {"id": t["id"], "ok": True, "error": None, **self._call(t)}
            except CapabilityError:
                raise
            except Exception as e:
                out[t["id"]] = {"id": t["id"], "ok": False, "error": str(e), "text": "", "json": None,
                                "search_urls": [], "usage": {}}
            if log:
                log("llm_call", provider=self.provider, id=t["id"], ok=out[t["id"]]["ok"])
        return out


def parse_responses(resp: dict) -> dict:
    texts, urls = [], []
    for item in resp.get("output", []) or []:
        if item.get("type") == "message":
            for c in item.get("content", []) or []:
                if c.get("type") in ("output_text", "text"):
                    texts.append(c.get("text", ""))
                    for a in c.get("annotations", []) or []:
                        if a.get("url"):
                            urls.append(a["url"])
        elif item.get("type") == "web_search_call":
            for s in ((item.get("action") or {}).get("sources") or []):
                if s.get("url"):
                    urls.append(s["url"])
    text = "\n".join(texts) or resp.get("output_text", "")
    u = resp.get("usage", {}) or {}
    n_search = sum(1 for i in resp.get("output", []) or [] if i.get("type") == "web_search_call")
    return {"text": text, "json": extract_json(text), "search_urls": sorted(set(urls)),
            "usage": {"input_tokens": u.get("input_tokens", 0), "output_tokens": u.get("output_tokens", 0),
                      "web_searches": n_search}}


def parse_chat(resp: dict) -> dict:
    ch = (resp.get("choices") or [{}])[0]
    text = (ch.get("message") or {}).get("content") or ""
    urls = list(resp.get("citations") or [])
    urls += [s.get("url") for s in resp.get("search_results") or [] if s.get("url")]
    u = resp.get("usage", {}) or {}
    return {"text": text, "json": extract_json(text), "search_urls": sorted(set(x for x in urls if x)),
            "usage": {"input_tokens": u.get("prompt_tokens", 0), "output_tokens": u.get("completion_tokens", 0),
                      "web_searches": 1 if urls else 0}}
