"""Points engine driven by an editable settings file. No code changes to retune."""
from __future__ import annotations

from .checks import days_ago


def score_items(items: list[dict], rules: dict, type_key="type", date_key="date",
                conf_key="confidence", today=None) -> tuple[int, list[dict]]:
    """Add up points for a list of findings (signals, risk drivers...).

    rules:
      points:      {type_name: points}
      recency:     [{max_days: 30, multiplier: 1.0}, ...]   (optional)
      confidence:  {high: 1.0, medium: 0.7, low: 0.4}        (optional)
      cap:         100
    Each type counts once (the best instance), so ten articles about one deal
    don't swamp the score.
    """
    points = rules.get("points", {})
    recency = sorted(rules.get("recency", []), key=lambda r: r["max_days"])
    conf = rules.get("confidence", {})
    best: dict[str, dict] = {}
    for it in items:
        t = it.get(type_key)
        base = points.get(t)
        if base is None:
            continue
        mult = 1.0
        if recency:
            age = days_ago(it.get(date_key), today)
            if age is None:
                # undated findings count like the oldest bucket unless settings say otherwise
                mult = rules.get("undated_multiplier", recency[-1]["multiplier"])
            else:
                mult = 0.0  # older than every bucket = doesn't count
                for r in recency:
                    if age <= r["max_days"]:
                        mult = r["multiplier"]
                        break
        if conf:
            mult *= conf.get(str(it.get(conf_key, "")).lower(), conf.get("default", 0.5))
        pts = round(base * mult, 1)
        if t not in best or pts > best[t]["points"]:
            best[t] = {"type": t, "points": pts, "base": base, "multiplier": round(mult, 2)}
    total = sum(b["points"] for b in best.values())
    cap = rules.get("cap")
    if cap is not None:
        total = min(total, cap)
    return int(round(total)), sorted(best.values(), key=lambda b: -b["points"])


def tier(score: float, tiers: list[dict]) -> str:
    for t in sorted(tiers, key=lambda t: -t["min"]):
        if score >= t["min"]:
            return t["label"]
    return tiers[-1]["label"] if tiers else ""
