"""Runs an agent's steps in order with dry run, approvals, saved state and resume.

Step kinds (declared in agent.yaml):
  read   free, touches nothing             -> always runs
  local  computes on data already pulled   -> always runs
  spend  costs money (Claude, credits)     -> needs approval; skipped in dry run
  write  changes a client system           -> needs approval; skipped in dry run

Approvals:
  - In a terminal, the run pauses and asks y/N.
  - From Claude Code (no terminal), the run stops at the step, prints
    NEEDS APPROVAL, and saves its place. Claude asks the person in chat, then
    reruns with --approve <step> (or --yes) and --resume.
  - Demo (fake) mode auto-approves: nothing real is spent or changed.
"""
from __future__ import annotations

import importlib.util
import sys
import traceback

from .config import Agent, Client
from .connectors import build, build_llm
from .llm import BatchPending
from .runlog import Run


class NeedsApproval(Exception):
    pass


class StopRun(Exception):
    """A step decided there's nothing more to do (e.g. dry run reached a paid step)."""


def load_steps_module(agent: Agent):
    path = agent.path / "steps.py"
    spec = importlib.util.spec_from_file_location(f"agent_steps_{agent.name.replace('-', '_')}", path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


class Context:
    def __init__(self, client: Client, agent: Agent, run: Run, live: bool, limit: int | None,
                 approved: set, auto_yes: bool, out=print):
        self.client = client
        self.agent = agent
        self.run = run
        self.settings = client.agent_settings(agent)
        self.live = live or client.is_fake
        self.fake = client.is_fake
        self.limit = limit
        self.approved = approved
        self.auto_yes = auto_yes or client.is_fake
        self.out = out
        self.state = run.load_state()
        self.data = self.state.setdefault("data", {})
        self._conn = {}
        self._llm = None
        self.steps_mod = load_steps_module(agent)
        self.costs: list[dict] = self.state.setdefault("costs", [])

    # connectors are created on first use so a run only needs the keys it touches
    def conn(self, role: str):
        if role not in self._conn:
            self._conn[role] = build(self.client, role)
        return self._conn[role]

    @property
    def llm(self):
        if self._llm is None:
            responder = getattr(self.steps_mod, "fake_responder", None)
            self._llm = build_llm(self.client, responder, self.settings.get("llm"))
        return self._llm

    def log(self, event, **kw):
        self.run.log(event, **kw)

    def approve(self, step: str, summary: str, est_cost: float | None = None) -> bool:
        cost = f" (estimated cost ${est_cost:,.2f})" if est_cost is not None else ""
        msg = f"{summary}{cost}"
        if not self.live:
            self.out(f"  DRY RUN: would {msg}")
            self.log("dry_run_skip", step=step, summary=msg)
            self.dry_skipped = True  # so the step isn't marked done
            return False
        if self.auto_yes or step in self.approved:
            if self.fake:
                self.out(f"  [demo auto-approved] {msg}")
            self.log("approved", step=step, summary=msg)
            return True
        if sys.stdin and sys.stdin.isatty():
            ans = input(f"  APPROVE? {msg} [y/N] ").strip().lower()
            ok = ans in ("y", "yes")
            self.log("approval_answer", step=step, ok=ok)
            if not ok:
                raise StopRun(f"Stopped: '{step}' was not approved.")
            return True
        self.state["pending_approval"] = {"step": step, "summary": msg}
        self.run.save_state(self.state)
        raise NeedsApproval(f"NEEDS APPROVAL [{step}]: {msg}\n"
                            f"  Rerun with: --resume --approve {step}")

    def require(self, step: str, summary: str, est_cost: float | None = None) -> None:
        """Approval for a paid or writing step; in a dry run this ends the run cleanly."""
        if not self.approve(step, summary, est_cost):
            raise StopRun("Dry run finished here. Nothing was written or spent. "
                          "Rerun with --live to do it for real (each paid or writing step asks first).")

    def add_cost(self, step: str, usd: float, note: str = "") -> None:
        self.costs.append({"step": step, "usd": round(usd, 4), "note": note})

    def records(self, items: list) -> list:
        return items[: self.limit] if self.limit else items

    def save(self):
        self.run.save_state(self.state)


def run_agent(client: Client, agent: Agent, live=False, limit=None, approve=(), yes=False,
              resume=False, only: str | None = None, out=print) -> int:
    """Returns exit code: 0 done, 2 failed, 3 waiting for approval, 4 waiting on batch."""
    run = Run.latest(client.runs_dir, agent.name) if resume else None
    if resume and run is None:
        out("No earlier run to resume; starting fresh.")
    run = run or Run(client.runs_dir, agent.name)
    ctx = Context(client, agent, run, live, limit, set(approve), yes, out)
    if limit and not resume:
        ctx.state["limit"] = limit
    ctx.limit = ctx.limit or ctx.state.get("limit")
    if live and not client.is_fake:
        ctx.state["live"] = True
    ctx.live = ctx.live or ctx.state.get("live", False)
    ctx.state.pop("pending_approval", None)

    mode = "DEMO (fake data)" if client.is_fake else ("LIVE" if ctx.live else "DRY RUN (nothing written or spent)")
    out(f"\n== {agent.title} for {client.config.get('client', client.name)} | {mode} | run {run.id} ==")
    if ctx.limit:
        out(f"   limited to {ctx.limit} records")
    ctx.log("run_start", mode=mode, limit=ctx.limit, resume=resume)

    steps = agent.manifest.get("steps", [])
    done = set(ctx.state.setdefault("done_steps", []))
    for i, step in enumerate(steps, 1):
        name = step["name"]
        if only and name != only:
            continue
        if name in done and not only:
            out(f"[{i}/{len(steps)}] {name}: already done")
            continue
        out(f"[{i}/{len(steps)}] {name}: {step.get('desc', '')}")
        fn = getattr(ctx.steps_mod, f"step_{name.replace('-', '_')}")
        ctx.dry_skipped = False
        try:
            result = fn(ctx)
        except NeedsApproval as e:
            out(str(e))
            ctx.log("needs_approval", step=name)
            return 3
        except BatchPending as e:
            ctx.save()
            out(f"  WAITING: {e}")
            ctx.log("batch_pending", step=name)
            return 4
        except StopRun as e:
            ctx.save()
            out(f"  {e}")
            ctx.log("stopped", step=name, reason=str(e))
            return 0
        except Exception as e:
            ctx.save()
            ctx.log("step_failed", step=name, error=str(e), trace=traceback.format_exc())
            out(f"  FAILED: {e}\n  Details in {run.log_path}")
            return 2
        if result:
            out(f"  {result}")
        if ctx.dry_skipped:
            ctx.save()
            continue  # a live run must still do this step
        done.add(name)
        ctx.state["done_steps"] = sorted(done, key=[s["name"] for s in steps].index)
        ctx.save()
        ctx.log("step_done", step=name, result=result)

    total = sum(c.get("usd", 0) for c in ctx.costs)
    out(f"\nDone. Estimated usage cost this run: ${total:,.2f}. Files: {run.dir}")
    ctx.log("run_done", est_cost=total)
    return 0
