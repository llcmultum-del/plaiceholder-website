"""Salesforce (Accounts, Contacts, Notes, Cases) via the REST API.

Auth: OAuth 2.0 client-credentials flow from an External Client App / Connected App
with "Enable Client Credentials Flow" and a Run As user.
Keys: SALESFORCE_CLIENT_ID, SALESFORCE_CLIENT_SECRET
Settings: connector_settings.salesforce.instance_url (https://yourco.my.salesforce.com)

Custom fields are created through the Tooling API. Salesforce hides new fields from
everyone until field-level security is granted: after setup, the admin adds the
"AI Agents" fields to a permission set for the integration user and the reps.
Logical field `ai_signal_score` becomes `AI_Signal_Score__c`.
"""
from __future__ import annotations

from ..checks import norm_domain
from ..http import ApiError, Http
from .base import CRM, Helpdesk

STD_COMPANY = {"name": "Name", "domain": "Website"}
STD_CONTACT = {"first_name": "FirstName", "last_name": "LastName", "email": "Email", "title": "Title"}


def sf_field(name: str) -> str:
    return "_".join(p.capitalize() if not p.isupper() else p for p in name.split("_")).replace("Ai_", "AI_") + "__c"


def _to_sf(props: dict, std: dict) -> dict:
    out = {}
    for k, v in props.items():
        if k in ("id", "company_id"):
            continue
        if isinstance(v, list):
            v = "\n".join(map(str, v))
        out[std.get(k) or sf_field(k)] = v
    return out


def _from_sf(rec: dict, std: dict, fields: list[str]) -> dict:
    out = {"id": rec.get("Id")}
    for k, api in std.items():
        if api in rec:
            out[k] = rec[api]
    for f in fields:
        api = sf_field(f)
        if api in rec:
            out[f] = rec[api]
    if "domain" in out:
        out["domain"] = norm_domain(out["domain"] or "")
    return out


def _q(s: str) -> str:
    return str(s).replace("\\", "\\\\").replace("'", "\\'")


TYPE_META = {
    "number": {"type": "Number", "precision": 18, "scale": 2},
    "text": {"type": "Text", "length": 255},
    "textarea": {"type": "LongTextArea", "length": 32768, "visibleLines": 6},
    "date": {"type": "Date"},
    "select": {"type": "Picklist"},
}


class Salesforce(CRM, Helpdesk):
    def __init__(self, client_id: str, client_secret: str, settings: dict):
        self.instance = settings["instance_url"].rstrip("/")
        self.version = settings.get("api_version", "v62.0")
        token_http = Http("Salesforce auth", self.instance)
        tok = token_http.post("/services/oauth2/token", data={
            "grant_type": "client_credentials", "client_id": client_id, "client_secret": client_secret})
        self.instance = tok.get("instance_url", self.instance)
        self.http = Http("Salesforce", f"{self.instance}/services/data/{self.version}",
                         headers={"Authorization": f"Bearer {tok['access_token']}",
                                  "Content-Type": "application/json"})

    def ping(self):
        r = self.http.get("/limits")
        left = (r.get("DailyApiRequests") or {}).get("Remaining")
        return f"Salesforce OK ({left} API calls left today)"

    def query(self, soql: str, limit: int = 2000) -> list[dict]:
        out = []
        r = self.http.get("/query", params={"q": soql})
        out += r.get("records", [])
        while r.get("nextRecordsUrl") and len(out) < limit:
            r = self.http.get(self.instance + r["nextRecordsUrl"])
            out += r.get("records", [])
        return out[:limit]

    def ensure_fields(self, object_type, fields):
        sobj = {"company": "Account", "contact": "Contact"}[object_type]
        existing = {f["name"] for f in self.http.get(f"/sobjects/{sobj}/describe").get("fields", [])}
        created = []
        for f in fields:
            api = sf_field(f["name"])
            if api in existing:
                continue
            meta = {"label": f.get("label", f["name"])[:40], **TYPE_META[f.get("type", "text")]}
            if f.get("type") == "select":
                meta["valueSet"] = {"valueSetDefinition": {"value": [
                    {"fullName": o, "label": o, "default": False} for o in f.get("options", [])]}}
            try:
                self.http.post("/tooling/sobjects/CustomField",
                               json={"FullName": f"{sobj}.{api}", "Metadata": meta})
                created.append(api)
            except ApiError as e:
                raise ApiError("Salesforce", e.status,
                               f"Could not create {sobj}.{api}. Create it by hand in Setup > Object Manager "
                               f"or give the integration user 'Customize Application'. Detail: {e.body}")
        return created

    def find_company_by_domain(self, domain):
        d = norm_domain(domain)
        recs = self.query(f"SELECT Id, Name, Website FROM Account WHERE Website LIKE '%{_q(d)}%' LIMIT 5")
        for r in recs:
            if norm_domain(r.get("Website") or "") == d:
                return _from_sf(r, STD_COMPANY, [])
        return None

    def get_company(self, company_id, fields=None):
        cols = ", ".join(["Id", "Name", "Website"] + [sf_field(f) for f in fields or []])
        recs = self.query(f"SELECT {cols} FROM Account WHERE Id = '{_q(company_id)}'")
        return _from_sf(recs[0], STD_COMPANY, fields or []) if recs else None

    def create_company(self, props):
        return self.http.post("/sobjects/Account", json=_to_sf(props, STD_COMPANY))["id"]

    def update_company(self, company_id, props):
        self.http.patch(f"/sobjects/Account/{company_id}", json=_to_sf(props, STD_COMPANY))

    def list_companies(self, fields, date_field=None, date_from=None, date_to=None, limit=1000):
        cols = ", ".join(["Id", "Name", "Website"] + [sf_field(f) for f in fields])
        where = ""
        if date_field:
            df = sf_field(date_field)
            where = f" WHERE {df} >= {date_from} AND {df} <= {date_to}"
        recs = self.query(f"SELECT {cols} FROM Account{where} LIMIT {int(limit)}", limit)
        return [_from_sf(r, STD_COMPANY, fields) for r in recs]

    def find_contact_by_email(self, email):
        recs = self.query(f"SELECT Id, FirstName, LastName, Email FROM Contact WHERE Email = '{_q(email)}' LIMIT 1")
        return _from_sf(recs[0], STD_CONTACT, []) if recs else None

    def create_contact(self, props, company_id=None):
        body = _to_sf({k: v for k, v in props.items() if k != "linkedin_url"}, STD_CONTACT)
        if company_id:
            body["AccountId"] = company_id
        return self.http.post("/sobjects/Contact", json=body)["id"]

    def company_notes(self, company_id, limit=20):
        recs = self.query(
            "SELECT Id, Subject, Description, ActivityDate FROM Task "
            f"WHERE WhatId = '{_q(company_id)}' ORDER BY ActivityDate DESC NULLS LAST LIMIT {int(limit)}")
        return [{"id": r["Id"], "date": r.get("ActivityDate"),
                 "body": f"{r.get('Subject') or ''}: {r.get('Description') or ''}"} for r in recs]

    def add_note(self, company_id, body):
        return self.http.post("/sobjects/Task", json={
            "WhatId": company_id, "Subject": "AI agent note", "Description": body,
            "Status": "Completed"})["id"]

    def tickets_for_company(self, company, since_days=180, limit=50):
        recs = self.query(
            "SELECT Id, Subject, Description, Status, Priority, CreatedDate, LastModifiedDate FROM Case "
            f"WHERE AccountId = '{_q(company['id'])}' AND CreatedDate = LAST_N_DAYS:{int(since_days)} "
            f"ORDER BY CreatedDate DESC LIMIT {int(limit)}")
        return [{"id": r["Id"], "subject": r.get("Subject"), "description": r.get("Description"),
                 "status": r.get("Status"), "priority": r.get("Priority"),
                 "created_at": r.get("CreatedDate"), "updated_at": r.get("LastModifiedDate")} for r in recs]
