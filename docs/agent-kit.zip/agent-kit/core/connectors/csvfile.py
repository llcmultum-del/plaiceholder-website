"""Accounting data from CSV exports. Works with any system that can export a spreadsheet.

Settings (connector_settings.csv):
  invoices:         path to invoices CSV (one row per line item)
  purchase_orders:  path to POs CSV (one row per line item)
  vendors:          optional approved-vendor list
  columns:          optional mapping if their headers differ, e.g. {invoice_number: "Bill No"}

Expected headers (rename with `columns`):
  invoices: invoice_number, vendor, invoice_date, po_number, sku, description, qty, unit_price
  POs:      po_number, vendor, po_date, sku, description, qty, unit_price
  vendors:  vendor, approved (yes/no)
"""
from __future__ import annotations

import csv
from pathlib import Path

from ..checks import parse_date
from .base import Accounting

DEFAULT_COLS = {
    "invoice_number": "invoice_number", "vendor": "vendor", "invoice_date": "invoice_date",
    "po_number": "po_number", "sku": "sku", "description": "description", "qty": "qty",
    "unit_price": "unit_price", "po_date": "po_date", "approved": "approved",
}


def _num(v) -> float:
    try:
        return float(str(v).replace("$", "").replace(",", "").strip() or 0)
    except ValueError:
        return 0.0


class CsvAccounting(Accounting):
    def __init__(self, settings: dict, base: Path | None = None):
        self.s = settings
        self.base = base or Path(".")
        self.cols = {**DEFAULT_COLS, **(settings.get("columns") or {})}

    def _path(self, key) -> Path | None:
        v = self.s.get(key)
        if not v:
            return None
        p = Path(v)
        return p if p.is_absolute() else self.base / p

    def _rows(self, key):
        p = self._path(key)
        if not p or not p.exists():
            return []
        with open(p, newline="", encoding="utf-8-sig") as f:
            return list(csv.DictReader(f))

    def _c(self, row, key):
        return (row.get(self.cols[key]) or "").strip()

    def ping(self):
        missing = [k for k in ("invoices", "purchase_orders") if not (self._path(k) and self._path(k).exists())]
        if missing:
            raise FileNotFoundError(f"CSV files not found: {', '.join(missing)}")
        return f"CSV OK ({len(self._rows('invoices'))} invoice lines, {len(self._rows('purchase_orders'))} PO lines)"

    def _group(self, rows, num_key, date_key, kind):
        # Group line rows into documents by number + vendor + date, so the same invoice
        # number entered twice on different days stays two documents (a duplicate to catch).
        docs: dict[str, dict] = {}
        seen_ids: dict[str, int] = {}
        for r in rows:
            num = self._c(r, num_key)
            if not num:
                continue
            dt = str(parse_date(self._c(r, date_key)) or self._c(r, date_key))
            key = f"{num}|{self._c(r, 'vendor').lower()}|{dt}"
            if key not in docs:
                seen_ids[num] = seen_ids.get(num, 0) + 1
                suffix = "" if seen_ids[num] == 1 else f"#{seen_ids[num]}"
            d = docs.setdefault(key, {
                "id": f"{kind}:{num}{suffix}", "number": num, "vendor": self._c(r, "vendor"),
                "date": dt,
                "po_number": self._c(r, "po_number") if kind == "INV" else num,
                "lines": [], "amount": 0.0})
            line = {"sku": self._c(r, "sku"), "description": self._c(r, "description"),
                    "qty": _num(self._c(r, "qty")), "unit_price": _num(self._c(r, "unit_price"))}
            d["lines"].append(line)
            d["amount"] = round(d["amount"] + line["qty"] * line["unit_price"], 2)
        return list(docs.values())

    def list_invoices(self, since=None):
        inv = self._group(self._rows("invoices"), "invoice_number", "invoice_date", "INV")
        if since:
            s = parse_date(since)
            inv = [i for i in inv if parse_date(i["date"]) and parse_date(i["date"]) >= s]
        return inv

    def list_purchase_orders(self):
        return self._group(self._rows("purchase_orders"), "po_number", "po_date", "PO")

    def list_vendors(self):
        return [{"vendor": self._c(r, "vendor"),
                 "approved": self._c(r, "approved").lower() in ("yes", "y", "true", "1")}
                for r in self._rows("vendors")]
