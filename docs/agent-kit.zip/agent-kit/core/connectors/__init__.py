"""Picks the right connector for a client from client.yaml. Agents ask for a role
(crm, helpdesk, enrichment, notify, accounting); this returns whatever that client uses."""
from __future__ import annotations

from ..config import Client, ConfigError

ROLES = {
    "crm": ["hubspot", "salesforce"],
    "helpdesk": ["zendesk", "hubspot", "salesforce"],
    "enrichment": ["apollo"],
    "notify": ["slack"],
    "accounting": ["csv", "quickbooks"],
}

KEYS = {
    "hubspot": ["HUBSPOT_TOKEN"],
    "salesforce": ["SALESFORCE_CLIENT_ID", "SALESFORCE_CLIENT_SECRET"],
    "apollo": ["APOLLO_API_KEY"],
    "zendesk": ["ZENDESK_EMAIL", "ZENDESK_TOKEN"],
    "slack": ["SLACK_WEBHOOK_URL"],
    "quickbooks": ["QUICKBOOKS_ACCESS_TOKEN", "QUICKBOOKS_REALM_ID"],
    "csv": [],
    "anthropic": ["ANTHROPIC_API_KEY"],
    "openai": ["OPENAI_API_KEY"],
    "perplexity": ["PERPLEXITY_API_KEY"],
    "xai": ["XAI_API_KEY"],
    "gemini": ["GEMINI_API_KEY"],
}

_fake_world_cache: dict = {}


def fake_world(client: Client):
    from .fake import FakeWorld
    p = client.runs_dir / "fake_world.json"
    key = str(p)
    if key not in _fake_world_cache or not p.exists():
        _fake_world_cache[key] = FakeWorld(p)
    return _fake_world_cache[key]


def build(client: Client, role: str):
    kind = client.connector_kind(role)
    if not kind:
        raise ConfigError(f"client.yaml has no connector for '{role}'. Options: {', '.join(ROLES[role])}")
    if kind == "fake":
        from . import fake
        w = fake_world(client)
        return {
            "crm": lambda: fake.FakeCRM(w),
            "helpdesk": lambda: fake.FakeHelpdesk(w),
            "enrichment": lambda: fake.FakeEnrichment(w),
            "notify": lambda: fake.FakeNotifier(client.runs_dir / "fake_outbox.txt"),
            "accounting": lambda: fake.FakeAccounting(),
        }[role]()
    if kind not in ROLES[role]:
        raise ConfigError(f"'{kind}' can't be used as {role}. Options: {', '.join(ROLES[role])}")
    s = client.connector_settings(kind)
    sec = client.secret
    if kind == "hubspot":
        from .hubspot import HubSpot
        return HubSpot(sec("HUBSPOT_TOKEN"), s)
    if kind == "salesforce":
        from .salesforce import Salesforce
        if "instance_url" not in s:
            raise ConfigError("Add connector_settings.salesforce.instance_url to client.yaml")
        return Salesforce(sec("SALESFORCE_CLIENT_ID"), sec("SALESFORCE_CLIENT_SECRET"), s)
    if kind == "apollo":
        from .apollo import Apollo
        return Apollo(sec("APOLLO_API_KEY"), s)
    if kind == "zendesk":
        from .zendesk import Zendesk
        if "subdomain" not in s and "base_url" not in s:
            raise ConfigError("Add connector_settings.zendesk.subdomain to client.yaml")
        return Zendesk(sec("ZENDESK_EMAIL"), sec("ZENDESK_TOKEN"), s)
    if kind == "slack":
        from .slack import Slack
        return Slack(sec("SLACK_WEBHOOK_URL"), s)
    if kind == "csv":
        from .csvfile import CsvAccounting
        return CsvAccounting(s, base=client.path)
    if kind == "quickbooks":
        from .quickbooks import QuickBooks
        return QuickBooks(sec("QUICKBOOKS_ACCESS_TOKEN"), sec("QUICKBOOKS_REALM_ID"), s)
    raise ConfigError(f"Unknown connector {kind}")


def llm_provider(client: Client) -> str:
    return (client.config.get("llm") or {}).get("provider", "anthropic")


def build_llm(client: Client, fake_responder=None, overrides: dict | None = None):
    """The AI platform for this client: anthropic (default), openai, perplexity, xai or gemini."""
    cfg = {**(client.config.get("llm") or {}), **(overrides or {})}
    provider = cfg.pop("provider", "anthropic")
    if client.is_fake:
        from ..llm import FakeLLM
        if fake_responder is None:
            raise ConfigError("This agent has no fake responder for demo mode")
        return FakeLLM(fake_responder, cfg)
    from ..llm import LLM, PROVIDERS, OpenAICompatLLM
    if provider not in PROVIDERS:
        raise ConfigError(f"Unknown AI platform '{provider}'. Options: {', '.join(PROVIDERS)}")
    key = client.secret(PROVIDERS[provider]["key"])
    if provider == "anthropic":
        return LLM(key, cfg, base_url=cfg.get("base_url", PROVIDERS["anthropic"]["base_url"]))
    return OpenAICompatLLM(provider, key, cfg, base_url=cfg.get("base_url"))
