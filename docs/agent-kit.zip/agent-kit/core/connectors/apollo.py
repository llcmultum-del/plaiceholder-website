"""Apollo.io: company lists, people search, verified emails.

Key: APOLLO_API_KEY (a master API key is needed for people search and enrichment).
Endpoint paths change from time to time; override them in client.yaml under
connector_settings.apollo.endpoints if Apollo renames one.
Credits: company and people search are free on most plans; each revealed email
costs a credit. The agent's settings cap how many get revealed per run.
"""
from __future__ import annotations

from ..checks import norm_domain
from ..http import Http
from .base import Enrichment

ENDPOINTS = {
    "company_search": "/api/v1/mixed_companies/search",
    "people_search": "/api/v1/mixed_people/api_search",
    "people_match": "/api/v1/people/match",
    "health": "/v1/auth/health",
}


class Apollo(Enrichment):
    def __init__(self, api_key: str, settings: dict | None = None):
        s = settings or {}
        self.ep = {**ENDPOINTS, **(s.get("endpoints") or {})}
        self.http = Http("Apollo", s.get("base_url", "https://api.apollo.io"),
                         headers={"x-api-key": api_key, "Content-Type": "application/json",
                                  "Cache-Control": "no-cache"})
        self.credits_used = 0

    def ping(self):
        r = self.http.get(self.ep["health"])
        if isinstance(r, dict) and r.get("is_logged_in") is False:
            raise RuntimeError("Apollo key rejected")
        return "Apollo OK"

    def search_companies(self, filters, limit):
        out, page = [], 1
        per_page = min(100, max(1, limit))
        while len(out) < limit:
            body = {**filters, "page": page, "per_page": per_page}
            r = self.http.post(self.ep["company_search"], json=body)
            orgs = (r.get("organizations") or []) + (r.get("accounts") or [])
            if not orgs:
                break
            for o in orgs:
                dom = norm_domain(o.get("primary_domain") or o.get("website_url") or o.get("domain") or "")
                if not dom:
                    continue
                out.append({
                    "name": o.get("name"), "domain": dom,
                    "industry": o.get("industry"),
                    "employees": o.get("estimated_num_employees"),
                    "location": ", ".join(x for x in [o.get("city"), o.get("state"), o.get("country")] if x),
                    "linkedin_url": o.get("linkedin_url"),
                    "apollo_id": o.get("id"),
                })
            pages = (r.get("pagination") or {}).get("total_pages", page)
            if page >= pages:
                break
            page += 1
        return out[:limit]

    def search_people(self, domain, titles, limit=5):
        body = {"q_organization_domains_list": [norm_domain(domain)], "person_titles": titles,
                "page": 1, "per_page": min(25, max(limit * 3, 5))}
        r = self.http.post(self.ep["people_search"], json=body)
        people = r.get("people") or r.get("contacts") or []
        tl = [t.lower() for t in titles]

        def rank(p):  # earlier in the client's title list = better
            t = (p.get("title") or "").lower()
            return min([i for i, x in enumerate(tl) if x in t] or [99])

        people.sort(key=rank)
        return [{"id": p.get("id"), "first_name": p.get("first_name"),
                 "last_name": p.get("last_name") or p.get("last_name_obfuscated"),
                 "title": p.get("title"), "linkedin_url": p.get("linkedin_url"),
                 "domain": norm_domain(domain)} for p in people][:limit]

    def reveal_email(self, person):
        r = self.http.post(self.ep["people_match"], json={"id": person["id"], "reveal_personal_emails": False})
        self.credits_used += 1
        p = r.get("person") or {}
        if p.get("email") and p.get("email_status") in (None, "verified", "likely to engage"):
            # fill in a full last name if search only gave an obfuscated one
            if p.get("last_name"):
                person["last_name"] = p["last_name"]
            return p["email"]
        return None
