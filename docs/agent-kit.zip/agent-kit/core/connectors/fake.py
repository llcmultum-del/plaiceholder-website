"""Fake versions of every connector for demos and testing. Nothing leaves the machine.

The fake world is seeded from every agent's sample_data/world.json and saved to
clients/<client>/runs/fake_world.json, so repeat runs behave like a real account
(companies already loaded stay loaded, and so on). Delete that file to reset.
"""
from __future__ import annotations

import json
from pathlib import Path

from ..checks import norm_domain, parse_date
from ..config import AGENTS_DIR
from .base import CRM, Accounting, Enrichment, Helpdesk, Notifier


class FakeWorld:
    def __init__(self, path: Path):
        self.path = path
        if path.exists():
            self.data = json.loads(path.read_text(encoding="utf-8"))
        else:
            self.data = self._seed()
            self.save()

    @staticmethod
    def _resolve_dates(obj):
        """Sample files write dates as '@+45d' / '@-10d' (days from today) so demos never go stale."""
        from datetime import date, timedelta
        import re
        if isinstance(obj, dict):
            return {k: FakeWorld._resolve_dates(v) for k, v in obj.items()}
        if isinstance(obj, list):
            return [FakeWorld._resolve_dates(v) for v in obj]
        if isinstance(obj, str):
            m = re.fullmatch(r"@([+-]\d+)d", obj)
            if m:
                return (date.today() + timedelta(days=int(m.group(1)))).isoformat()
        return obj

    @staticmethod
    def _seed() -> dict:
        world = {"crm_companies": {}, "crm_contacts": {}, "crm_notes": {}, "tickets": [],
                 "apollo_companies": [], "apollo_people": [], "fields": {}, "next_id": 1000}
        for wf in sorted(AGENTS_DIR.glob("*/sample_data/world.json")):
            w = FakeWorld._resolve_dates(json.loads(wf.read_text(encoding="utf-8")))
            for c in w.get("crm_companies", []):
                world["crm_companies"][str(c["id"])] = c
            for n in w.get("crm_notes", []):
                world["crm_notes"].setdefault(str(n["company_id"]), []).append(n)
            world["tickets"] += w.get("tickets", [])
            world["apollo_companies"] += w.get("apollo_companies", [])
            world["apollo_people"] += w.get("apollo_people", [])
        return world

    def new_id(self) -> str:
        self.data["next_id"] += 1
        return str(self.data["next_id"])

    def save(self) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.path.write_text(json.dumps(self.data, indent=2), encoding="utf-8")


class FakeCRM(CRM):
    def __init__(self, world: FakeWorld):
        self.w = world

    def ping(self):
        return f"fake CRM with {len(self.w.data['crm_companies'])} companies"

    def ensure_fields(self, object_type, fields):
        have = self.w.data["fields"].setdefault(object_type, [])
        created = [f["name"] for f in fields if f["name"] not in have]
        have += created
        self.w.save()
        return created

    def find_company_by_domain(self, domain):
        d = norm_domain(domain)
        for c in self.w.data["crm_companies"].values():
            if norm_domain(c.get("domain", "")) == d:
                return dict(c)
        return None

    def get_company(self, company_id, fields=None):
        c = self.w.data["crm_companies"].get(str(company_id))
        return dict(c) if c else None

    def create_company(self, props):
        cid = self.w.new_id()
        self.w.data["crm_companies"][cid] = {"id": cid, **props}
        self.w.save()
        return cid

    def update_company(self, company_id, props):
        self.w.data["crm_companies"][str(company_id)].update(props)
        self.w.save()

    def list_companies(self, fields, date_field=None, date_from=None, date_to=None, limit=1000):
        out = []
        for c in self.w.data["crm_companies"].values():
            if date_field:
                d = parse_date(c.get(date_field))
                if not d or (date_from and d < parse_date(date_from)) or (date_to and d > parse_date(date_to)):
                    continue
            out.append(dict(c))
        return out[:limit]

    def find_contact_by_email(self, email):
        for c in self.w.data["crm_contacts"].values():
            if c.get("email", "").lower() == (email or "").lower():
                return dict(c)
        return None

    def create_contact(self, props, company_id=None):
        cid = self.w.new_id()
        self.w.data["crm_contacts"][cid] = {"id": cid, "company_id": company_id, **props}
        self.w.save()
        return cid

    def company_notes(self, company_id, limit=20):
        return self.w.data["crm_notes"].get(str(company_id), [])[:limit]

    def add_note(self, company_id, body):
        nid = self.w.new_id()
        self.w.data["crm_notes"].setdefault(str(company_id), []).append(
            {"id": nid, "company_id": company_id, "date": "today", "body": body})
        self.w.save()
        return nid


class FakeHelpdesk(Helpdesk):
    def __init__(self, world: FakeWorld):
        self.w = world

    def ping(self):
        return f"fake help desk with {len(self.w.data['tickets'])} tickets"

    def tickets_for_company(self, company, since_days=180, limit=50):
        d = norm_domain(company.get("domain", ""))
        return [t for t in self.w.data["tickets"] if norm_domain(t.get("company_domain", "")) == d][:limit]


class FakeEnrichment(Enrichment):
    def __init__(self, world: FakeWorld):
        self.w = world
        self.credits_used = 0

    def ping(self):
        return f"fake Apollo with {len(self.w.data['apollo_companies'])} companies"

    def search_companies(self, filters, limit):
        return [dict(c) for c in self.w.data["apollo_companies"]][:limit]

    def search_people(self, domain, titles, limit=5):
        d = norm_domain(domain)
        tl = [t.lower() for t in titles]
        hits = [p for p in self.w.data["apollo_people"] if norm_domain(p.get("domain", "")) == d]
        hits.sort(key=lambda p: min([i for i, t in enumerate(tl) if t in p.get("title", "").lower()] or [99]))
        return [{k: v for k, v in p.items() if k != "email"} for p in hits][:limit]

    def reveal_email(self, person):
        self.credits_used += 1
        for p in self.w.data["apollo_people"]:
            if p["id"] == person["id"]:
                return p.get("email")
        return None


class FakeNotifier(Notifier):
    def __init__(self, outbox: Path):
        self.outbox = outbox

    def ping(self):
        return "fake notifier (messages saved to a file)"

    def send(self, text):
        self.outbox.parent.mkdir(parents=True, exist_ok=True)
        with open(self.outbox, "a", encoding="utf-8") as f:
            f.write(text.strip() + "\n\n---\n\n")


class FakeAccounting(Accounting):
    """Reads the invoice-checker's sample CSVs."""

    def __init__(self):
        from .csvfile import CsvAccounting
        sd = AGENTS_DIR / "invoice-checker" / "sample_data"
        self.inner = CsvAccounting({
            "invoices": str(sd / "invoices.csv"),
            "purchase_orders": str(sd / "purchase_orders.csv"),
            "vendors": str(sd / "vendors.csv"),
        }, base=sd)

    def ping(self):
        return "fake accounting (sample CSV files)"

    def list_invoices(self, since=None):
        return self.inner.list_invoices(since)

    def list_purchase_orders(self):
        return self.inner.list_purchase_orders()

    def list_vendors(self):
        return self.inner.list_vendors()
