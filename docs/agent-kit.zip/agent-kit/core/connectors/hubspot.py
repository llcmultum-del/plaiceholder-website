"""HubSpot CRM (companies, contacts, notes, tickets) via a Private App token.

Client needs: a HubSpot Private App with scopes
  crm.objects.companies.read/write, crm.objects.contacts.read/write,
  crm.schemas.companies.read/write, crm.schemas.contacts.read/write,
  tickets (only if used as the help desk).
Key: HUBSPOT_TOKEN
"""
from __future__ import annotations

import time

from ..checks import norm_domain
from ..http import Http
from .base import CRM, Helpdesk

OBJ = {"company": "companies", "contact": "contacts"}
STD_COMPANY = {"name": "name", "domain": "domain"}
STD_CONTACT = {"first_name": "firstname", "last_name": "lastname", "email": "email",
               "title": "jobtitle", "linkedin_url": "hs_linkedin_url"}
TYPE_MAP = {
    "number": ("number", "number"),
    "text": ("string", "text"),
    "textarea": ("string", "textarea"),
    "date": ("date", "date"),
    "select": ("enumeration", "select"),
}
GROUP = "ai_agents"


def _hs_props(props: dict, std: dict) -> dict:
    out = {}
    for k, v in props.items():
        if k == "id":
            continue
        if isinstance(v, list):
            v = "\n".join(map(str, v))
        out[std.get(k, k)] = "" if v is None else v
    return out


def _from_hs(obj: dict, std: dict) -> dict:
    rev = {v: k for k, v in std.items()}
    props = obj.get("properties", {}) or {}
    rec = {"id": str(obj.get("id"))}
    for k, v in props.items():
        rec[rev.get(k, k)] = v
    return rec


class HubSpot(CRM, Helpdesk):
    def __init__(self, token: str, settings: dict | None = None):
        s = settings or {}
        self.http = Http("HubSpot", s.get("base_url", "https://api.hubapi.com"),
                         headers={"Authorization": f"Bearer {token}", "Content-Type": "application/json"})

    def ping(self):
        r = self.http.get("/crm/v3/objects/companies", params={"limit": 1})
        return f"HubSpot OK ({len(r.get('results', []))} company visible on first page)"

    # --- fields -------------------------------------------------------------
    def ensure_fields(self, object_type, fields):
        obj = OBJ[object_type]
        if self.http.get(f"/crm/v3/properties/{obj}/groups/{GROUP}", ok_404=True) is None:
            self.http.post(f"/crm/v3/properties/{obj}/groups",
                           json={"name": GROUP, "label": "AI Agents", "displayOrder": -1})
        created = []
        for f in fields:
            if self.http.get(f"/crm/v3/properties/{obj}/{f['name']}", ok_404=True) is not None:
                continue
            ptype, ftype = TYPE_MAP[f.get("type", "text")]
            body = {"name": f["name"], "label": f.get("label", f["name"]), "type": ptype,
                    "fieldType": ftype, "groupName": GROUP, "description": f.get("description", "")}
            if ptype == "enumeration":
                body["options"] = [{"label": o, "value": o, "displayOrder": i}
                                   for i, o in enumerate(f.get("options", []))]
            self.http.post(f"/crm/v3/properties/{obj}", json=body)
            created.append(f["name"])
        return created

    # --- companies ----------------------------------------------------------
    def _search(self, obj, filters, props, limit=100, after=None):
        body = {"filterGroups": [{"filters": filters}] if filters else [],
                "properties": props, "limit": min(limit, 100)}
        if after:
            body["after"] = after
        return self.http.post(f"/crm/v3/objects/{obj}/search", json=body)

    def find_company_by_domain(self, domain):
        d = norm_domain(domain)
        r = self._search("companies", [{"propertyName": "domain", "operator": "EQ", "value": d}],
                         ["name", "domain"], limit=1)
        res = r.get("results", [])
        return _from_hs(res[0], STD_COMPANY) if res else None

    def get_company(self, company_id, fields=None):
        params = {"properties": ",".join(["name", "domain"] + list(fields or []))}
        r = self.http.get(f"/crm/v3/objects/companies/{company_id}", params=params, ok_404=True)
        return _from_hs(r, STD_COMPANY) if r else None

    def create_company(self, props):
        r = self.http.post("/crm/v3/objects/companies", json={"properties": _hs_props(props, STD_COMPANY)})
        return str(r["id"])

    def update_company(self, company_id, props):
        self.http.patch(f"/crm/v3/objects/companies/{company_id}",
                        json={"properties": _hs_props(props, STD_COMPANY)})

    def list_companies(self, fields, date_field=None, date_from=None, date_to=None, limit=1000):
        filters = []
        if date_field:
            # HubSpot date properties filter on epoch milliseconds at midnight UTC
            filters.append({"propertyName": date_field, "operator": "BETWEEN",
                            "value": _ms(date_from), "highValue": _ms(date_to)})
        props = ["name", "domain"] + list(fields)
        out, after = [], None
        while len(out) < limit:
            r = self._search("companies", filters, props, limit=100, after=after)
            out += [_from_hs(o, STD_COMPANY) for o in r.get("results", [])]
            after = (r.get("paging") or {}).get("next", {}).get("after")
            if not after:
                break
            time.sleep(0.2)  # search endpoint is limited to a few requests per second
        return out[:limit]

    # --- contacts -----------------------------------------------------------
    def find_contact_by_email(self, email):
        r = self._search("contacts", [{"propertyName": "email", "operator": "EQ", "value": email}],
                         ["email", "firstname", "lastname"], limit=1)
        res = r.get("results", [])
        return _from_hs(res[0], STD_CONTACT) if res else None

    def create_contact(self, props, company_id=None):
        r = self.http.post("/crm/v3/objects/contacts", json={"properties": _hs_props(props, STD_CONTACT)})
        cid = str(r["id"])
        if company_id:
            self.http.put(f"/crm/v4/objects/contacts/{cid}/associations/default/companies/{company_id}")
        return cid

    # --- notes --------------------------------------------------------------
    def _associated(self, from_obj, from_id, to_obj, limit):
        r = self.http.get(f"/crm/v4/objects/{from_obj}/{from_id}/associations/{to_obj}",
                          params={"limit": min(limit, 500)})
        return [str(x["toObjectId"]) for x in r.get("results", [])][:limit]

    def company_notes(self, company_id, limit=20):
        ids = self._associated("companies", company_id, "notes", limit)
        if not ids:
            return []
        r = self.http.post("/crm/v3/objects/notes/batch/read", json={
            "properties": ["hs_note_body", "hs_timestamp"], "inputs": [{"id": i} for i in ids]})
        return [{"id": str(o["id"]), "date": o["properties"].get("hs_timestamp"),
                 "body": o["properties"].get("hs_note_body", "")} for o in r.get("results", [])]

    def add_note(self, company_id, body):
        r = self.http.post("/crm/v3/objects/notes", json={
            "properties": {"hs_note_body": body, "hs_timestamp": int(time.time() * 1000)},
            "associations": [{"to": {"id": company_id},
                              "types": [{"associationCategory": "HUBSPOT_DEFINED", "associationTypeId": 190}]}],
        })
        return str(r["id"])

    # --- tickets (HubSpot as the help desk) ---------------------------------
    def tickets_for_company(self, company, since_days=180, limit=50):
        ids = self._associated("companies", company["id"], "tickets", limit)
        if not ids:
            return []
        r = self.http.post("/crm/v3/objects/tickets/batch/read", json={
            "properties": ["subject", "content", "hs_pipeline_stage", "hs_ticket_priority",
                           "createdate", "hs_lastmodifieddate"],
            "inputs": [{"id": i} for i in ids]})
        out = []
        for o in r.get("results", []):
            p = o.get("properties", {})
            out.append({"id": str(o["id"]), "subject": p.get("subject", ""),
                        "description": p.get("content", ""), "status": p.get("hs_pipeline_stage"),
                        "priority": p.get("hs_ticket_priority"), "created_at": p.get("createdate"),
                        "updated_at": p.get("hs_lastmodifieddate")})
        return out


def _ms(d):
    from datetime import datetime, timezone
    from ..checks import parse_date
    dt = parse_date(d)
    return str(int(datetime(dt.year, dt.month, dt.day, tzinfo=timezone.utc).timestamp() * 1000))
