"""Slack alerts through an Incoming Webhook (one channel per webhook).

Key: SLACK_WEBHOOK_URL (api.slack.com/apps > your app > Incoming Webhooks)
"""
from __future__ import annotations

from ..http import Http
from .base import Notifier


class Slack(Notifier):
    def __init__(self, webhook_url: str, settings: dict | None = None):
        self.url = webhook_url
        self.http = Http("Slack", webhook_url)

    def ping(self):
        # Webhooks have no read-only check; sending is the only test.
        return "Slack webhook configured (send a test with: kit.py check <client> --send-test)"

    def send(self, text):
        self.http.post(self.url, json={"text": text})
