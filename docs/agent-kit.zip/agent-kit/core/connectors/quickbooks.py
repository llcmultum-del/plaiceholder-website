"""QuickBooks Online bills (vendor invoices), purchase orders and vendors.  BETA.

Keys: QUICKBOOKS_ACCESS_TOKEN, QUICKBOOKS_REALM_ID
Getting a token needs an Intuit developer app and the OAuth flow (Intuit's OAuth
Playground works for a pilot). Access tokens last one hour; for production, add a
refresh-token step or use CSV exports instead.
"""
from __future__ import annotations

from ..http import Http
from .base import Accounting


class QuickBooks(Accounting):
    def __init__(self, token: str, realm_id: str, settings: dict | None = None):
        s = settings or {}
        base = s.get("base_url", "https://quickbooks.api.intuit.com")
        self.http = Http("QuickBooks", f"{base}/v3/company/{realm_id}",
                         headers={"Authorization": f"Bearer {token}", "Accept": "application/json"})
        self.minor = s.get("minorversion", "75")

    def _query(self, q: str) -> list[dict]:
        out, start = [], 1
        entity = q.split(" from ")[1].split()[0]
        while True:
            r = self.http.get("/query", params={"query": f"{q} STARTPOSITION {start} MAXRESULTS 500",
                                                "minorversion": self.minor})
            rows = (r.get("QueryResponse") or {}).get(entity, [])
            out += rows
            if len(rows) < 500:
                return out
            start += 500

    def ping(self):
        r = self.http.get("/companyinfo/" + self.http.base_url.rsplit("/", 1)[-1],
                          params={"minorversion": self.minor})
        return f"QuickBooks OK ({(r.get('CompanyInfo') or {}).get('CompanyName')})"

    @staticmethod
    def _lines(doc):
        out = []
        for ln in doc.get("Line", []):
            det = ln.get("ItemBasedExpenseLineDetail") or {}
            if det:
                out.append({"sku": (det.get("ItemRef") or {}).get("name", ""), "description": ln.get("Description", ""),
                            "qty": float(det.get("Qty") or 0), "unit_price": float(det.get("UnitPrice") or 0)})
            elif ln.get("Amount"):
                out.append({"sku": "", "description": ln.get("Description", ""), "qty": 1.0,
                            "unit_price": float(ln["Amount"])})
        return out

    def list_invoices(self, since=None):
        q = "select * from Bill"
        if since:
            q += f" where TxnDate >= '{since}'"
        out = []
        for b in self._query(q):
            po = ""
            for lt in b.get("LinkedTxn", []):
                if lt.get("TxnType") == "PurchaseOrder":
                    po = lt.get("TxnId", "")
            out.append({"id": f"INV:{b['Id']}", "number": b.get("DocNumber") or b["Id"],
                        "vendor": (b.get("VendorRef") or {}).get("name", ""), "date": b.get("TxnDate"),
                        "po_number": po, "amount": float(b.get("TotalAmt") or 0), "lines": self._lines(b)})
        return out

    def list_purchase_orders(self):
        return [{"id": f"PO:{p['Id']}", "number": p["Id"], "vendor": (p.get("VendorRef") or {}).get("name", ""),
                 "date": p.get("TxnDate"), "po_number": p["Id"], "amount": float(p.get("TotalAmt") or 0),
                 "lines": self._lines(p)} for p in self._query("select * from PurchaseOrder")]

    def list_vendors(self):
        return [{"vendor": v.get("DisplayName"), "approved": bool(v.get("Active", True))}
                for v in self._query("select * from Vendor")]
