"""Zendesk Support tickets, matched to a CRM company by organization domain or name.

Keys: ZENDESK_EMAIL, ZENDESK_TOKEN (Admin Center > Apps and integrations > Zendesk API)
Settings: connector_settings.zendesk.subdomain  (the 'acme' in acme.zendesk.com)
"""
from __future__ import annotations

from ..checks import norm_domain
from ..http import Http
from .base import Helpdesk


class Zendesk(Helpdesk):
    def __init__(self, email: str, token: str, settings: dict):
        base = settings.get("base_url") or f"https://{settings['subdomain']}.zendesk.com"
        self.http = Http("Zendesk", base, auth=(f"{email}/token", token))
        self._orgs: dict[str, str | None] = {}

    def ping(self):
        r = self.http.get("/api/v2/users/me.json")
        return f"Zendesk OK (signed in as {r.get('user', {}).get('email')})"

    def _org_id(self, company):
        key = norm_domain(company.get("domain", "")) or company.get("name", "")
        if key in self._orgs:
            return self._orgs[key]
        org_id = None
        dom = norm_domain(company.get("domain", ""))
        if dom:
            r = self.http.get("/api/v2/search.json", params={"query": f"type:organization {dom}"})
            for o in r.get("results", []):
                if dom in [norm_domain(d) for d in o.get("domain_names", [])]:
                    org_id = o["id"]
                    break
        if not org_id and company.get("name"):
            r = self.http.get("/api/v2/organizations/autocomplete.json", params={"name": company["name"]})
            orgs = r.get("organizations", [])
            if orgs:
                org_id = orgs[0]["id"]
        self._orgs[key] = org_id
        return org_id

    def tickets_for_company(self, company, since_days=180, limit=50):
        org = self._org_id(company)
        if not org:
            return []
        r = self.http.get("/api/v2/search.json", params={
            "query": f"type:ticket organization:{org} created>{since_days}days",
            "sort_by": "created_at", "sort_order": "desc", "per_page": min(limit, 100)})
        return [{"id": str(t["id"]), "subject": t.get("subject"), "description": (t.get("description") or "")[:2000],
                 "status": t.get("status"), "priority": t.get("priority"),
                 "created_at": t.get("created_at"), "updated_at": t.get("updated_at"),
                 "satisfaction": (t.get("satisfaction_rating") or {}).get("score")}
                for t in r.get("results", [])][:limit]
