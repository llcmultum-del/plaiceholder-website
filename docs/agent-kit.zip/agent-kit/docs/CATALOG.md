# Catalog: 13 preset agents

Built = template in `agents/`, demo and tests included. Spec = build with `/agent-new`,
reusing the listed core pieces. Prices: see the Agent Catalog and Pricing Playbook doc.

| Agent | Area | Tier | Status | Reuses from core | Notes for building |
| --- | --- | --- | --- | --- | --- |
| Signal Prospector | Sales | Advanced | Built | crm, enrichment, llm batch + web search, verify_sources, scoring | - |
| Inbound Lead Researcher | Sales | Standard | Spec | crm (new: list recently created contacts/companies), llm web search, scoring | Trigger on leads created since last run; write fit score + draft reply as a note; never send email |
| CRM Hygiene | Sales | Starter | Spec | crm list_companies, norm_domain | Mostly rules (dupes by domain/email, missing fields, stale deals); Claude only for fuzzy duplicates; write = proposed fixes list, apply only approved rows |
| Deal Follow-up Drafter | Sales | Standard | Spec | crm (new: deals + last activities), llm | New connector: Gmail/Outlook drafts (draft only, never send) |
| Meeting Prep Briefs | Sales | Starter | Spec | crm, llm web search, notify | New connector: calendar (Google/Microsoft); run hourly via scheduler |
| Renewal Risk Radar | Customer success | Standard | Built | crm, helpdesk, notify, verify_evidence | - |
| Support Ticket Triage | Customer success | Starter | Spec | helpdesk (new: update tags/priority, internal note), llm | Write tags + internal-note draft only; categories from interview |
| Customer Onboarding Tracker | Customer success | Starter | Spec | crm, helpdesk, notify | Rules on onboarding checklist fields; Claude summarizes blockers |
| Invoice Checker | Back office | Standard | Built | accounting (csv, quickbooks), notify | - |
| Resume Screener | Back office | Standard | Spec | csv source, llm, verify_evidence | Summarize vs must-haves with quoted evidence; never auto-reject; check local AI-hiring rules (e.g. NYC Local Law 144) |
| Weekly KPI Writer | Back office | Starter | Spec | crm, csv, notify | Numbers computed in code; Claude only writes the narrative around them |
| Competitor Watch | Marketing | Starter | Spec | llm web search, verify_sources, notify | Store last week's findings in runs/ to report only what changed |
| RFP and Questionnaire Drafter | Marketing | Advanced | Spec | llm, verify_evidence | Answer library as CSV/docs; every answer cites a library entry; output a .docx/markdown for review |
