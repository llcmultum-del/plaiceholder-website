# SOP-02: Building an agent (catalog or custom)

**Goal:** "this agent, for this company, connected to these platforms" becomes a tested delivery with one command.

## The model: one builder, many templates
We use **one builder** (`kit.py build`, or `/agent-build` in Claude Code), not a separate builder agent per agent type.

- **Templates hold the specialization.** Each catalog agent is a template in `agents/`: its steps, prompts, checks, scoring, chat-mode spec, interview and sample data.
- **The builder holds the process.** It sets up the client, connects tools, pins the template, tests and packages the same way for every agent.
- **Why not one builder per type:** 13 builders would drift apart, and every process improvement would have to be made 13 times. With one builder, a fix to testing or packaging improves every agent at once.
- **Custom agents** become a new template first (`/agent-new`), then go through the same builder. Many "custom" requests are a catalog template with different settings, so check that first.

## Inputs
| You need | Example |
|---|---|
| Agent template | `signal-prospector` (`python kit.py list`) |
| Client folder name | `acme` (lowercase, dashes, never starting with `_`) |
| Their tools | `hubspot,apollo` (also: salesforce, zendesk, slack, quickbooks, csv) |
| Their AI platform | `chatgpt` (also: claude, perplexity, grok, gemini, copilot) |

## Steps
1. **Build** (Claude Code: `/agent-build signal-prospector for acme using hubspot, apollo on chatgpt`):
   ```
   python kit.py build acme signal-prospector --platforms hubspot,apollo --ai chatgpt --name "Acme Corp"
   ```
   If it says **BLOCKED**, read the FAIL line. The usual cause is an AI platform that can't do something the
   agent needs: for example, Gemini can't run web-search research in automated mode. Pick another platform for
   the automated runtime, or deliver chat mode only.
2. **Keys:** follow SOP-01 step 4, then `python kit.py check acme`.
3. **Tune:** `/agent-tune acme signal-prospector`, the discovery interview. Answers go only to
   `clients/acme/agents/signal-prospector.yaml`.
4. **Prompt test:** `python kit.py test-prompt acme signal-prospector <a domain they know>`. It costs a few cents; walk through what was kept and thrown out.
5. **Rebuild after tuning:** `python kit.py build acme signal-prospector --note "Tuned from discovery"`. The status should now be READY, or READY FOR SETUP only because chat mode doesn't need keys.
6. **Pilot:** SOP-04.
7. **Deliver:** SOP-05.

## Custom agent (not in the catalog)
1. Write a one-paragraph spec: the job, tools in and out, what a person must approve, and what a wrong answer looks like.
2. Check whether an existing template with new settings would do. If so, use that.
3. Otherwise run `/agent-new <name> "<what it does>"`. Claude Code copies the closest template and adds a
   `fake_responder`, sample data, a `portable.md.j2` chat-mode spec and an end-to-end test.
4. Run `python tests/run_tests.py` until it passes, and `python kit.py demo <name>` to see the dashboard.
5. Then build for the client from step 1 above.
6. Price it: tier price plus $1,000 to $3,000 for the new template. It joins the catalog for the next client.

## Rules
- Never edit `agents/` (shared templates) to suit one client. Client-specific changes go in that client's settings file.
- Never pass `--force` unless you've read the failure and the client agrees in writing.
