# SOP-04: Testing and QA

**Rule:** nothing goes to a client without a test report, and nothing goes live without a pilot.

## The four layers
| Layer | What it proves | How |
|---|---|---|
| 1. Kit tests | Code, connectors and AI platform adapters work as documented | `python tests/run_tests.py` (after any code change; all must pass) |
| 2. Build tests | This client's configuration, tuned settings and chat files work | Automatic in `kit.py build`, written to `TEST_REPORT.md` |
| 3. Live trial check | Real accounts accept our calls | Our own trial accounts, once per connector or platform, before the first client uses it |
| 4. Client pilot | The agent is useful for this client | 20 records, reviewed by the client |

## Build test checks (TEST_REPORT.md)
- Configuration and AI platform fit (FAIL blocks delivery)
- Client keys present (WARN until the client adds them)
- Settings tuned, with no placeholders (WARN until `/agent-tune`)
- End-to-end run on sample data with the client's settings and pinned template (FAIL blocks)
- Portable AGENT.md renders, the short version fits, and the core sections are present (FAIL blocks)
- Secrets scan: no key value anywhere in the delivery (the build is deleted if one is found)

## Live trial checklist (once per connector or platform)
- [ ] HubSpot developer test account · [ ] Salesforce Developer Edition · [ ] Apollo trial · [ ] Zendesk trial
- [ ] Slack test workspace webhook · [ ] QuickBooks sandbox
- [ ] AI platforms in use: Anthropic, OpenAI, Perplexity, xAI, Google (about $5 of credit each)
- For each: `kit.py check`, then `kit.py run <test-client> <agent> --limit 5 --live`. Fix anything, add a stub test, and record the date here.

## Pilot (per client)
1. `python kit.py run <client> <agent> --limit 20` (dry run), then add `--live` and approve each step.
2. The client's reviewer marks each of the top 10 results useful or not useful.
3. Check every finding links to its source or evidence, and look at the verify audit file.
4. Time 10 records done the old way against reviewing the agent's output. Record the minutes per record.
5. Record the usage cost per record from the run summary.
6. Accept against the SOW criteria, or tune and re-pilot once.

## Record the result (it's your case study)
| Client | Agent | Records | Useful (top 10) | Minutes/record before → after | Cost/record | Date |
|---|---|---|---|---|---|---|
