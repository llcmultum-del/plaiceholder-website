# SOP-07: Offboarding (cancellation or non-payment)

**Principle:** we never switch off or delete anything in a client's systems. Their license survives (once the
launch package is paid). What ends is our service and our access.

## Case A: the client cancels the care plan (30 days' notice)
1. Acknowledge in writing: the end date, that the agent stays theirs to use internally, and what's no longer
   covered (monitoring, fixes when tools change, tuning, model moves).
2. Offer the alternatives once, without pressure: annual prepay (2 months free), a lower tier, or on-call help at $125/hour.
3. On the end date: `python kit.py care <client> --status ended`. It prints this checklist:
   - [ ] Ask the client to revoke the care-plan credential, and confirm it's done
   - [ ] Delete `clients/<client>/.env`, `runs/` and any exports
   - [ ] Resend the latest delivery zip and handover notes
   - [ ] Remind them of the hourly and reactivation rates
   - [ ] Keep `clients/<client>/` settings, pinned template and delivery history (no client data) for a fast reactivation
4. Calendar a friendly check-in for 90 days later. A tool change has often broken something by then.

## Case B: care plan invoice unpaid
| Days late | Action |
|---|---|
| 1 | Automatic reminder |
| 7 | Personal email |
| 15 | Care services paused (per Care Plan Terms). Written notice; the agent keeps running |
| 30 | Care plan ended, then Case A steps 3 and 4. Unpaid amounts go to normal collections |

We don't disable the agent for an unpaid care plan. It's a service, not a license.

## Case C: launch package unpaid after delivery
1. Reminders on day 1, 7 and 15.
2. Day 30: formal written notice that no license was granted (MSA 3.4), and that they must stop using and delete the agent within 10 days.
3. Revoke any access we still hold. Don't access their systems to delete anything yourself.
4. If unresolved, take it to an attorney or small-claims court. The signed MSA/SOW and the delivery MANIFEST (dates, versions) are your evidence.

## Reactivation
1. The client pays the reactivation fee ($500 / $750 / $1,000) and restarts the care plan.
2. They create a new care credential, and you run `kit.py check`.
3. `python kit.py upgrade <client> <agent>` (if templates moved on), then `build --note "Reactivation"`, then a short re-pilot.
4. `python kit.py care <client> --status active`.
