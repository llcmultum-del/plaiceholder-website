# SOP-05: Delivery and handover

**Goal:** the client owns a working agent, knows how to use it, and has moved onto the care plan.

## How we sell and maintain an agent we hand over
We hand over the agent: the client keeps the files and runs them in their own accounts. We can't lock a copy
of plain files, and we don't try to. Three things protect the business instead:

1. **The license (legal).** The MSA grants an internal-use license once the launch package is paid. No resale,
   no sharing, no competing use. If the launch package isn't paid, there's no license. Enforcement is contractual, like any software license.
2. **The service (value).** What keeps clients paying is the care plan, not access to the files. Tools and AI
   models change every few months and agents slowly break or drift. The care plan includes monitoring, fixes,
   model moves, tuning, a monthly results report and the fix guarantee.
3. **Being the easiest path.** Settings history, the pinned template, versioned deliveries and our test setup
   make us much faster at fixing their agent than anyone else would be.

## Steps
1. **Final build:** `python kit.py build <client> <agent> --note "Pilot accepted"`. The status must be READY.
2. **Send the delivery zip:** `deliveries/<client>/<agent>/<client>-<agent>-vN.zip`, by a shared drive link or an email attachment.
   It contains no keys.
3. **Install with them (30-minute training call):**
   - Chat mode: open `platforms/<their platform>.md`, follow the steps, paste the block, attach AGENT.md, and run a real example.
   - Automated mode: they unzip `runtime/`, add keys (`set-key`), run `check`, then the schedule or `/agent-run`.
   - Show the dashboard, how to read it, and what needs a person's approval.
4. **Remove our setup access:** delete `clients/<client>/.env` and `runs/` and any local exports. Ask the client to
   rotate any key we used during the build.
5. **Set up care access:** the client creates a separate, limited credential for care work (for example a dedicated
   integration user). Store it encrypted. They can revoke it at any time.
6. **Send the handover email** (template below) and the second 50% invoice.
7. **Set the care plan's month-4 start date:** `python kit.py care <client> --status active --since <handover date>`.

## Handover email
> Subject: Your [Agent] is live: results and next steps
>
> Hi [Name],
> - **Pilot result:** [X of 10 useful], [minutes before → after] per record, ~$[cost] per record in AI usage.
> - **Your files:** [link]. Start with README.md. They're yours to use internally under our agreement.
> - **Care plan:** months 1 to 3 are included. I'll send your first results report on [date]. From month 4 it's $[fee]/mo, cancel anytime with 30 days' notice.
> - **Access:** I've removed my setup access. Please send the limited care-plan login when you can (steps attached).
>
> Thanks, [Founder Name]

## Done when
- [ ] Client ran the agent themselves once
- [ ] Our setup keys and data deleted; the client confirmed key rotation
- [ ] Care credential received
- [ ] Final invoice sent; testimonial requested (founding clients)
