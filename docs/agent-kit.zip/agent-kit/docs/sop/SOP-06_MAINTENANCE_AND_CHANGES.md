# SOP-06: Maintenance, edits and versioning

**Goal:** change one client's agent quickly without ever touching another client's.

## How the files are organized
```
agents/<agent>/                      shared templates (the catalog). Only changed on purpose, with tests.
clients/<client>/
    client.yaml                      tools, AI platform, care plan, delivery history
    .env                             care-plan credential only (never shared)
    agents/<agent>.yaml              THIS client's tuned settings  ← most edits happen here
    pinned/<agent>/                  THIS client's private copy of the template (frozen at their version)
    runs/                            logs (deleted at handover)
deliveries/<client>/<agent>/
    v1/ v2/ v3/ …                    immutable deliveries; never edited
    CHANGELOG.md                     what changed in each version
    <client>-<agent>-vN.zip          the file you send
```

### The four safety rules
1. **Every command names one client.** `build`, `run`, `diff`, `upgrade` and `care` only touch that client's folders.
2. **Pinned templates.** Each client runs its own frozen copy of the template, so improving a shared template
   never changes a delivered client by accident.
3. **Immutable versions.** A change is a new version (vN+1) with a changelog note. The previous version stays for rollback.
4. **Tests on every build.** A rebuild re-runs the full sample-data test with that client's settings before anything is delivered.

## Monthly care routine (per client, about 30 to 60 minutes)
The agent runs in the client's systems, so monitoring comes from three places:
1. **Health check with the care credential:** `python kit.py check <client>`, then a dry run on 5 records:
   `python kit.py run <client> <agent> --limit 5`. A dry run reads live data but writes and spends nothing,
   and confirms their tools still answer and every step still works.
2. **Their run summaries:** ask clients on automated mode to add your email to the agent's Slack channel, or forward
   the run summary. Look for failures, rising cost per record, and a jump in thrown-out findings in the verify audit
   (a sign of drift).
3. **Chat-mode clients:** run the 3-record same-result check (SOP-03 step 5) on their platform with sample data.

Then:
4. Send the monthly results email: what ran, key findings, cost per record, anything fixed.
5. Note any tuning requests and use the plan's tuning hours.

## Making a change for one client
Claude Code: `/agent-edit <client> <agent> "<what to change>"`. By hand:
1. Edit **only** `clients/<client>/agents/<agent>.yaml`. Only edit `clients/<client>/pinned/<agent>/` if a setting can't express the change.
2. `python kit.py build <client> <agent> --note "<what changed>"` creates vN+1, tested.
3. `python kit.py diff <client> <agent>` shows exactly what changed. Check that only what you intended changed.
4. Send the new zip. Chat mode: they replace the instructions block and AGENT.md. Automated: they replace the runtime folder and keep their `.env`.
5. **Rollback:** resend the previous version's zip.

## When a tool or AI model changes (the fix guarantee: 5 business days)
1. Reproduce it on a test client, then fix it in `core/` (connectors, AI adapters) and add a stub test. Run `python tests/run_tests.py`.
2. `core/` fixes reach clients when you rebuild them: `python kit.py build <client> <agent> --note "Fix: <tool> change"`.
   Rebuild every affected client with an active care plan (`python kit.py clients` lists who uses what).
3. Model retired? Update `llm.model` in each affected client's `client.yaml`, rebuild, and re-run the same-result check (SOP-03 step 5).

## Improving a shared template (all future clients)
1. Change `agents/<agent>/`, bump `version` in its `agent.yaml`, and run the tests.
2. Existing clients don't change. For each one who should get it: `python kit.py upgrade <client> <agent>` (preview), then
   `--apply` (keeps a backup and their settings), then `build --note "Upgrade to template vX"`.
3. Clients without a care plan stay on their version unless they pay for the upgrade.

## Never
- Edit a delivered `vN` folder.
- Change shared templates to fix one client.
- Run commands on a client folder you didn't name.
