# SOP-01: Client onboarding (signed → ready to build)

**Goal:** everything needed to build is in hand within 2 business days of signing.
**Owner:** Founder · **Time:** about 1 hour of your time

## Trigger
MSA and SOW signed, first 50% invoice paid.

## Steps
1. **Create the client record**
   `python kit.py build <client> <agent> --platforms <tools> --ai <platform> --name "<Client Name>"`
   This creates `clients/<client>/`, pins the template, and produces a first sample-data build (status READY FOR SETUP). The build confirms the agent fits their tools and AI platform before you go further.
2. **Record the care plan:** `python kit.py care <client> --status active --tier <tier> --monthly <fee> --since <kickoff date>`.
3. **Send the kickoff email** (template below) with:
   - the list of keys to create, from the build's `.env.example`, with links to `docs/KEYS.md` steps
   - the discovery interview invite (1 hour, the people who do the task)
   - the pilot reviewer request (who checks the top 10 results)
4. **Collect keys safely.** The client creates each key in their own account. You enter it with
   `python kit.py set-key <client> <KEY>` (hidden typing) during a screen share, or the client enters it themselves.
   Never accept keys by email or chat.
5. **Confirm AI platform terms.** Note in the SOW notes which AI platform and plan they use, and whether its
   business/API terms exclude training on their data.
6. **Run the connection check:** `python kit.py check <client>` until every line says ok (placeholder warnings are expected until tuning).
7. **Book the discovery interview** and run it with `/agent-tune <client> <agent>` (see SOP-02 step 3).

## Kickoff email template
> Subject: Kickoff: your [Agent] with PlAIceholder
>
> Hi [Name], thanks for signing on. Three things get us moving:
> 1. **Access:** please create these keys in your accounts: [list]. Steps for each are attached. We'll enter them together on a 10-minute call; please don't email them.
> 2. **Discovery (1 hour):** [date options] with [the people who do the task]. We'll ask how you do it today; your answers become the agent's settings.
> 3. **Pilot reviewer:** who should check the first 20 results?
>
> Target: pilot results by [date], handover by [date]. [Founder Name]

## Done when
- [ ] `kit.py check` passes for every connection
- [ ] Discovery booked, pilot reviewer named
- [ ] Care plan recorded
