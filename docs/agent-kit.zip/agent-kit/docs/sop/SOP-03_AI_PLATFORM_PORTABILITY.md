# SOP-03: Delivering on the client's own AI platform

**Goal:** an agent built with Claude works the same in ChatGPT, Perplexity, Grok, Gemini or Copilot, so the client doesn't need a new AI subscription.

## How portability works
Every agent has **one source of truth**: the template plus the client's tuned settings. The builder turns that into:

| File (in the delivery) | Use it for |
|---|---|
| `AGENT.md` | The full portable spec: role, inputs, procedure, rules, scoring, output format, when to stop. Plain markdown that any AI reads. |
| `platforms/claude-project.md` | Claude Project instructions (+ attach AGENT.md) |
| `platforms/claude-skill/SKILL.md` | Claude skill (Claude Code / Claude apps) |
| `platforms/chatgpt.md` | ChatGPT custom GPT or Project instructions (under 8,000 characters) + attach AGENT.md |
| `platforms/perplexity.md` | Perplexity Space instructions + attach AGENT.md |
| `platforms/grok.md` | Grok project / custom instructions + attach AGENT.md |
| `platforms/gemini.md` | Gemini Gem instructions + attach AGENT.md |
| `platforms/copilot.md` | Microsoft Copilot Studio agent instructions (under 8,000 characters) + knowledge |
| `platforms/api-system-prompt.md` | Developers: system prompt for any AI API |
| `runtime/` | Automated mode, using the client's AI platform's API key |

Each platform file starts with setup steps, then a "copy everything below this line" block. The short version is
kept under 7,500 characters, so it fits the instruction boxes on platforms with limits. The full spec rides along as AGENT.md.

## Two modes, and what each platform can do

| Platform | Chat mode | Automated mode (runtime) | Notes |
|---|---|---|---|
| Claude | ✓ | ✓ with web search, Batch API at half price | Default; cheapest for large research runs |
| ChatGPT (OpenAI) | ✓ | ✓ with web search | No batch discount in the kit; tasks run one by one |
| Perplexity | ✓ | ✓, always searches; returns citations | Best fit for research agents |
| Grok (xAI) | ✓ | ✓ with live search citations | Confirm search options in the live test |
| Gemini (Google) | ✓ (turn on Google Search in the Gem for research) | ✓ for non-research agents only | The builder blocks research agents on Gemini automated mode |
| Copilot | ✓ | ✗ (chat files only) | Runtime uses another platform if automation is needed |

**Chat mode** means a person gives the agent data (paste, attach, or the platform's own connectors to their CRM)
and reads the results. **Automated mode** runs on a schedule, reads from and writes back to their tools, and needs an API key.

## Steps
1. At kickoff, ask: "Which AI tool does your team already pay for, and do they want chat, automation, or both?"
2. Build with that platform: `--ai chatgpt` (or claude, perplexity, grok, gemini, copilot). The builder sets the runtime
   provider, clears the old model name, and blocks combinations that can't work.
3. Set the current model name for automated mode in `clients/<client>/client.yaml` under `llm.model`. Model names
   change; check the provider's model list. Defaults: Claude `claude-sonnet-5-5`, ChatGPT `gpt-5`, Perplexity `sonar-pro`,
   Grok `grok-4`, Gemini `gemini-2.5-pro`.
4. **Chat-mode install (on a screen share, 10 minutes):** open the platform file, follow its steps, paste the block, attach AGENT.md,
   turn on web search or data analysis as the file says, then run one real example together.
5. **Same-result check:** run 3 records in chat mode and the same 3 in automated mode (or the sample in AGENT.md).
   The scores and flags should match closely. Big gaps mean a platform setting (search off, file not attached) or a model that's too small.
6. Record the platform and model in the SOW notes. Rebuild with `--note` if anything changed.

## Writing templates that stay portable (for new agents)
- Use plain markdown only: headings, lists, tables, one fenced JSON block. No XML tags or tool-specific syntax.
- Fixed sections: **Your role · What you work on · Procedure · Rules you must follow · Scoring · Output format · Stop and ask a person when**. The builder fails a spec missing the core sections.
- Write rules as testable sentences ("No source, no signal"), not vibes.
- Never rely on a feature only one platform has. Say "if you can run code, use it for math" rather than naming a tool.
- Keep the short version under 7,500 characters. Long reference material (talk tracks, examples) goes in the full version only.
- Give an example input and output in the full version. It's the best way to make different models agree.

## Limits to tell clients plainly
- Different models give somewhat different wording and borderline scores. The rules and checks keep the results consistent, not identical.
- Chat mode depends on the person attaching the right data, and on the platform's search being turned on.
- Model names and platform menus change. The care plan covers re-testing when they do.
