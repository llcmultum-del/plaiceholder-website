# Where to get each key

The client creates every key in their own account and types it in with
`python kit.py set-key <client> <KEY>` (typing is hidden). At handover they rotate
the keys, and you delete any copies.

| Key | Where | Notes |
| --- | --- | --- |
| `ANTHROPIC_API_KEY` | console.anthropic.com → API Keys | Claude. Client's own account and billing. Set a monthly spend limit. |
| `OPENAI_API_KEY` | platform.openai.com → API keys | ChatGPT models. API billing is separate from ChatGPT subscriptions. Set a usage limit. |
| `PERPLEXITY_API_KEY` | Perplexity → Settings → API | Sonar models; always searches the web. |
| `XAI_API_KEY` | console.x.ai → API keys | Grok models. Confirm live search options during the live test. |
| `GEMINI_API_KEY` | Google AI Studio → Get API key | Gemini models. Not for research agents in automated mode (no web search through this kit). |
| `HUBSPOT_TOKEN` | HubSpot → Settings → Integrations → Private Apps → Create | Scopes: `crm.objects.companies.read/write`, `crm.objects.contacts.read/write`, `crm.schemas.companies.read/write`, `crm.schemas.contacts.read/write`; add `tickets` for Renewal Risk with HubSpot tickets. Super admin needed. |
| `SALESFORCE_CLIENT_ID` / `SALESFORCE_CLIENT_SECRET` | Setup → External Client App Manager (or App Manager → Connected App) → enable OAuth, "Client Credentials Flow", pick a Run As user | Also set `connector_settings.salesforce.instance_url` (their My Domain URL). After the fields step, the admin adds the new "AI" fields to a permission set for the integration user and reps (Salesforce hides new fields until then). Creating fields needs "Customize Application"; otherwise the admin creates them by hand from the list in `agent.yaml`. |
| `APOLLO_API_KEY` | Apollo → Settings → Integrations → API → Create new key | Must be a **master** key for people search and email reveal. Each revealed email costs a credit; cap it in settings. |
| `ZENDESK_EMAIL` / `ZENDESK_TOKEN` | Admin Center → Apps and integrations → Zendesk API → enable token access → Add API token | Also set `connector_settings.zendesk.subdomain`. Organizations should have domains filled in for matching. |
| `SLACK_WEBHOOK_URL` | api.slack.com/apps → Create app → Incoming Webhooks → Add to the channel | One webhook per channel. Test with `python kit.py check <client> --send-test`. |
| `QUICKBOOKS_ACCESS_TOKEN` / `QUICKBOOKS_REALM_ID` | developer.intuit.com app + OAuth Playground | Beta: tokens last one hour. CSV exports are simpler for pilots. |
