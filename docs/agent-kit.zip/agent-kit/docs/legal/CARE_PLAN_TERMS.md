# Care Plan Terms (Exhibit A, template)

> Template, not legal advice. Review with an attorney before use.

## 1. What the Care Plan is
A monthly service that keeps a delivered Agent working and improving. The Agent itself belongs to
Client under the license in the MSA; the Care Plan is the people and process around it.

## 2. Included each month
| | Starter | Standard | Advanced |
|---|---|---|---|
| Fee (from month 4) | $250 | $450 | $750 |
| Monitoring of runs and costs | ✓ | ✓ | ✓ |
| Monthly results email | ✓ | ✓ | ✓ |
| Fixes when a connected tool or AI model changes | ✓ | ✓ | ✓ |
| Moves to newer AI models when the current one is retired | ✓ | ✓ | ✓ |
| Tuning hours (prompts, scoring, settings) | 1 | 2 | 3 |
| Quarterly tuning call | | ✓ | ✓ |
| Response time | 2 business days | 2 business days | 2 business days |

Unused tuning hours don't roll over.

## 3. Fix guarantee
If a change in a connected third-party tool breaks the Agent, Provider will restore it within 5 business days
of being told (or of detecting it). If Provider misses that, the Care Plan fee for that month is waived.
This doesn't apply when the cause is Client revoking access, an account lapsing, or a third-party outage.

## 4. Access
Client gives Provider a **separate, limited credential** (for example a dedicated integration user or API key)
used only for Care Plan work. Client can revoke it at any time. Provider stores it encrypted and uses it only
for monitoring, fixes and approved changes.

## 5. Not included
New agents or new kinds of tasks, new tool connections, data cleanup, work during third-party outages,
and changes beyond the included tuning hours (billed at $125/hour or quoted).

## 6. Term, cancellation and lapse
- Months 1 to 3 are included in the launch package (6 months committed for founding clients).
- After that, month to month. Either party may cancel with 30 days' written notice.
- Unpaid Care Plan invoices more than 15 days late pause Care Plan services (not the Client's license).
- When the Care Plan ends: Client revokes the Care Plan credential, Provider deletes Client data and keys it holds,
  and the Agent keeps running in Client's systems under the license, without monitoring or fixes.
- **Reactivation:** restarting care after a lapse costs a one-time reactivation fee ($500 / $750 / $1,000 by tier),
  which covers re-testing and repairing the Agent, then the monthly fee resumes.

## 7. Annual prepay
Paying 12 months in advance costs 10 months' fees. Refunds on early cancellation are pro-rated at the monthly rate.
