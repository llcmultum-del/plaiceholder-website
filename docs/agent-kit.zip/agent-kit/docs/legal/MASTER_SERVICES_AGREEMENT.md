# Master Services Agreement (template)

> **Template, not legal advice.** Have a licensed attorney in your state review and adapt
> this before first use. [Bracketed text] is filled in per client.

This Master Services Agreement ("Agreement") is entered into on [Date] between
**[Legal entity name] d/b/a PlAIceholder** ("Provider"), [address], and **[Client legal name]**
("Client"), [address].

## 1. Services
1.1 Provider will build, configure, test and deliver AI agents ("Agents") and provide related
services as described in one or more Statements of Work ("SOW"). Each SOW is governed by this Agreement.
1.2 Optional ongoing support ("Care Plan") is governed by the Care Plan Terms (Exhibit A).

## 2. Fees and payment
2.1 Client pays the fees in each SOW. Unless the SOW says otherwise: 50% of the launch package at
signing, 50% at handover. Care Plan fees are billed monthly in advance.
2.2 Invoices are due within [15] days. Late amounts accrue interest at the lesser of 1.5% per month or
the maximum legal rate.
2.3 **Third-party usage costs** (AI platforms such as Anthropic, OpenAI, Perplexity, xAI or Google; data
providers such as Apollo; and Client's software subscriptions) are paid by Client directly to those providers
and are not part of Provider's fees.

## 3. Ownership and license
3.1 **Provider materials.** Provider owns its pre-existing and generally applicable materials,
including agent templates, the agent kit software, prompts, scoring frameworks, documentation and know-how,
and any improvements to them ("Provider Materials").
3.2 **Client materials.** Client owns its data, its systems, the settings tuned for Client, and the outputs the
Agents produce for Client ("Client Materials").
3.3 **License to Client.** Upon payment in full of the applicable launch package, Provider grants Client a
perpetual, non-exclusive, non-transferable, non-sublicensable license to use, copy and modify the delivered
Agent (including the Provider Materials embedded in it) **solely for Client's internal business purposes**.
Client may not sell, resell, distribute, publish, or provide the Agent or Provider Materials to third parties,
or use them to offer competing services. The license survives termination of any Care Plan.
3.4 **Unpaid delivery.** If the launch package is not paid in full, no license is granted and Client must stop
using and delete the Agent within 10 days of written notice.
3.5 **Reuse.** Provider may reuse Provider Materials, including improvements made during Client's project, for
other clients, but never Client Materials or Client's Confidential Information.

## 4. Client responsibilities
Client will: (a) provide timely access, accounts and API keys it controls; (b) make a knowledgeable person
available for the discovery interview and pilot review; (c) ensure it has the right to process the data it
connects; (d) keep its keys secure and revoke Provider's access when no longer needed; (e) review Agent outputs
before acting on them.

## 5. AI outputs
5.1 Agents use third-party AI models that can produce incomplete or incorrect results. Agents are designed to
draft, score and flag, with human approval before sending communications, changing records or making payments.
5.2 Client is responsible for decisions made using Agent outputs, including decisions about customers,
vendors, payments and hiring, and for complying with laws that apply to those decisions (including any
rules on automated decision-making in employment).

## 6. Confidentiality and data
6.1 Each party will protect the other's Confidential Information with reasonable care and use it only to
perform under this Agreement.
6.2 Provider will handle Client data per Provider's Data Handling and Security Policy (Exhibit B), including
deleting Client data and Provider's copies of keys at handover, and keeping only a limited, Client-revocable
credential while a Care Plan is active.

## 7. Warranties
7.1 Provider will perform services in a professional and workmanlike manner. Each Agent is tested on sample
data and piloted on up to [20] records before full delivery; if the pilot results do not meet the acceptance
criteria in the SOW, Provider will revise the Agent or, at Client's option, end the SOW and refund the second
50% payment.
7.2 EXCEPT AS STATED IN THIS SECTION, SERVICES AND AGENTS ARE PROVIDED "AS IS". PROVIDER DOES NOT WARRANT
UNINTERRUPTED OPERATION OR ERROR-FREE AI OUTPUTS, OR THE AVAILABILITY OF THIRD-PARTY SERVICES.

## 8. Limitation of liability
Neither party is liable for indirect, incidental, special or consequential damages or lost profits. Each
party's total liability under this Agreement is limited to the fees Client paid Provider in the 12 months
before the claim. These limits do not apply to breach of confidentiality, Client's payment obligations, or
breach of Section 3.3.

## 9. Term and termination
9.1 This Agreement continues until terminated. Either party may terminate it with 30 days' written notice
when no SOW is in progress.
9.2 Either party may terminate an SOW for material breach not cured within 15 days of notice.
9.3 **Effect of termination.** Provider's access is removed; Provider deletes Client data and keys it holds;
paid-in-full licenses survive; unpaid fees become due. Sections 2, 3, 5, 6, 8, 9.3 and 10 survive.

## 10. General
Provider is an independent contractor. Neither party may assign this Agreement without consent, except to a
successor of its business. [Founding clients only: Client agrees Provider may name Client and publish the
measured pilot result and an approved testimonial.] Governing law: [State]. Venue: [County, State]. This
Agreement, its SOWs and exhibits are the entire agreement; changes must be in writing.

**Exhibit A:** Care Plan Terms (CARE_PLAN_TERMS.md) · **Exhibit B:** Data Handling and Security Policy

| Provider | Client |
|---|---|
| Name: | Name: |
| Title: | Title: |
| Signature / date: | Signature / date: |
