# Statement of Work #[N] (template)

Under the Master Services Agreement dated [Date] between [Legal entity name] d/b/a PlAIceholder and [Client legal name].

## 1. Agent
| | |
|---|---|
| Agent | [Signal Prospector / Renewal Risk Radar / Invoice Checker / custom: name] |
| Tier | [Starter / Standard / Advanced] |
| Job it does | [one sentence from the catalog, tuned to Client] |
| Client tools connected | [e.g. HubSpot, Apollo, Slack] |
| AI platform | [Claude / ChatGPT / Perplexity / Grok / Gemini / Copilot (chat mode only)] |
| Modes delivered | [Chat mode files for the AI platform above] and/or [automated runtime] |
| Records in scope | [e.g. up to 1,000 companies per month] |

## 2. Deliverables
1. Discovery interview (1 hour) and tuned settings.
2. Agent delivery package: AGENT.md, ready-to-paste files for Client's AI platform, automated runtime (if in scope), test report, changelog.
3. Pilot on up to 20 records, with results reviewed by Client.
4. Measured result: time per record before and after, and AI/data cost per record.
5. 30-minute training session and handover notes.
6. Care Plan, months 1 to 3 (included in the launch package).

## 3. Pilot acceptance criteria
The pilot is accepted when **[e.g. at least 7 of the top 10 results are judged useful by Client's reviewer, and every finding links to its source/evidence]**. If it isn't, Provider revises and re-pilots once. If the second pilot doesn't meet the criteria, Client may end this SOW and the second payment isn't owed.

## 4. Timeline (target)
| Step | Target date |
|---|---|
| Kickoff and access | [date] |
| Discovery interview | [date] |
| Pilot results | [kickoff + ~7 business days] |
| Handover and training | [kickoff + ~10 business days] |

## 5. Fees
| Item | Amount |
|---|---|
| Launch package ([tier], includes 3 months of care) | $[2,250 / 4,850 / 8,250] |
| Discounts ([founding client / second agent 25%]) | -$[ ] |
| **Total** | **$[ ]**, 50% at signing, 50% at handover |
| Care Plan from month 4 | $[250 / 450 / 750] per month, month to month, 30 days' notice |
| Estimated usage (paid by Client to providers) | ~$[ ] per [record], measured in the pilot |

## 6. Assumptions
- Client's data is reasonably clean. Cleanup is quoted separately at $125/hour.
- Client creates and controls all accounts and API keys.
- Client provides a reviewer for the pilot within 3 business days.
- Third-party tools keep providing the access used at kickoff.

## 7. Out of scope
New agent types, additional tools beyond those listed, data migration, custom dashboards beyond the agent's standard one, and changes after acceptance (covered by the Care Plan tuning hours or quoted separately).

| Provider | Client |
|---|---|
| Signature / date: | Signature / date: |
