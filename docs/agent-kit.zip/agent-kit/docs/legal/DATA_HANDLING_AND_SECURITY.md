# Data Handling and Security Policy (Exhibit B)

Version 1.0 · October 2026 · Owner: [Founder Name]

## Principles
1. **Client data stays in client systems.** Agents run in the client's accounts with the client's keys.
2. **Least access, shortest time.** We get only the access a step needs, and give it back when done.
3. **Nothing leaves the delivery that shouldn't.** Every build scans its files for secrets and refuses to deliver if it finds one.
4. **Humans approve.** Agents draft, score and flag; people send, pay and decide.

## What we access, when
| Phase | Access | Where it lives | Removed when |
|---|---|---|---|
| Build and pilot | Client-created API keys for the tools in the SOW | `clients/<client>/.env` on Provider's encrypted laptop; never in email or chat | Handover |
| Pilot data | Records pulled during the pilot (logs, results, backups) | `clients/<client>/runs/` on the same laptop | Handover (deleted) |
| Care Plan | One limited, revocable credential | Password manager / encrypted `.env` | Care Plan ends, or client revokes it |
| After the Care Plan | None | None | n/a |

## Key handling
- Keys are typed with hidden input (`kit.py set-key`); they're never pasted into chats, emails or documents.
- Keys are never committed to version control (`.gitignore` excludes every `.env`).
- Deliveries contain a `.env.example` with key **names** only. The builder scans for key **values** and stops if it finds one.
- We ask clients to create keys with the narrowest permissions the agent needs (see `docs/KEYS.md`), and to set spending limits on AI platforms.

## Devices and accounts
- Full-disk encryption, a screen lock, and automatic OS updates on every device that touches client data.
- Multi-factor authentication on email, code hosting, password manager and every provider account.
- Client folders are kept separate: one folder per client, with no shared data between clients.

## AI platforms
- The client chooses the AI platform and holds the account; data is processed under that provider's business/API terms.
- Major providers publish terms for their API and business products, including whether data is used for training. Confirm the current terms for the client's chosen provider during kickoff and record it in the SOW notes.
- Agents send the AI only the fields a task needs (for example ticket text, not payment details).

## Retention and deletion
- At handover we delete the client's `.env`, `runs/`, exports and any local copies, and confirm it in writing.
- We keep the client's settings, pinned template and delivery history (no client records or keys) so care and reactivation are fast. On request, we delete those too.

## Incidents
If we suspect a key or client data was exposed, we:
1. revoke or ask the client to rotate the affected keys immediately;
2. tell the client within 72 hours of discovery, with what happened, what was affected and what we did;
3. write a short postmortem and fix the cause.

## Review
Reviewed every 6 months, and whenever we add a new tool or AI platform.
