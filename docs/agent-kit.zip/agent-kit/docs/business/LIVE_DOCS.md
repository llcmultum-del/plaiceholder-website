# Business plan and sales playbook

These two live as editable docs (export to Word or PDF from the doc's menu):

- **PlAIceholder Business Plan**: https://claude.ai/artifact/GfBg7po2pHpuRjUF8aEQXQ
- **PlAIceholder Sales Playbook**: https://claude.ai/artifact/FHNpBbRmPTJLhL6JcS9SJx
- **Agent Catalog and Pricing Playbook** (first version, superseded by PRICE_SHEET.md for prices): https://claude.ai/code/artifact/5daeb9b6-0f01-4f5c-bcfc-6b94f0319319

The forecast in the business plan comes from `tools/forecast.py`. Change the assumptions at the top and rerun it.
