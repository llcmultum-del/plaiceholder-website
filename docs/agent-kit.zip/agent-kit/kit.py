#!/usr/bin/env python3
"""Agent Kit command line. Run `python kit.py --help`.

Common flow for a new client:
  python kit.py demo signal-prospector            # show the fake-data demo
  python kit.py new-client acme                   # make clients/acme
  python kit.py set-key acme HUBSPOT_TOKEN        # hidden typing, saved to clients/acme/.env
  python kit.py add-agent acme signal-prospector
  python kit.py check acme                        # tests every key and connection
  python kit.py run acme signal-prospector --limit 20          # dry run
  python kit.py run acme signal-prospector --limit 20 --live   # pilot, asks before each paid/writing step
  python kit.py status acme
"""
from __future__ import annotations

import argparse
import getpass
import json
import shutil
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from core.config import (CLIENTS_DIR, ConfigError, get_agent, list_agents, load_client,  # noqa: E402
                         load_yaml, save_yaml, write_env_value)
from core.connectors import KEYS, ROLES, build, build_llm  # noqa: E402
from core.pipeline import load_steps_module, run_agent  # noqa: E402
from core.runlog import Run  # noqa: E402

PLACEHOLDER_HINTS = ["Your Company", "YOUR_", "example.com", "CHANGE_ME"]


def cmd_list(a):
    print(f"{'Agent':<22} {'Tier':<9} {'Area':<28} Needs")
    for ag in list_agents():
        m = ag.manifest
        needs = ", ".join(f"{k}: {'/'.join(v)}" for k, v in (m.get("needs") or {}).items())
        print(f"{ag.name:<22} {m.get('tier', ''):<9} {m.get('area', ''):<28} {needs}")
    print("\nDetails: python kit.py info <agent>")


def cmd_info(a):
    ag = get_agent(a.agent)
    m = ag.manifest
    print(f"{m['title']}  ({m.get('tier')}, {m.get('area')})\n\n{m.get('summary', '').strip()}\n")
    for k, v in (m.get("pattern") or {}).items():
        print(f"  {k:<13} {v}")
    print("\nSteps:")
    for s in m["steps"]:
        print(f"  {s['name']:<11} [{s['kind']:<5}] {s['desc']}")


def cmd_new_client(a):
    dest = CLIENTS_DIR / a.client
    if dest.exists():
        raise ConfigError(f"clients/{a.client} already exists")
    shutil.copytree(CLIENTS_DIR / "_template", dest)
    cfg = load_yaml(dest / "client.yaml")
    cfg["client"] = a.display or a.client.replace("-", " ").title()
    save_yaml(dest / "client.yaml", cfg)
    print(f"Created clients/{a.client}. Next: edit client.yaml (connectors), then set keys and add agents.")


def cmd_set_key(a):
    c = load_client(a.client)
    if a.stdin:
        val = sys.stdin.readline().strip()
    else:
        val = getpass.getpass(f"Paste {a.key} (typing is hidden): ").strip()
    if not val:
        raise ConfigError("No value entered; nothing saved.")
    write_env_value(c.path / ".env", a.key, val)
    print(f"Saved {a.key} to clients/{a.client}/.env (ending ...{val[-4:]})")


def cmd_add_agent(a):
    c = load_client(a.client)
    ag = get_agent(a.agent)
    agents = c.config.setdefault("agents", [])
    if ag.name not in agents:
        agents.append(ag.name)
        save_yaml(c.path / "client.yaml", c.config)
    sp = c.agent_settings_path(ag)
    if not sp.exists():
        save_yaml(sp, {"# tuned settings": "only values that differ from agents/%s/settings.yaml" % ag.name})
        sp.write_text(f"# Client-specific settings for {ag.title}.\n"
                      f"# Only put values that differ from agents/{ag.name}/settings.yaml.\n"
                      f"# /agent-tune fills this in from the discovery interview.\n{{}}\n", encoding="utf-8")
    needs = ag.manifest.get("needs") or {}
    print(f"Added {ag.title} to {a.client}. It needs: " + ", ".join(f"{k} ({'/'.join(v)})" for k, v in needs.items()))


def _roles_needed(c):
    roles = set()
    for name in c.config.get("agents") or []:
        roles |= set((get_agent(name, c).manifest.get("needs") or {}).keys())
    return roles


def cmd_check(a):
    c = load_client(a.client)
    print(f"Checking {c.config.get('client')} ({c.mode} mode)")
    problems = validate_client(c)
    for p in problems:
        print(f"  ! {p}")
    ok = not problems
    for role in sorted(_roles_needed(c)):
        try:
            if role == "llm":
                msg = build_llm(c, fake_responder=lambda t: ("OK", [])).ping()
                print(f"  ok  llm: Claude replied {msg!r}")
                continue
            conn = build(c, role)
            print(f"  ok  {role}: {conn.ping()}")
            if a.send_test and role == "notify":
                conn.send("Test message from your AI agent setup.")
                print("      test message sent")
        except Exception as e:
            ok = False
            print(f"  XX  {role}: {e}")
    print("All good." if ok else "Fix the items above, then run check again.")
    return 0 if ok else 1


def validate_client(c) -> list[str]:
    probs = []
    for name in c.config.get("agents") or []:
        try:
            ag = get_agent(name, c)
        except ConfigError as e:
            probs.append(str(e))
            continue
        if not c.is_fake:
            provider = (c.config.get("llm") or {}).get("provider", "anthropic")
            from core.llm import PROVIDERS
            if provider not in PROVIDERS:
                probs.append(f"unknown AI platform '{provider}' (options: {', '.join(PROVIDERS)})")
            elif ag.manifest.get("needs_web_search") and not PROVIDERS[provider]["search"]:
                probs.append(f"{name} needs web search, which {PROVIDERS[provider]['label']} can't do here; "
                             "use anthropic, openai, perplexity or xai")
            for role, options in (ag.manifest.get("needs") or {}).items():
                kind = provider if role == "llm" else c.connector_kind(role)
                if role != "llm" and not kind:
                    probs.append(f"{name} needs a '{role}' connector in client.yaml ({'/'.join(options)})")
                    continue
                if kind not in options:
                    probs.append(f"{name} can't use '{kind}' for {role}; options: {'/'.join(options)}")
                for k in KEYS.get(kind, []):
                    if not c.secret(k, required=False):
                        probs.append(f"missing key {k} (python kit.py set-key {c.name} {k})")
        text = json.dumps(c.agent_settings(ag))
        hits = [h for h in PLACEHOLDER_HINTS if h in text]
        if hits and not c.is_fake:
            probs.append(f"{name} settings still have placeholders ({', '.join(hits)}). Run /agent-tune.")
    return sorted(set(probs))


def cmd_run(a):
    c = load_client(a.client)
    ag = get_agent(a.agent, c)
    if ag.name not in (c.config.get("agents") or []) and not c.is_fake:
        raise ConfigError(f"{ag.name} isn't added to {a.client}. Run: python kit.py add-agent {a.client} {ag.name}")
    approve = [x.strip() for x in (a.approve or "").split(",") if x.strip()]
    # --only re-runs one step on the latest run's data (e.g. rebuild the dashboard)
    resume = a.resume or bool(a.only)
    return run_agent(c, ag, live=a.live, limit=a.limit, approve=approve, yes=a.yes, resume=resume, only=a.only)


def cmd_demo(a):
    demo = CLIENTS_DIR / "demo"
    if not demo.exists():
        shutil.copytree(CLIENTS_DIR / "_template", demo)
        cfg = load_yaml(demo / "client.yaml")
        cfg.update({"client": "Demo Co (fake data)", "mode": "fake", "agents": [x.name for x in list_agents()]})
        save_yaml(demo / "client.yaml", cfg)
    cfg = load_yaml(demo / "client.yaml")
    all_agents = [x.name for x in list_agents()]
    if cfg.get("agents") != all_agents:  # new templates show up in the demo automatically
        cfg["agents"] = all_agents
        save_yaml(demo / "client.yaml", cfg)
    if a.reset:
        shutil.rmtree(demo / "runs", ignore_errors=True)
    c = load_client("demo")
    return run_agent(c, get_agent(a.agent), live=True, limit=a.limit, yes=True)


def cmd_status(a):
    c = load_client(a.client)
    names = [a.agent] if a.agent else (c.config.get("agents") or [])
    for name in names:
        ag = get_agent(name, c)
        run = Run.latest(c.runs_dir, name)
        print(f"\n{ag.title}")
        if not run:
            print("  never run")
            continue
        st = run.load_state()
        steps = [s["name"] for s in ag.manifest["steps"]]
        done = st.get("done_steps", [])
        print(f"  last run {run.id}: {len(done)}/{len(steps)} steps done")
        nxt = [s for s in steps if s not in done]
        if nxt:
            print(f"  next step: {nxt[0]}")
        if st.get("pending_approval"):
            p = st["pending_approval"]
            print(f"  WAITING FOR APPROVAL: {p['summary']}  ->  --resume --approve {p['step']}")
        if (st.get("research_batch") or {}).get("batch_id") or (st.get("assess_batch") or {}).get("batch_id"):
            print("  Claude batch still running -> rerun with --resume to collect")
        cost = sum(x.get("usd", 0) for x in st.get("costs", []))
        print(f"  est. usage cost so far: ${cost:,.2f}")
        hook = getattr(load_steps_module(ag), "status_summary", None)
        if hook:
            for line in hook(st):
                print(f"  {line}")
        dash = c.runs_dir / f"{name}-dashboard.html"
        if dash.exists():
            print(f"  dashboard: {dash}")
        fails = [json.loads(l) for l in run.log_path.read_text().splitlines()] if run.log_path.exists() else []
        fails = [f for f in fails if f["event"] == "step_failed"]
        if fails:
            print(f"  last error: {fails[-1]['error'][:300]}")


def cmd_test_prompt(a):
    c = load_client(a.client)
    ag = get_agent(a.agent, c)
    mod = load_steps_module(ag)
    if not hasattr(mod, "test_prompt"):
        raise ConfigError(f"{ag.name} has no prompt tester")
    from core.pipeline import Context
    run = Run(c.runs_dir, ag.name + "-prompt-tests")
    ctx = Context(c, ag, run, live=True, limit=1, approved={"test"}, auto_yes=True)
    ctx.llm.cfg["use_batch"] = False
    print(json.dumps(mod.test_prompt(ctx, a.record), indent=2, default=str))


def cmd_build(a):
    from core.builder import build
    plats = [p for p in (a.platforms or "").split(",") if p.strip()]
    d = build(a.client, a.agent, platforms=plats, ai=a.ai, display=a.name, note=a.note or "", force=a.force)
    return 0 if d else 1


def cmd_build_request(a):
    from core.request import build_from_request
    r = build_from_request(a.request, force=a.force)
    return {"delivered": 0, "needs_template": 5}.get(r["status"], 1)


def cmd_intake(a):
    from core.request import intake_questions
    print(intake_questions(a.agent))


def cmd_new_template(a):
    from core.request import new_template
    d = new_template(a.slug, a.base, a.title, a.area, a.tier)
    print(f"Draft template created at agents/{a.slug} (version 0.1.0, copied from {a.base}).")
    print(f"Checklist: agents/{a.slug}/TODO.md. The builder won't deliver it until version is 1.0.0.")


def cmd_clients(a):
    rows = []
    for p in sorted(CLIENTS_DIR.iterdir()):
        if not (p / "client.yaml").exists() or p.name.startswith("_") or p.name == "demo":
            continue
        cfg = load_yaml(p / "client.yaml")
        care = cfg.get("care_plan") or {}
        latest = {}
        for d in cfg.get("deliveries") or []:
            latest[d["agent"]] = d
        agents = ", ".join(f"{n} v{latest[n]['version']}" if n in latest else f"{n} (not delivered)"
                           for n in cfg.get("agents") or []) or "-"
        rows.append((p.name, cfg.get("client", ""), (cfg.get("llm") or {}).get("provider", "anthropic"),
                     care.get("status", "none"), agents))
    if not rows:
        print("No clients yet. Start one with: python kit.py build <client> <agent> --platforms ... --ai ...")
        return 0
    print(f"{'Folder':<18} {'Client':<24} {'AI':<11} {'Care plan':<10} Agents (latest delivery)")
    for r in rows:
        print(f"{r[0]:<18} {r[1][:23]:<24} {r[2]:<11} {r[3]:<10} {r[4]}")


def cmd_diff(a):
    from core.builder import diff
    print(diff(a.client, a.agent, a.a, a.b))


def cmd_upgrade(a):
    from core.builder import upgrade
    print(upgrade(a.client, a.agent, a.apply))


OFFBOARD = """Offboarding checklist (care plan ended), see docs/sop/SOP-07_OFFBOARDING.md:
  1. Confirm the end date in writing (email) and that the agent stays theirs to use under the license.
  2. Ask the client to revoke the care-plan login/key they gave you, and confirm when done.
  3. Delete every copy of their data and keys you hold: clients/{c}/.env, clients/{c}/runs/, local exports.
  4. Send the final delivery zip (latest version) and the handover notes again.
  5. Explain what is no longer covered: fixes when tools change, tuning, monitoring. Hourly and reactivation rates apply.
  6. Leave clients/{c}/ (settings, pinned template, delivery history) so a reactivation is fast."""


def cmd_care(a):
    c = load_client(a.client)
    from datetime import date
    cfg = load_yaml(c.path / "client.yaml")
    plan = cfg.get("care_plan") or {}
    if a.status:
        plan.update({"status": a.status, "since": a.since or date.today().isoformat()})
    if a.tier:
        plan["tier"] = a.tier
    if a.monthly is not None:
        plan["monthly_usd"] = a.monthly
    cfg["care_plan"] = plan
    save_yaml(c.path / "client.yaml", cfg)
    print(f"{cfg.get('client')}: care plan {plan}")
    if plan.get("status") == "ended":
        print(OFFBOARD.format(c=c.name))


def main(argv=None):
    p = argparse.ArgumentParser(description="Agent Kit: deploy preset AI agents for clients.")
    sub = p.add_subparsers(dest="cmd", required=True)
    sub.add_parser("list", help="show the agent catalog").set_defaults(fn=cmd_list)
    s = sub.add_parser("info", help="details on one agent"); s.add_argument("agent"); s.set_defaults(fn=cmd_info)
    s = sub.add_parser("new-client", help="create a client folder"); s.add_argument("client")
    s.add_argument("--display", help="client's display name"); s.set_defaults(fn=cmd_new_client)
    s = sub.add_parser("set-key", help="save a secret with hidden typing"); s.add_argument("client"); s.add_argument("key")
    s.add_argument("--stdin", action="store_true", help="read the value from stdin"); s.set_defaults(fn=cmd_set_key)
    s = sub.add_parser("add-agent", help="turn an agent on for a client"); s.add_argument("client"); s.add_argument("agent")
    s.set_defaults(fn=cmd_add_agent)
    s = sub.add_parser("check", help="test keys and connections"); s.add_argument("client")
    s.add_argument("--send-test", action="store_true", help="also send a test Slack message"); s.set_defaults(fn=cmd_check)
    s = sub.add_parser("run", help="run an agent (dry run unless --live)"); s.add_argument("client"); s.add_argument("agent")
    s.add_argument("--live", action="store_true", help="really spend and write (asks before each step)")
    s.add_argument("--limit", type=int, help="only this many records (pilot)")
    s.add_argument("--approve", help="comma list of steps approved in advance (for chat approvals)")
    s.add_argument("--yes", action="store_true", help="approve every step (use with care)")
    s.add_argument("--resume", action="store_true", help="continue the last run where it stopped")
    s.add_argument("--only", help="run just one step")
    s.set_defaults(fn=cmd_run)
    s = sub.add_parser("demo", help="run an agent on fake data"); s.add_argument("agent")
    s.add_argument("--limit", type=int); s.add_argument("--reset", action="store_true", help="start the fake world over")
    s.set_defaults(fn=cmd_demo)
    s = sub.add_parser("status", help="where each agent's last run stands"); s.add_argument("client")
    s.add_argument("agent", nargs="?"); s.set_defaults(fn=cmd_status)
    s = sub.add_parser("test-prompt", help="try the AI step on one record, live, no writes")
    s.add_argument("client"); s.add_argument("agent"); s.add_argument("record", help="domain, account id or invoice number")
    s.set_defaults(fn=cmd_test_prompt)
    s = sub.add_parser("build", help="build, test and package an agent for one client")
    s.add_argument("client", help="client folder name, e.g. acme")
    s.add_argument("agent", help="template, e.g. signal-prospector")
    s.add_argument("--platforms", help="their tools, comma list: hubspot,salesforce,apollo,zendesk,slack,quickbooks,csv")
    s.add_argument("--ai", help="their AI platform: claude, chatgpt, perplexity, grok, gemini, copilot")
    s.add_argument("--name", help="client display name (first build)")
    s.add_argument("--note", help="what changed (goes in the changelog)")
    s.add_argument("--force", action="store_true", help="deliver even if a test failed (not recommended)")
    s.set_defaults(fn=cmd_build)
    s = sub.add_parser("build-request", help="the worker: build an agent from a request file (requests/*.yaml)")
    s.add_argument("request", help="path to the request, e.g. requests/acme-signal-prospector.yaml")
    s.add_argument("--force", action="store_true", help="deliver even if a test failed (not recommended)")
    s.set_defaults(fn=cmd_build_request)
    s = sub.add_parser("intake", help="what to collect from a client for one agent"); s.add_argument("agent")
    s.set_defaults(fn=cmd_intake)
    s = sub.add_parser("new-template", help="start a custom agent template (draft) from the closest catalog one")
    s.add_argument("slug"); s.add_argument("--from", dest="base", required=True)
    s.add_argument("--title"); s.add_argument("--area"); s.add_argument("--tier", choices=["Starter", "Standard", "Advanced"])
    s.set_defaults(fn=cmd_new_template)
    sub.add_parser("clients", help="all clients, AI platform, care plan, delivered versions").set_defaults(fn=cmd_clients)
    s = sub.add_parser("diff", help="what changed between two deliveries"); s.add_argument("client"); s.add_argument("agent")
    s.add_argument("a", nargs="?"); s.add_argument("b", nargs="?"); s.set_defaults(fn=cmd_diff)
    s = sub.add_parser("upgrade", help="move ONE client to the latest template version")
    s.add_argument("client"); s.add_argument("agent"); s.add_argument("--apply", action="store_true"); s.set_defaults(fn=cmd_upgrade)
    s = sub.add_parser("care", help="record a client's care plan status (active, paused, ended)")
    s.add_argument("client"); s.add_argument("--status", choices=["active", "paused", "ended"])
    s.add_argument("--tier", choices=["starter", "standard", "advanced"]); s.add_argument("--monthly", type=int)
    s.add_argument("--since"); s.set_defaults(fn=cmd_care)
    a = p.parse_args(argv)
    try:
        return a.fn(a) or 0
    except ConfigError as e:
        print(f"Setup problem: {e}")
        return 1
    except KeyboardInterrupt:
        print("\nStopped. Run again with --resume to pick up where it left off.")
        return 130


if __name__ == "__main__":
    sys.exit(main())
