# Run: python tools/forecast.py  (edit WINS and the assumptions at the top, rerun)
# 12-month cash forecast for PlAIceholder. All assumptions explicit.
TIERS = {"starter": dict(setup=1500, care=250, f_pkg=1750, pkg=2250, hrs_setup=10, hrs_care=1.5),
         "standard": dict(setup=3500, care=450, f_pkg=3500, pkg=4850, hrs_setup=20, hrs_care=3),
         "advanced": dict(setup=6000, care=750, f_pkg=5500, pkg=8250, hrs_setup=35, hrs_care=4.5)}
MIX = {"starter": 0.4, "standard": 0.4, "advanced": 0.2}
# new client wins per month (month 1 = Nov 2026); first 5 are founding clients
WINS = [1, 1, 1, 2, 2, 2, 2, 3, 3, 3, 3, 3]
SECOND_AGENT_RATE = 0.30   # share of clients buying a 2nd agent, 4 months after first
RETAIN_AFTER_INCLUDED = 0.80  # keep paying after included months
MONTHLY_CHURN = 0.03
FIXED = {"AI subscriptions + test credits": 250, "Software (site, email, storage, password mgr)": 80,
         "Insurance (E&O + cyber), est.": 150, "Accounting/bookkeeping": 100, "Contract developer (from month 4)": 0}
ONE_TIME = {"Attorney review of MSA/SOW/care terms, est.": 1500}
months = 12
import collections
agents = []  # each: start month, tier, founding, included months
won = 0
for m, w in enumerate(WINS, 1):
    for i in range(w):
        won += 1
        # deterministic mix: cycle S,St,S,St,A
        tier = ["starter", "standard", "starter", "standard", "advanced"][(won - 1) % 5]
        agents.append(dict(start=m, tier=tier, founding=won <= 5, included=6 if won <= 5 else 3, second=False))
# second agents: every ~3rd client (30%) buys one 4 months later (standard, 25% off)
k = 0
for a in list(agents):
    if not a["second"]:
        k += 1
        if k % 10 in (3, 6, 9) and a["start"] + 4 <= months:
            agents.append(dict(start=a["start"] + 4, tier="standard", founding=False, included=3, second=True))
rows = []
cum = -sum(ONE_TIME.values())
for m in range(1, months + 1):
    setup_cash = care_cash = 0.0
    hrs = 0.0
    active_care = 0.0
    for a in agents:
        t = TIERS[a["tier"]]
        pkg = t["f_pkg"] if a["founding"] else t["pkg"]
        if a["second"]:
            pkg = t["setup"] * 0.75 + 3 * t["care"] * 0.75
        if m == a["start"]:
            setup_cash += pkg / 2; hrs += t["hrs_setup"] * 0.6
        if m == a["start"] + 1:
            setup_cash += pkg / 2; hrs += t["hrs_setup"] * 0.4
        age = m - a["start"]
        if age >= 1:
            hrs += t["hrs_care"]  # care work during included months too
        paid_from = a["included"] + 1 if not a["founding"] else 4  # founding: 3 included in pkg + 3 paid
        if age >= paid_from:
            survive = RETAIN_AFTER_INCLUDED * (1 - MONTHLY_CHURN) ** (age - paid_from)
            if a["founding"] and age < 7:
                survive = 1.0  # 6-month commitment
            fee = t["care"] * (0.75 if a["second"] else 1)
            care_cash += fee * survive
            active_care += survive
    fixed = sum(FIXED.values()) + (1000 if m >= 4 else 0)
    revenue = setup_cash + care_cash
    profit = revenue - fixed
    cum += profit
    rows.append((m, sum(1 for a in agents if a["start"] == m), round(setup_cash), round(care_cash),
                 round(revenue), round(fixed), round(profit), round(cum), round(hrs), round(active_care, 1)))
print("m,new_agents,setup_cash,care_cash,revenue,costs,profit,cumulative,hours,paying_care_plans")
for r in rows: print(",".join(map(str, r)))
tot = [sum(r[i] for r in rows) for i in (2, 3, 4, 5, 6)]
print("TOTAL setup,care,revenue,costs,profit:", tot)
print("agents sold:", len(agents), "clients:", won, "exit MRR:", rows[-1][3])
