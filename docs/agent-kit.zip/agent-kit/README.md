# Agent Kit (PlAIceholder)

Preset AI agents you can demo on fake data, connect to a client's own tools, tune with
a short interview, and prove on a 20-record pilot. One shared core; each agent is a
small template on top of it.

| Agent | Area | Tier | Connects to |
| --- | --- | --- | --- |
| **Signal Prospector** | Sales | Advanced | HubSpot or Salesforce, Apollo, Claude web search |
| **Renewal Risk Radar** | Customer success | Standard | HubSpot or Salesforce; Zendesk, HubSpot or Salesforce tickets; Slack |
| **Invoice Checker** | Back office | Standard | CSV exports or QuickBooks (beta), Slack |

Ten more agents are specced in `docs/CATALOG.md` and can be built on the same core with `/agent-new`.

## Start here (5 minutes, no accounts needed)

```
pip install -r requirements.txt
python kit.py demo signal-prospector
python kit.py demo renewal-risk
python kit.py demo invoice-checker
```
Each run prints the path to a dashboard (`clients/demo/runs/<agent>-dashboard.html`). Open it in a browser.
These are your sales demos.

## Build an agent for a client in one command

```
python kit.py build acme signal-prospector --platforms hubspot,apollo --ai chatgpt --name "Acme Corp"
```
This sets up `clients/acme`, pins a private copy of the template, runs the tests (a full sample-data run with
Acme's settings, platform fit, chat-file checks, a secrets scan), and writes a versioned delivery to
`deliveries/acme/signal-prospector/v1/` plus a zip to send:
- `AGENT.md`: the portable agent spec
- `platforms/`: ready-to-paste files for Claude, ChatGPT, Perplexity, Grok, Gemini, Copilot and the API, plus a Claude skill
- `runtime/`: automated mode on the client's AI platform
- `TEST_REPORT.md`, `CHANGELOG.md`, `MANIFEST.json`

Changes for one client: edit `clients/acme/agents/signal-prospector.yaml`, then `build ... --note "what changed"` to get v2.
`python kit.py diff acme signal-prospector` shows the change. Other clients are never touched.
See `docs/sop/` for the full procedures and `docs/README.md` for all business documents.

## Deploying for a client (in Claude Code)

Open this folder in Claude Code and type:

| Command | What happens |
| --- | --- |
| `/agent-setup acme` | Creates the client, picks agents and tools, walks through keys (hidden typing), tests every connection |
| `/agent-tune acme signal-prospector` | Claude interviews the team and writes their settings; offers a one-record prompt test |
| `/agent-run acme signal-prospector 20` | Dry run, then a 20-record pilot; asks in chat before every step that costs money or changes their systems |
| `/agent-run acme signal-prospector` | Full run |
| `/agent-status acme` | What finished, what's waiting, cost so far, where the dashboard is |
| `/agent-build signal-prospector for acme using hubspot, apollo on chatgpt` | Build, test and package in one step |
| `/agent-edit acme signal-prospector "add fintech signals"` | Change one client safely; new version |
| `/agent-new competitor-watch "..."` | Builds a new template from the catalog on the shared core |

Prefer a terminal? Everything is `python kit.py <command>`; see `python kit.py --help`.

## How every agent works

1. **Pull** data from tools the client already pays for.
2. **Think**: Claude does the research or judgment (Batch API at half price for big runs).
3. **Check**: rules catch AI mistakes. No source link, no signal. No real ticket, no reason. Rules flag invoices; Claude can't clear them.
4. **Write back** to where people work: CRM fields and notes, Slack, a CSV.
5. **Show and ask**: a one-file dashboard, plus a yes before anything is spent or written.

## Safety built in
- Dry run by default. Nothing is written or spent without a yes, one step at a time.
- Pilots with `--limit`. Spending caps (Apollo credits) in settings.
- Never deletes anything; never edits fields it didn't create. Backups of every record before it's changed.
- Waits and retries when a service says "too fast". Long Claude batches can be collected later with `--resume`.
- Keys live only in `clients/<client>/.env` and never go into chat.
- Every run keeps a log, state and backups in `clients/<client>/runs/`.

## Folder map
```
kit.py                 the command line
core/                  shared plumbing: connectors, Claude client, approvals, checks, scoring, dashboard
agents/<agent>/        agent.yaml, settings.yaml, prompts/, steps.py, interview.md, sample_data/
clients/_template/     copied for each new client
clients/<client>/      client.yaml, .env, agents/<agent>.yaml (tuned), runs/
tests/run_tests.py     end-to-end tests against a stand-in server (no accounts needed)
docs/                  SOPs, legal templates, data policy, brand guide, price sheet, keys, catalog
deliveries/<client>/   versioned deliveries (vN) and zips to send
tools/forecast.py      the business plan's revenue model
```

## What has and hasn't been tested
- **Tested:** all three agents end to end on fake data, and against a stand-in server that imitates the
  HubSpot, Salesforce, Apollo, Zendesk, Slack and Anthropic APIs (`python tests/run_tests.py`, 11 tests, including ChatGPT, Perplexity, Grok and Gemini adapters, the builder and client isolation).
  Covers dry run, chat approvals, resume, batch waiting, failed-item retry, rate-limit retry, re-runs without duplicates.
- **Not yet tested:** real accounts. Before the first client, run each agent with `--limit 5` on free trial
  accounts (HubSpot developer test account, Salesforce Developer Edition, Apollo trial, Zendesk trial, an
  Anthropic key with $5). Expect small fixes, most likely an Apollo endpoint name or a Salesforce permission.
- QuickBooks is beta (tokens expire hourly); prefer CSV exports for pilots.
