---
description: Run an agent (dry run, pilot or full) with chat approvals
argument-hint: <client> <agent> [limit]
---
Run for `$ARGUMENTS`.

1. If a limit is given, it's a pilot: add `--limit <n>`.
2. Always start with a dry run: `python kit.py run <client> <agent> [--limit n]`. Summarize what it would do.
3. Ask: "Run it for real?" On yes: `python kit.py run <client> <agent> [--limit n] --live`.
4. Whenever output contains `NEEDS APPROVAL [step]: <what> (estimated cost $X)`:
   tell the person in plain words what will happen and what it may cost, wait for yes, then
   `python kit.py run <client> <agent> --resume --approve <step>`. Repeat for each step.
   If they say "approve the rest", pass all remaining step names comma-separated.
5. Exit code 4 means Claude's batch research is still running. Say so, and offer to check back with
   `python kit.py run <client> <agent> --resume`. Do not resubmit.
6. Exit code 2: read the last `step_failed` entry in the run's `log.jsonl`, explain it plainly, and fix
   settings or keys. Only change code if it's clearly a bug, then run `python tests/run_tests.py`.
7. When done: share the dashboard path, the key numbers and the estimated cost per record.
