---
description: Set up a client and connect their tools (keys, connectors, field check)
argument-hint: <client-name> [agent]
---
Set up client `$ARGUMENTS` step by step. Explain each step in one plain sentence first.

1. Run `pip install -r requirements.txt --quiet` if `python -c "import requests, yaml, jinja2"` fails.
2. If `clients/<client>/` doesn't exist, run `python kit.py new-client <client>`.
3. Show the catalog (`python kit.py list`). If no agent was given, ask which agent(s) they want, then
   `python kit.py add-agent <client> <agent>` for each.
4. Ask which tools they use for each role the agents need (CRM: HubSpot or Salesforce; help desk:
   Zendesk, HubSpot or Salesforce; notifications: Slack; accounting: CSV export or QuickBooks).
   Edit `clients/<client>/client.yaml` `connectors:` and remove roles nobody needs. For Salesforce ask for
   the My Domain URL; for Zendesk the subdomain.
5. For each key the check reports missing, tell them where to get it (see docs/KEYS.md) and ask them to run
   `! python kit.py set-key <client> <KEY>` themselves. Never ask them to paste a key in chat.
6. Offer the fake-data demo first: `python kit.py demo <agent>` and open the dashboard it prints.
7. Run `python kit.py check <client>` until every line says ok. Placeholder warnings are expected
   until `/agent-tune`.
8. Finish with: what's connected, what's left (usually `/agent-tune <client> <agent>`, then a 20-record pilot).
