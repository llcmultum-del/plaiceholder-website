---
description: Change one client's agent safely and deliver a new version
argument-hint: <client> <agent> "<what to change>"
---
Edit request: `$ARGUMENTS`

1. Confirm the client folder exists (`python kit.py clients`). Say: "Editing <agent> for <client> only."
2. Make the change ONLY in `clients/<client>/agents/<agent>.yaml` (settings). Touch
   `clients/<client>/pinned/<agent>/` (that client's private template copy) only if a setting can't express the change.
   Never edit `agents/` (shared templates) or any other client's folder for a client request.
3. Rebuild: `python kit.py build <client> <agent> --note "<one-line description of the change>"`.
4. Show what changed: `python kit.py diff <client> <agent>`. Summarize it in plain words.
5. If the client runs the automated runtime, remind the person to send the new zip and replace the old folder
   (their `.env` stays). If they use chat mode, they replace the instructions and AGENT.md in their AI tool.
