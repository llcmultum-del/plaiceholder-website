---
description: Interview the client and write their agent settings
argument-hint: <client> <agent>
---
Tune agent for `$ARGUMENTS`.

1. Read `agents/<agent>/interview.md` and `agents/<agent>/settings.yaml`.
2. Interview the person one section at a time, in plain words, a few questions per message. Use their
   answers, not guesses; if they don't know, keep the default and note it.
3. After each section, read back what you'll save in one or two sentences.
4. Write only the values that differ from the defaults to `clients/<client>/agents/<agent>.yaml`
   (valid YAML, same structure as settings.yaml). Lists replace the default list entirely.
5. Run `python kit.py check <client>`; placeholder warnings should be gone.
6. Offer one prompt test on a record they know well:
   `python kit.py test-prompt <client> <agent> <domain | account id | invoice number>`.
   This spends a few cents of Claude usage, so ask first. Walk through what was kept and thrown out.
7. Suggest the next step: a dry run, then `/agent-run <client> <agent> 20`.
