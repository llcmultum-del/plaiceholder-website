---
description: The worker. Build an agent for a company from a request file or a plain sentence
argument-hint: <requests/file.yaml> | "<agent> for <company>, uses <tools>, on <AI platform>"
---
Build request: `$ARGUMENTS`

Follow docs/builder/BUILDER.md exactly.

1. If the argument is a file in requests/, use it. Otherwise write `requests/<folder>-<agent>.yaml` from
   requests/_TEMPLATE.yaml using what the person said (Part A). Fill in public company facts from their
   website and mark guesses `# ASSUMPTION`. Never invent tuning numbers. Show the request in five lines or
   fewer. Ask only if a required field is missing or the inputs contradict each other.
2. Run `python kit.py build-request <file>`.
   - Exit 0: delivered. Read BUILD_SUMMARY-vN.md and check it against Part E.
   - Exit 1: fix what the output names (in the request, or ask the person), then rerun.
   - Exit 5: a custom agent needs a template. Do Part C fully, including the demo and all tests, set
     version 1.0.0, then rerun the request.
3. Reply in four lines or fewer (Part F): status, zip path and the client's platform file, open questions,
   next step.

Rules from CLAUDE.md still apply: one client only, deliveries are immutable, keys never in chat, no --force.
