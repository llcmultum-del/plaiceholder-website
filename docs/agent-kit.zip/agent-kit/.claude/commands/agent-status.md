---
description: Where each agent stands for a client, what's waiting, what it cost
argument-hint: <client> [agent]
---
Run `python kit.py status $ARGUMENTS` and explain it in plain words: what finished, anything
waiting for approval or for Claude's batch, errors, cost so far, and the dashboard to open.
Suggest one next step.
