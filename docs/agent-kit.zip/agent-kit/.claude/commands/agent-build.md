---
description: Build, test and package an agent for one client in one step
argument-hint: <agent> for <client> using <platforms> on <ai platform>
---
Build request: `$ARGUMENTS`

1. Work out: agent template (see `python kit.py list`), client folder name (lowercase-with-dashes),
   their tools (hubspot, salesforce, apollo, zendesk, slack, quickbooks, csv), and their AI platform
   (claude, chatgpt, perplexity, grok, gemini, copilot). Ask one short question only if one of these is missing.
   - If the agent isn't in the catalog yet, it's a custom agent: run `/agent-new` first, then come back.
2. Say in one line: "Building <agent> for <client> only. No other client's files will change."
3. Run: `python kit.py build <client> <agent> --platforms <list> --ai <platform> [--name "<Display Name>"]`
4. Read the TEST_REPORT.md it wrote and explain the result plainly:
   - READY: send the zip.
   - READY FOR SETUP: works on sample data; list what's left (keys, `/agent-tune`).
   - BLOCKED: explain the FAIL line and fix it (usually the AI platform can't do web search for a research agent). Never use --force without the person's explicit OK.
5. Tell the person which file to send (the zip path) and which platform file the client uses first.
