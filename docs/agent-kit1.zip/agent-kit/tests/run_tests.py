#!/usr/bin/env python3
"""End-to-end tests: every template, every real connector, against the stand-in server.

    python tests/run_tests.py

No network or accounts needed. Also works under pytest if you have it.
"""
from __future__ import annotations

import csv
import io
import json
import shutil
import sys
import traceback
from contextlib import redirect_stdout
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "tests"))

import kit  # noqa: E402
import stub_server as stub  # noqa: E402
from core.checks import norm_url, verify_evidence, verify_sources  # noqa: E402
from core.config import CLIENTS_DIR, save_yaml  # noqa: E402
from core.connectors.csvfile import CsvAccounting  # noqa: E402
from core.connectors.salesforce import sf_field  # noqa: E402
from core.scoring import score_items, tier  # noqa: E402

SRV, BASE = stub.start()
MADE: list[Path] = []


def make_client(name, connectors, extra_settings=None, agents=(), secrets=None, llm=None):
    d = CLIENTS_DIR / name
    shutil.rmtree(d, ignore_errors=True)
    (d / "agents").mkdir(parents=True)
    MADE.append(d)
    cs = {"hubspot": {"base_url": BASE + "/hs"}, "apollo": {"base_url": BASE + "/apollo"},
          "zendesk": {"base_url": BASE + "/zd"},
          "salesforce": {"instance_url": BASE + "/sf", "api_version": "v62.0"}}
    cs.update(extra_settings or {})
    save_yaml(d / "client.yaml", {
        "client": name, "mode": "live", "connectors": connectors, "connector_settings": cs,
        "llm": {"base_url": BASE + "/anthropic", "poll_seconds": 0, "batch_wait_minutes": 1, **(llm or {})},
        "agents": list(agents)})
    env = {"HUBSPOT_TOKEN": "pat-test", "APOLLO_API_KEY": "ak", "ANTHROPIC_API_KEY": "sk-test",
           "OPENAI_API_KEY": "sk-openai-secret-123", "PERPLEXITY_API_KEY": "pplx-secret-123",
           "XAI_API_KEY": "xai-secret-123", "GEMINI_API_KEY": "gem-secret-123",
           "SLACK_WEBHOOK_URL": BASE + "/slack/hook", "ZENDESK_EMAIL": "a@b.example", "ZENDESK_TOKEN": "zt",
           "SALESFORCE_CLIENT_ID": "cid", "SALESFORCE_CLIENT_SECRET": "cs", **(secrets or {})}
    (d / ".env").write_text("\n".join(f"{k}={v}" for k, v in env.items()) + "\n")
    return d


def tune(client_dir, agent, settings):
    save_yaml(client_dir / "agents" / f"{agent}.yaml", settings)


def kitrun(*args):
    buf = io.StringIO()
    with redirect_stdout(buf):
        code = kit.main(list(args))
    return code, buf.getvalue()


def writes(prefix):
    return [c for c in stub.STATE["calls"] if c[0] in ("POST", "PATCH", "PUT") and c[1].startswith(prefix)
            and "/search" not in c[1] and "/batch/read" not in c[1]]


# ------------------------------------------------------------------ unit checks
def test_units():
    assert norm_url("https://www.News.example/a/") == norm_url("news.example/a")
    kept, dropped = verify_sources([{"source_url": "https://x.example/1"}, {"source_url": "https://y.example/2"}],
                                   ["http://www.x.example/1/"])
    assert len(kept) == 1 and len(dropped) == 1
    k, d = verify_evidence([{"evidence_id": "T-1"}, {"evidence_id": "T-9"}], {"T-1"})
    assert len(k) == 1 and len(d) == 1
    total, parts = score_items([{"type": "a", "date": None, "confidence": "high"},
                                {"type": "a", "date": None, "confidence": "low"},
                                {"type": "zzz"}], {"points": {"a": 20}, "confidence": {"high": 1, "low": 0.4}, "cap": 100})
    assert total == 20 and len(parts) == 1, (total, parts)  # same type counted once, unknown ignored
    assert tier(31, [{"min": 30, "label": "Hot"}, {"min": 0, "label": "Cold"}]) == "Hot"
    assert sf_field("ai_signal_score") == "AI_Signal_Score__c"
    acc = CsvAccounting({"invoices": "invoices.csv", "purchase_orders": "purchase_orders.csv"},
                        base=ROOT / "agents" / "invoice-checker" / "sample_data")
    ids = [i["id"] for i in acc.list_invoices() if i["number"] == "BPJ-3301"]
    assert ids == ["INV:BPJ-3301", "INV:BPJ-3301#2"], ids  # same number on two dates stays two invoices


# ------------------------------------------------------------------ Signal Prospector
def test_prospector_hubspot_apollo():
    stub.reset()
    c = make_client("_t_prospector", {"crm": "hubspot", "enrichment": "apollo"}, agents=["signal-prospector"])
    tune(c, "signal-prospector", {"company_profile": {"seller": "Acme Escrow"},
                                  "contacts": {"per_company": 2, "credit_cap": 5}})
    stub.seed_hubspot(companies=[{"id": "1", "name": "Target 3", "domain": "target3.example"}])

    # 1. dry run: reads only, stops before paying
    code, out = kitrun("run", "_t_prospector", "signal-prospector", "--limit", "5")
    assert code == 0 and "DRY RUN" in out and "Dry run finished" in out, out
    assert not writes("/hs") and not stub.STATE["batches"], writes("/hs")

    # 2. live, no terminal, nothing pre-approved: stops and asks
    code, out = kitrun("run", "_t_prospector", "signal-prospector", "--limit", "5", "--live")
    assert code == 3 and "NEEDS APPROVAL [fields]" in out, out

    # 3. approve the rest in one go and resume
    code, out = kitrun("run", "_t_prospector", "signal-prospector", "--resume", "--approve",
                       "fields,load,research,contacts,write")
    assert code == 0, out
    hs = stub.STATE["hs"]
    assert "ai_signal_score" in stub.STATE["hs_props"]["companies"]
    scored = [o for o in hs["companies"].values() if o["properties"].get("ai_signal_score") not in (None, "")]
    assert len(scored) == 4, (len(scored), out)  # 5 pulled; Target 3 already in CRM and not ours -> skipped
    assert hs["companies"]["1"]["properties"].get("ai_signal_score") is None  # someone else's account untouched
    for o in scored:
        assert "invented.example" not in o["properties"]["ai_signal_sources"]
        assert o["properties"]["ai_signal_types"] == "acquisition"
    assert len(hs["contacts"]) == 5, len(hs["contacts"])  # credit cap 5
    assert sum(1 for a in stub.STATE["hs_assoc"] if a[0] == "contacts") == 5
    assert len(stub.STATE["batches"]) == 1  # research used the Batch API
    assert ("POST", "/hs/crm/v3/objects/companies/search") in stub.STATE["calls"]  # survived a 429
    assert (c / "runs" / "signal-prospector-dashboard.html").exists()

    # 4. monthly re-run: our companies get rescored, nothing duplicated
    n_before = len(hs["companies"])
    code, out = kitrun("run", "_t_prospector", "signal-prospector", "--limit", "5", "--live", "--yes")
    assert code == 0, out
    assert len(hs["companies"]) == n_before and len(hs["contacts"]) == 5, out


def test_prospector_batch_pending_and_retry():
    stub.reset()
    stub.STATE["polls_needed"] = 10**6
    stub.STATE["fail_first"] = True
    c = make_client("_t_batch", {"crm": "hubspot", "enrichment": "apollo"}, agents=["signal-prospector"],
                    llm={"batch_wait_minutes": 0})
    code, out = kitrun("run", "_t_batch", "signal-prospector", "--limit", "3", "--live", "--yes")
    assert code == 4 and "still running" in out, out
    code, out = kitrun("status", "_t_batch")
    assert "batch still running" in out, out
    stub.STATE["polls_needed"] = 0
    code, out = kitrun("run", "_t_batch", "signal-prospector", "--resume", "--yes")
    assert code == 0 and "2 researched, 1 failed" in out, out
    # second run retries only the failed company
    stub.STATE["fail_first"] = False
    code, out = kitrun("run", "_t_batch", "signal-prospector", "--resume", "--yes", "--only", "research")
    assert "1 researched, 0 failed" in out, out


def test_prospector_salesforce():
    stub.reset()
    make_client("_t_prospector_sf", {"crm": "salesforce", "enrichment": "apollo"}, agents=["signal-prospector"],
                llm={"use_batch": False})
    code, out = kitrun("run", "_t_prospector_sf", "signal-prospector", "--limit", "3", "--live", "--yes")
    assert code == 0, out
    sf = stub.STATE["sf"]
    assert "AI_Signal_Score__c" in stub.STATE["sf_fields"]["Account"]
    accts = list(sf["Account"].values())
    assert len(accts) == 3 and all(a.get("AI_Signal_Tier__c") for a in accts), accts
    assert len(sf["Contact"]) == 6 and all(c.get("AccountId") for c in sf["Contact"].values())
    assert not stub.STATE["batches"]  # use_batch off -> one call per company


# ------------------------------------------------------------------ Renewal Risk
def _renewal_dates():
    from datetime import date, timedelta
    return (date.today() + timedelta(days=30)).isoformat(), (date.today() + timedelta(days=400)).isoformat()


def test_renewal_salesforce_zendesk_slack():
    stub.reset()
    soon, later = _renewal_dates()
    stub.STATE["sf_fields"]["Account"] |= {"Renewal_Date__c", "Annual_Value__c", "Account_Owner__c"}
    stub.STATE["sf"]["Account"] = {
        "001A": {"Id": "001A", "Name": "Soon Co", "Website": "https://www.soon.example", "Renewal_Date__c": soon,
                 "Annual_Value__c": 50000, "Account_Owner__c": "Maya"},
        "001B": {"Id": "001B", "Name": "Later Co", "Website": "later.example", "Renewal_Date__c": later}}
    make_client("_t_renew_sf", {"crm": "salesforce", "helpdesk": "zendesk", "notify": "slack"}, agents=["renewal-risk"])
    code, out = kitrun("check", "_t_renew_sf")
    assert "placeholders" in out  # settings not tuned yet -> warned
    code, out = kitrun("run", "_t_renew_sf", "renewal-risk", "--live", "--yes")
    assert code == 0, out
    acct = stub.STATE["sf"]["Account"]["001A"]
    assert acct.get("AI_Risk_Score__c", 0) > 0 and acct["AI_Risk_Level__c"] in ("High", "Medium", "Low"), acct
    assert "T-5001" in acct["AI_Risk_Drivers__c"] and "T-NOPE" not in acct["AI_Risk_Drivers__c"], acct
    assert "AI_Risk_Score__c" not in stub.STATE["sf"]["Account"]["001B"]  # outside the window
    assert any(t["WhatId"] == "001A" for t in stub.STATE["sf"]["Task"].values())  # note written
    if acct["AI_Risk_Level__c"] == "High":
        assert stub.STATE["slack"] and "Soon Co" in stub.STATE["slack"][-1]


def test_renewal_hubspot_tickets():
    stub.reset()
    soon, _ = _renewal_dates()
    stub.seed_hubspot(
        companies=[{"id": "10", "name": "Hub Co", "domain": "hub.example", "renewal_date": soon, "annual_value": "12000"}],
        tickets=[{"id": "900", "company": "10", "properties": {"subject": "Down", "content": "Outage",
                                                               "hs_ticket_priority": "HIGH", "createdate": "2026-10-01"}}],
        notes=[{"id": "800", "company": "10", "properties": {"hs_note_body": "Champion left", "hs_timestamp": "2026-09-01"}}])
    make_client("_t_renew_hs", {"crm": "hubspot", "helpdesk": "hubspot", "notify": "slack"}, agents=["renewal-risk"])
    code, out = kitrun("run", "_t_renew_hs", "renewal-risk", "--live", "--yes")
    assert code == 0, out
    p = stub.STATE["hs"]["companies"]["10"]["properties"]
    assert p.get("ai_risk_level") and "T-900" in p["ai_risk_drivers"], p
    assert any(a[2] == "notes" and a[1] == "10" for a in stub.STATE["hs_assoc"] if a[3] != "800")


# ------------------------------------------------------------------ Invoice Checker
def test_invoice_csv_slack():
    stub.reset()
    c = make_client("_t_invoice", {"accounting": "csv", "notify": "slack"}, agents=["invoice-checker"],
                    extra_settings={"csv": {"invoices": "data/inv.csv", "purchase_orders": "data/po.csv",
                                            "vendors": "data/vendors.csv"}})
    (c / "data").mkdir()
    sd = ROOT / "agents" / "invoice-checker" / "sample_data"
    shutil.copy(sd / "invoices.csv", c / "data" / "inv.csv")
    shutil.copy(sd / "purchase_orders.csv", c / "data" / "po.csv")
    shutil.copy(sd / "vendors.csv", c / "data" / "vendors.csv")
    code, out = kitrun("check", "_t_invoice")
    assert "ok  accounting: CSV OK" in out, out
    code, out = kitrun("run", "_t_invoice", "invoice-checker", "--live", "--yes")
    assert code == 0, out
    assert "10 exceptions on 7 invoices ($6,391.00 at risk); 5 clean" in out, out
    run_dir = sorted((c / "runs" / "invoice-checker").iterdir())[-1]
    rows = list(csv.DictReader(open(run_dir / "exceptions.csv")))
    kinds = sorted(r["type"] for r in rows)
    for k in ["duplicate", "no_po", "price_over", "qty_over", "unapproved_vendor", "vendor_mismatch", "item_not_on_po",
              "possible_duplicate"]:
        assert k in kinds, (k, kinds)
    assert all(r["ai_verdict"] == "" for r in rows if r["type"] in ("duplicate", "qty_over"))  # hard rules not sent to AI
    assert stub.STATE["slack"] and "6,391.00" in stub.STATE["slack"][-1]


# ------------------------------------------------------------------ other AI platforms
def _provider_client(name, provider, agent, connectors):
    base = {"openai": "/openai", "perplexity": "/pplx", "xai": "/xai", "gemini": "/gemini"}[provider]
    return make_client(name, connectors, agents=[agent],
                       llm={"provider": provider, "base_url": BASE + base, "use_batch": False})


def test_prospector_on_chatgpt_perplexity_grok():
    for provider in ("openai", "perplexity", "xai"):
        stub.reset()
        _provider_client(f"_t_p_{provider}", provider, "signal-prospector", {"crm": "hubspot", "enrichment": "apollo"})
        code, out = kitrun("run", f"_t_p_{provider}", "signal-prospector", "--limit", "2", "--live", "--yes")
        assert code == 0, (provider, out)
        scored = [o for o in stub.STATE["hs"]["companies"].values() if o["properties"].get("ai_signal_score")]
        assert len(scored) == 2, (provider, out)
        for o in scored:  # source check works with each platform's citation format
            assert "invented.example" not in o["properties"]["ai_signal_sources"], provider
            assert "news.example" in o["properties"]["ai_signal_sources"], provider
        calls = stub.STATE["llm_calls"]
        assert calls and all(c[1]["model"] != "claude-sonnet-5-5" for c in calls), provider
        if provider == "openai":
            assert calls[0][1]["tools"] == [{"type": "web_search"}]
        if provider == "xai":
            assert calls[0][1]["search_parameters"]["return_citations"] is True


def test_gemini_runs_renewal_but_refuses_research():
    stub.reset()
    soon, _ = _renewal_dates()
    stub.seed_hubspot(companies=[{"id": "10", "name": "Hub Co", "domain": "hub.example", "renewal_date": soon}],
                      tickets=[{"id": "900", "company": "10", "properties": {"subject": "Down", "content": "Outage",
                                                                             "hs_ticket_priority": "HIGH"}}])
    _provider_client("_t_gem", "gemini", "renewal-risk", {"crm": "hubspot", "helpdesk": "hubspot", "notify": "slack"})
    code, out = kitrun("run", "_t_gem", "renewal-risk", "--live", "--yes")
    assert code == 0 and stub.STATE["hs"]["companies"]["10"]["properties"].get("ai_risk_level"), out
    _provider_client("_t_gem2", "gemini", "signal-prospector", {"crm": "hubspot", "enrichment": "apollo"})
    code, out = kitrun("check", "_t_gem2")
    assert "needs web search" in out, out
    code, out = kitrun("run", "_t_gem2", "signal-prospector", "--limit", "2", "--live", "--yes")
    assert code == 2 and "can't search the web" in out, out


# ------------------------------------------------------------------ builder, isolation, versioning
def _cleanup_build(*names):
    from core.config import DELIVERIES_DIR
    for n in names:
        shutil.rmtree(CLIENTS_DIR / n, ignore_errors=True)
        shutil.rmtree(DELIVERIES_DIR / n, ignore_errors=True)
        MADE.append(CLIENTS_DIR / n)
        MADE.append(DELIVERIES_DIR / n)


def test_build_bundle_and_isolation():
    import json as _j
    from core.config import AGENTS_DIR, DELIVERIES_DIR
    _cleanup_build("tbuild-alpha", "tbuild-beta")
    # 1. one command builds a tested, versioned delivery
    code, out = kitrun("build", "tbuild-alpha", "signal-prospector", "--platforms", "hubspot,apollo",
                       "--ai", "chatgpt", "--name", "Alpha Inc")
    assert code == 0 and "READY FOR SETUP" in out and "End-to-end run on sample data" in out, out
    v1 = DELIVERIES_DIR / "tbuild-alpha" / "signal-prospector" / "v1"
    for f in ["AGENT.md", "README.md", "TEST_REPORT.md", "MANIFEST.json", "CHANGELOG.md", "platforms/chatgpt.md",
              "platforms/claude-project.md", "platforms/perplexity.md", "platforms/grok.md", "platforms/gemini.md",
              "platforms/copilot.md", "platforms/api-system-prompt.md", "platforms/claude-skill/SKILL.md",
              "runtime/kit.py", "runtime/agents/signal-prospector/agent.yaml",
              "runtime/clients/tbuild-alpha/client.yaml", "runtime/clients/tbuild-alpha/.env.example"]:
        assert (v1 / f).exists(), f
    assert (v1.parent / "tbuild-alpha-signal-prospector-v1.zip").exists()
    assert "OPENAI_API_KEY" in (v1 / "runtime/clients/tbuild-alpha/.env.example").read_text()
    man = _j.loads((v1 / "MANIFEST.json").read_text())
    assert man["ai_platform"] == "openai" and man["connectors"]["crm"] == "hubspot"
    assert len((v1 / "platforms/chatgpt.md").read_text()) < 8000

    # 2. a second client with the same agent, different tools and AI
    code, out = kitrun("build", "tbuild-beta", "signal-prospector", "--platforms", "salesforce,apollo", "--ai", "claude")
    assert code == 0, out
    beta_agent_before = (DELIVERIES_DIR / "tbuild-beta/signal-prospector/v1/AGENT.md").read_text()

    # 3. edit ALPHA only, rebuild -> v2 for alpha; beta untouched
    tune(CLIENTS_DIR / "tbuild-alpha", "signal-prospector",
         {"company_profile": {"seller": "Alpha Escrow", "offer": "software escrow"}})
    code, out = kitrun("build", "tbuild-alpha", "signal-prospector", "--note", "Tuned after discovery")
    assert code == 0 and "v2" in out, out
    v2 = v1.parent / "v2"
    assert "Alpha Escrow" in (v2 / "AGENT.md").read_text() and "Alpha Escrow" not in (v1 / "AGENT.md").read_text()
    assert "Tuned after discovery" in (v2 / "CHANGELOG.md").read_text()
    assert (DELIVERIES_DIR / "tbuild-beta/signal-prospector/v1/AGENT.md").read_text() == beta_agent_before
    assert not (DELIVERIES_DIR / "tbuild-beta/signal-prospector/v2").exists()
    code, out = kitrun("diff", "tbuild-alpha", "signal-prospector")
    assert "Alpha Escrow" in out, out

    # 4. a shared template change does not leak into either client until upgraded
    shared = AGENTS_DIR / "signal-prospector" / "prompts" / "research.md"
    original = shared.read_text()
    try:
        shared.write_text(original + "\nNEW TEMPLATE LINE\n")
        pinned = CLIENTS_DIR / "tbuild-beta" / "pinned" / "signal-prospector" / "prompts" / "research.md"
        assert "NEW TEMPLATE LINE" not in pinned.read_text()
        code, out = kitrun("upgrade", "tbuild-beta", "signal-prospector")
        assert "prompts/research.md" in out and "Nothing changed" in out, out
        assert "NEW TEMPLATE LINE" not in pinned.read_text()
        code, out = kitrun("upgrade", "tbuild-beta", "signal-prospector", "--apply")
        assert "Upgraded" in out and "NEW TEMPLATE LINE" in pinned.read_text()
        alpha_pinned = CLIENTS_DIR / "tbuild-alpha" / "pinned" / "signal-prospector" / "prompts" / "research.md"
        assert "NEW TEMPLATE LINE" not in alpha_pinned.read_text()  # alpha still on its own copy
    finally:
        shared.write_text(original)

    # 5. registry and care plan
    code, out = kitrun("care", "tbuild-alpha", "--status", "ended")
    assert "Offboarding checklist" in out
    code, out = kitrun("clients")
    assert "tbuild-alpha" in out and "ended" in out and "signal-prospector v2" in out, out


def test_build_blocks_bad_fit_and_never_leaks_keys():
    from core.config import DELIVERIES_DIR
    _cleanup_build("tbuild-gem", "tbuild-keys")
    code, out = kitrun("build", "tbuild-gem", "signal-prospector", "--platforms", "hubspot,apollo", "--ai", "gemini")
    assert code == 1 and "BLOCKED" in out and not (DELIVERIES_DIR / "tbuild-gem").exists(), out
    # keys present in the client's .env must never appear in a delivery
    kitrun("build", "tbuild-keys", "invoice-checker", "--platforms", "csv,slack", "--ai", "perplexity")
    env = CLIENTS_DIR / "tbuild-keys" / ".env"
    env.write_text("PERPLEXITY_API_KEY=pplx-VERY-SECRET-999\nSLACK_WEBHOOK_URL=https://hooks.example/SECRET-HOOK-777\n")
    code, out = kitrun("build", "tbuild-keys", "invoice-checker", "--note", "keys added")
    assert code == 0, out
    for p in (DELIVERIES_DIR / "tbuild-keys").rglob("*"):
        if p.is_file() and p.suffix != ".zip":
            txt = p.read_text(errors="ignore")
            assert "VERY-SECRET" not in txt and "SECRET-HOOK" not in txt, p


def main():
    tests = [(n, f) for n, f in globals().items() if n.startswith("test_") and callable(f)]
    failed = 0
    for n, f in tests:
        try:
            f()
            print(f"PASS {n}")
        except Exception:
            failed += 1
            print(f"FAIL {n}\n{traceback.format_exc()}")
    for d in MADE:
        shutil.rmtree(d, ignore_errors=True)
    print(f"\n{len(tests) - failed}/{len(tests)} passed")
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(main())
