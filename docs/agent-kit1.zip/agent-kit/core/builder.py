"""The agent builder: one command turns a catalog template into a tested, versioned
delivery for one client.

    python kit.py build acme signal-prospector --platforms hubspot,apollo --ai chatgpt --name "Acme Corp"

What it does, in order:
  1. Creates or updates clients/acme (only that folder; other clients are never touched).
  2. Maps the client's platforms to connector roles and sets the AI platform.
  3. Pins a private copy of the template to clients/acme/pinned/<agent>, so template
     changes never leak into a delivered client by accident.
  4. Runs the build tests: config checks, a full run on fake data with the client's
     own settings, portable-file checks, and a secrets scan.
  5. Writes an immutable, versioned delivery to deliveries/acme/<agent>/vN/ (plus a zip):
     AGENT.md, ready-to-paste files per AI platform, the runtime, TEST_REPORT.md,
     MANIFEST.json, CHANGELOG.md.
"""
from __future__ import annotations

import contextlib
import hashlib
import io
import json
import shutil
import zipfile
from datetime import datetime
from pathlib import Path

from .config import (AGENTS_DIR, CLIENTS_DIR, DELIVERIES_DIR, KIT_ROOT, ConfigError, get_agent, load_client,
                     load_yaml, save_yaml)
from .llm import PROVIDERS
from .portable import PLATFORMS, check, platform_file, render_agent_md, skill_file

# platform name the person types -> (role, connector)
PLATFORM_ROLES = {
    "hubspot": [("crm", "hubspot")],
    "salesforce": [("crm", "salesforce")],
    "apollo": [("enrichment", "apollo")],
    "zendesk": [("helpdesk", "zendesk")],
    "slack": [("notify", "slack")],
    "quickbooks": [("accounting", "quickbooks")],
    "csv": [("accounting", "csv")], "excel": [("accounting", "csv")], "spreadsheet": [("accounting", "csv")],
}
# AI platform name the person types -> runtime provider (None = chat files only)
AI_ALIASES = {
    "claude": "anthropic", "anthropic": "anthropic",
    "chatgpt": "openai", "openai": "openai", "gpt": "openai",
    "perplexity": "perplexity",
    "grok": "xai", "xai": "xai",
    "gemini": "gemini", "google": "gemini",
    "copilot": None,
}
PRIMARY_FILE = {"anthropic": "claude-project", "openai": "chatgpt", "perplexity": "perplexity",
                "xai": "grok", "gemini": "gemini", None: "copilot"}
IGNORE = shutil.ignore_patterns("__pycache__", "*.pyc", "runs", ".env", ".buildtest*", "deliveries")


def _out(msg, out):
    out(msg)


def _sha(p: Path) -> str:
    return hashlib.sha256(p.read_bytes()).hexdigest()[:16]


# ------------------------------------------------------------------ client setup
def prepare_client(client_name: str, agent_name: str, platforms: list[str], ai: str | None,
                   display: str | None, out=print):
    path = CLIENTS_DIR / client_name
    if not path.exists():
        shutil.copytree(CLIENTS_DIR / "_template", path)
        cfg = load_yaml(path / "client.yaml")
        cfg["client"] = display or client_name.replace("-", " ").title()
        cfg["connectors"] = {}
        cfg["agents"] = []
        save_yaml(path / "client.yaml", cfg)
        (path / "CLIENT_ID").write_text(client_name + "\n")
        out(f"  created clients/{client_name}")
    client = load_client(client_name)
    cfg = client.config
    if display:
        cfg["client"] = display
    template = get_agent(agent_name)  # shared template, to read its needs
    needs = template.manifest.get("needs") or {}

    if platforms:
        conns = cfg.setdefault("connectors", {}) or {}
        for p in platforms:
            p = p.strip().lower()
            if p not in PLATFORM_ROLES:
                raise ConfigError(f"Unknown platform '{p}'. Known: {', '.join(sorted(PLATFORM_ROLES))}")
            for role, kind in PLATFORM_ROLES[p]:
                conns[role] = kind
        # a CRM can double as the help desk when no help desk was named
        if "helpdesk" in needs and "helpdesk" not in conns and conns.get("crm") in ("hubspot", "salesforce"):
            conns["helpdesk"] = conns["crm"]
            out(f"  using {conns['crm']} tickets as the help desk")
        # invoices default to CSV exports
        if "accounting" in needs and "accounting" not in conns:
            conns["accounting"] = "csv"
        cfg["connectors"] = conns

    chat_only = False
    if ai:
        key = ai.strip().lower()
        if key not in AI_ALIASES:
            raise ConfigError(f"Unknown AI platform '{ai}'. Known: {', '.join(AI_ALIASES)}")
        provider = AI_ALIASES[key]
        llm = cfg.setdefault("llm", {}) or {}
        if provider is None:
            chat_only = True
            out("  Copilot: chat files only; the automated runtime keeps its current AI platform")
        else:
            if llm.get("provider", "anthropic") != provider:
                llm.pop("model", None)  # model names don't carry across platforms
            llm["provider"] = provider
            if provider != "anthropic":
                llm["use_batch"] = False
        cfg["llm"] = llm
    cfg["primary_chat_platform"] = PRIMARY_FILE[None if chat_only else (cfg.get("llm") or {}).get("provider", "anthropic")]

    if agent_name not in (cfg.get("agents") or []):
        cfg.setdefault("agents", []).append(agent_name)
    save_yaml(path / "client.yaml", cfg)

    pinned = path / "pinned" / agent_name
    if not pinned.exists():
        shutil.copytree(template.path, pinned, ignore=IGNORE)
        out(f"  pinned template {agent_name} v{template.manifest.get('version')} to clients/{client_name}/pinned/")
    sp = path / "agents" / f"{agent_name}.yaml"
    if not sp.exists():
        sp.parent.mkdir(parents=True, exist_ok=True)
        sp.write_text(f"# Client-specific settings for {template.title}.\n"
                      f"# Only values that differ from pinned/{agent_name}/settings.yaml.\n{{}}\n", encoding="utf-8")
    return load_client(client_name)


# ------------------------------------------------------------------ tests
def run_build_tests(client, agent, out=print) -> list[dict]:
    from kit import validate_client  # reuse the same checks as `kit.py check`
    from .pipeline import run_agent

    results = []

    def rec(name, status, detail=""):
        results.append({"check": name, "status": status, "detail": detail})
        out(f"  {status:<4} {name}{': ' + detail if detail else ''}")

    # 1. configuration
    probs = validate_client(client)
    hard = [p for p in probs if not p.startswith("missing key") and "placeholders" not in p]
    keys = [p for p in probs if p.startswith("missing key")]
    ph = [p for p in probs if "placeholders" in p]
    rec("Configuration and AI platform fit", "FAIL" if hard else "PASS", "; ".join(hard))
    rec("Client keys present", "WARN" if keys else "PASS",
        "client adds them at setup: " + ", ".join(k.split()[2] for k in keys) if keys else "")
    rec("Settings tuned (no placeholders)", "WARN" if ph else "PASS", "run /agent-tune before going live" if ph else "")

    # 2. full run on fake data with this client's settings and pinned template
    box = CLIENTS_DIR / f"_buildtest-{client.name}"
    shutil.rmtree(box, ignore_errors=True)
    try:
        shutil.copytree(client.path, box, ignore=shutil.ignore_patterns("runs", ".env", "data"))
        cfg = load_yaml(box / "client.yaml")
        cfg["mode"] = "fake"
        save_yaml(box / "client.yaml", cfg)
        boxed = load_client(box.name)
        buf = io.StringIO()
        with contextlib.redirect_stdout(buf):
            code = run_agent(boxed, get_agent(agent.name, boxed), live=True, yes=True, out=lambda m: print(m))
        dash = (box / "runs" / f"{agent.name}-dashboard.html").exists()
        ok = code == 0 and (dash or not any(s["name"] == "dashboard" for s in agent.manifest["steps"]))
        rec("End-to-end run on sample data", "PASS" if ok else "FAIL",
            "all steps completed" if ok else buf.getvalue()[-600:])
    finally:
        shutil.rmtree(box, ignore_errors=True)

    # 3. portable files
    settings = client.agent_settings(agent)
    try:
        full = render_agent_md(agent, client, settings)
        short = render_agent_md(agent, client, settings, short=True)
        pp = check(full, short)
        placeholder_only = all("Your Company" in p for p in pp)
        rec("Portable AGENT.md renders for every platform",
            "PASS" if not pp else ("WARN" if placeholder_only else "FAIL"),
            f"full {len(full):,} chars, short {len(short):,} chars" + ("; " + "; ".join(pp) if pp else ""))
    except Exception as e:
        rec("Portable AGENT.md renders for every platform", "FAIL", str(e))
    return results


def _status(results):
    if any(r["status"] == "FAIL" for r in results):
        return "BLOCKED"
    if any(r["status"] == "WARN" for r in results):
        return "READY FOR SETUP"  # works; client still adds keys and/or tuning
    return "READY"


# ------------------------------------------------------------------ bundle
def _next_version(base: Path) -> int:
    nums = [int(p.name[1:]) for p in base.glob("v*") if p.is_dir() and p.name[1:].isdigit()]
    return max(nums, default=0) + 1


def write_delivery(client, agent, results, note: str, out=print) -> Path:
    settings = client.agent_settings(agent)
    base = DELIVERIES_DIR / client.name / agent.name
    base.mkdir(parents=True, exist_ok=True)
    n = _next_version(base)
    d = base / f"v{n}"
    d.mkdir()
    full = render_agent_md(agent, client, settings)
    short = render_agent_md(agent, client, settings, short=True)
    (d / "AGENT.md").write_text(full, encoding="utf-8")
    pdir = d / "platforms"
    pdir.mkdir()
    for key, p in PLATFORMS.items():
        (pdir / p["file"]).write_text(platform_file(key, agent, full if key == "api" else short), encoding="utf-8")
    (pdir / "claude-skill").mkdir()
    (pdir / "claude-skill" / "SKILL.md").write_text(skill_file(agent, full), encoding="utf-8")

    # runtime: everything needed to run it automated, minus secrets
    rt = d / "runtime"
    shutil.copytree(KIT_ROOT / "core", rt / "core", ignore=IGNORE)
    for f in ("kit.py", "requirements.txt"):
        shutil.copy(KIT_ROOT / f, rt / f)
    if (KIT_ROOT / ".claude").exists():
        shutil.copytree(KIT_ROOT / ".claude", rt / ".claude", ignore=IGNORE)
    (rt / "docs").mkdir()
    shutil.copy(KIT_ROOT / "docs" / "KEYS.md", rt / "docs" / "KEYS.md")
    shutil.copytree(agent.path, rt / "agents" / agent.name, ignore=IGNORE)
    shutil.copytree(CLIENTS_DIR / "_template", rt / "clients" / "_template", ignore=IGNORE)
    cdir = rt / "clients" / client.name
    (cdir / "agents").mkdir(parents=True)
    cfg = dict(client.config)
    cfg.pop("deliveries", None)
    cfg.pop("care_plan", None)
    cfg["agents"] = [agent.name]
    save_yaml(cdir / "client.yaml", cfg)
    shutil.copy(client.agent_settings_path(agent), cdir / "agents" / f"{agent.name}.yaml")
    from .connectors import KEYS
    needed = sorted({k for role in (agent.manifest.get("needs") or {})
                     for k in KEYS.get((cfg.get("llm") or {}).get("provider", "anthropic") if role == "llm"
                                       else (cfg.get("connectors") or {}).get(role, ""), [])})
    (cdir / ".env.example").write_text("# Fill these with: python kit.py set-key "
                                       f"{client.name} <KEY>\n" + "".join(f"{k}=\n" for k in needed), encoding="utf-8")
    (rt / "README-RUNTIME.md").write_text(
        f"# {agent.title} runtime for {cfg.get('client')}\n\n"
        "Automated mode: runs on a schedule, reads from and writes back to your tools.\n\n"
        "```\npip install -r requirements.txt\n"
        f"python kit.py check {client.name}\n"
        f"python kit.py run {client.name} {agent.name} --limit 20          # dry run\n"
        f"python kit.py run {client.name} {agent.name} --limit 20 --live   # pilot\n```\n\n"
        "Or open this folder in Claude Code and use /agent-setup, /agent-run and /agent-status.\n"
        "Keys: see docs/KEYS.md. They go in clients/<client>/.env and are never shared.\n", encoding="utf-8")

    # reports
    status = _status(results)
    provider = (cfg.get("llm") or {}).get("provider", "anthropic")
    rows = "\n".join(f"| {r['check']} | {r['status']} | {r['detail'] or ''} |" for r in results)
    (d / "TEST_REPORT.md").write_text(
        f"# Test report: {agent.title} for {cfg.get('client')} (v{n})\n\n"
        f"**Status: {status}**\n\nBuilt {datetime.now():%Y-%m-%d %H:%M} · template v{agent.manifest.get('version')} · "
        f"AI platform for automation: {PROVIDERS[provider]['label']}\n\n"
        f"| Check | Result | Detail |\n|---|---|---|\n{rows}\n\n"
        "READY = connect and go live after a pilot. READY FOR SETUP = works on sample data; the client still adds "
        "keys and/or the tuning interview. BLOCKED = don't send.\n"
        "Sample-data tests don't prove live accounts work: always run a 20-record pilot.\n", encoding="utf-8")
    primary = PLATFORMS[cfg.get("primary_chat_platform", "claude-project")]
    (d / "README.md").write_text(
        f"# {agent.title} for {cfg.get('client')}, version {n}\n\n"
        "## Use it in chat (no setup beyond your AI tool)\n"
        f"- Your platform: **{primary['label']}**. Open `platforms/{primary['file']}` and follow the steps.\n"
        "- Other platforms: the matching file in `platforms/`. Claude skill: `platforms/claude-skill/SKILL.md`.\n"
        "- `AGENT.md` is the full spec. Attach it wherever the steps say.\n\n"
        "## Run it automatically\n- See `runtime/README-RUNTIME.md`.\n\n"
        "## What's in this folder\n- `TEST_REPORT.md`: what was tested before delivery\n"
        "- `CHANGELOG.md`: what changed in each version\n- `MANIFEST.json`: versions and file checksums\n\n"
        f"Licensed to {cfg.get('client')} for internal use only. Built by PlAIceholder.\n", encoding="utf-8")
    log = base / "CHANGELOG.md"
    entry = (f"## v{n} · {datetime.now():%Y-%m-%d}\n- {note or ('Initial delivery' if n == 1 else 'Rebuild')}\n"
             f"- Template v{agent.manifest.get('version')}, AI platform: {PROVIDERS[provider]['label']}, status: {status}\n\n")
    log.write_text(entry + (log.read_text(encoding="utf-8") if log.exists() else ""), encoding="utf-8")
    shutil.copy(log, d / "CHANGELOG.md")

    # secrets scan: no key value may appear anywhere in the delivery
    secrets = [v for v in client.secrets.values() if v and len(v) >= 8]
    leaks = [str(p.relative_to(d)) for p in d.rglob("*") if p.is_file()
             and any(s in p.read_text(encoding="utf-8", errors="ignore") for s in secrets)]
    if leaks:
        shutil.rmtree(d)
        raise ConfigError(f"Secret found in delivery files {leaks}; delivery removed.")

    files = {str(p.relative_to(d)): _sha(p) for p in sorted(d.rglob("*")) if p.is_file()}
    manifest = {"client": client.name, "client_name": cfg.get("client"), "agent": agent.name,
                "version": n, "template_version": agent.manifest.get("version"), "ai_platform": provider,
                "connectors": cfg.get("connectors"), "status": status, "built_at": datetime.now().isoformat(timespec="seconds"),
                "note": note, "files": files}
    (d / "MANIFEST.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    z = base / f"{client.name}-{agent.name}-v{n}.zip"
    with zipfile.ZipFile(z, "w", zipfile.ZIP_DEFLATED) as zf:
        for p in sorted(d.rglob("*")):
            if p.is_file():
                zf.write(p, Path(f"{client.name}-{agent.name}-v{n}") / p.relative_to(d))

    # record in the client's file
    full_cfg = load_yaml(client.path / "client.yaml")
    full_cfg.setdefault("deliveries", []).append(
        {"agent": agent.name, "version": n, "date": datetime.now().strftime("%Y-%m-%d"),
         "template_version": agent.manifest.get("version"), "ai_platform": provider, "status": status, "note": note})
    save_yaml(client.path / "client.yaml", full_cfg)
    return d


def build(client_name: str, agent_name: str, platforms=None, ai=None, display=None, note="",
          force=False, out=print) -> Path | None:
    if client_name.startswith("_"):
        raise ConfigError("Client names can't start with '_' (reserved).")
    out(f"\nBuilding {agent_name} for client '{client_name}' (only clients/{client_name} and "
        f"deliveries/{client_name} will change)")
    client = prepare_client(client_name, agent_name, platforms or [], ai, display, out)
    agent = get_agent(agent_name, client)
    out("Tests:")
    results = run_build_tests(client, agent, out)
    status = _status(results)
    if status == "BLOCKED" and not force:
        out(f"\nBLOCKED: fix the FAIL items above, then build again. Nothing was delivered.")
        return None
    d = write_delivery(client, agent, results, note, out)
    out(f"\n{status}: delivery {d.name} written to {d}")
    out(f"Send the client: {d.parent / (client.name + '-' + agent.name + '-' + d.name + '.zip')}")
    return d


# ------------------------------------------------------------------ maintenance helpers
def diff(client_name: str, agent_name: str, a: str | None = None, b: str | None = None) -> str:
    import difflib
    base = DELIVERIES_DIR / client_name / agent_name
    vs = sorted([p for p in base.glob("v*") if p.is_dir()], key=lambda p: int(p.name[1:]))
    if len(vs) < 2 and not (a and b):
        return "Only one version so far; nothing to compare."
    va = base / (a or vs[-2].name)
    vb = base / (b or vs[-1].name)
    out = []
    for rel in ["AGENT.md", f"runtime/clients/{client_name}/agents/{agent_name}.yaml",
                f"runtime/clients/{client_name}/client.yaml"]:
        x = (va / rel).read_text(encoding="utf-8").splitlines() if (va / rel).exists() else []
        y = (vb / rel).read_text(encoding="utf-8").splitlines() if (vb / rel).exists() else []
        out += list(difflib.unified_diff(x, y, f"{va.name}/{rel}", f"{vb.name}/{rel}", lineterm="", n=1))
    return "\n".join(out) or f"No differences between {va.name} and {vb.name} in spec or settings."


def upgrade(client_name: str, agent_name: str, apply: bool = False) -> str:
    import filecmp
    client = load_client(client_name)
    pinned = client.path / "pinned" / agent_name
    shared = AGENTS_DIR / agent_name
    if not pinned.exists():
        return "This client has no pinned copy yet; build it first."
    pv = load_yaml(pinned / "agent.yaml").get("version")
    sv = load_yaml(shared / "agent.yaml").get("version")
    changed = []
    for p in shared.rglob("*"):
        if p.is_file() and "__pycache__" not in p.parts:
            q = pinned / p.relative_to(shared)
            if not q.exists() or not filecmp.cmp(p, q, shallow=False):
                changed.append(str(p.relative_to(shared)))
    if not changed:
        return f"{client_name} already runs the latest {agent_name} template (v{sv})."
    msg = f"{client_name} runs {agent_name} v{pv}; latest template is v{sv}. Changed files: {', '.join(sorted(changed))}"
    if not apply:
        return msg + "\nNothing changed. Rerun with --apply to upgrade this client only, then build a new version."
    backup = client.path / "pinned" / f".backup-{agent_name}-v{pv}-{datetime.now():%Y%m%d%H%M%S}"
    shutil.copytree(pinned, backup)
    shutil.rmtree(pinned)
    shutil.copytree(shared, pinned, ignore=IGNORE)
    return msg + f"\nUpgraded. Old copy kept at {backup}. Client settings were not touched. Now run build to test and deliver."
