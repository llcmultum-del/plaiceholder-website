"""Signal Prospector steps. Each step_<name> gets the run context and returns a one-line result."""
from __future__ import annotations

import csv
import json
from datetime import date, timedelta
from pathlib import Path

from core.checks import days_ago, norm_domain, validate, verify_sources
from core.dashboard import render
from core.llm import estimate_cost
from core.scoring import score_items, tier

HERE = Path(__file__).parent

RESULT_SCHEMA = {
    "type": "object", "required": ["signals", "summary"],
    "properties": {
        "signals": {"type": "array", "items": {
            "type": "object", "required": ["type", "summary", "source_url"],
            "properties": {"type": {"type": "string"}, "summary": {"type": "string"},
                           "source_url": {"type": "string"}, "date": {"type": "string"},
                           "confidence": {"type": "string", "enum": ["high", "medium", "low"]}}}},
        "summary": {"type": "string"}, "reasoning": {"type": "string"}, "buyer_role": {"type": "string"},
    },
}


# ---------------------------------------------------------------- helpers
def _dnc(ctx) -> set:
    s = ctx.settings.get("do_not_contact") or {}
    out = {norm_domain(d) for d in s.get("domains") or []}
    if s.get("file"):
        p = ctx.client.resolve(s["file"])
        if p.exists():
            with open(p, newline="", encoding="utf-8-sig") as f:
                out |= {norm_domain(r.get("domain", "")) for r in csv.DictReader(f)}
    return out


def _companies(ctx) -> list[dict]:
    return ctx.data.setdefault("companies", [])


# ---------------------------------------------------------------- steps
def step_fields(ctx):
    fields = ctx.agent.manifest["crm_fields"]["company"]
    if not ctx.approve("fields", f"add up to {len(fields)} AI fields to CRM companies (existing fields are left alone)"):
        return "skipped (dry run)"
    created = ctx.conn("crm").ensure_fields("company", fields)
    return f"{len(created)} fields created, {len(fields) - len(created)} already there"


def step_pull(ctx):
    s = ctx.settings
    want = min(s.get("max_companies", 200), ctx.limit or 10**9)
    if s.get("source") == "list":
        p = ctx.client.resolve(s["list_file"])
        with open(p, newline="", encoding="utf-8-sig") as f:
            raw = [{"name": r.get("name") or r.get("company"), "domain": norm_domain(r.get("domain") or r.get("website", ""))}
                   for r in csv.DictReader(f)]
    else:
        # pull extra so dedupe and do-not-contact still leave enough
        raw = ctx.conn("enrichment").search_companies(s.get("apollo_filters") or {}, want * 2)
    dnc, seen, out, removed = _dnc(ctx), set(), [], {"duplicate": 0, "do_not_contact": 0, "no_domain": 0}
    for c in raw:
        d = norm_domain(c.get("domain", ""))
        if not d:
            removed["no_domain"] += 1
        elif d in seen:
            removed["duplicate"] += 1
        elif d in dnc:
            removed["do_not_contact"] += 1
        else:
            seen.add(d)
            out.append({**c, "domain": d})
    out = out[:want]
    ctx.data["companies"] = out
    ctx.run.save_json("pulled.json", out)
    return f"{len(out)} companies ready (removed: {removed})"


def step_load(ctx):
    crm = ctx.conn("crm")
    mode = ctx.settings.get("existing_companies", "rescore_ours")
    new, skipped = [], 0
    for c in _companies(ctx):
        found = crm.find_company_by_domain(c["domain"])
        if found:
            c["crm_id"] = found["id"]
            c["existing"] = True
            if mode == "skip":
                c["skip"] = True
            elif mode == "rescore_ours":
                full = crm.get_company(found["id"], ["ai_signal_score"]) or {}
                if full.get("ai_signal_score") in (None, ""):
                    c["skip"] = True  # someone else's account; leave it alone
            skipped += c.get("skip", False)
        else:
            new.append(c)
    if new and ctx.approve("load", f"create {len(new)} new companies in the CRM (name and website only)"):
        for c in new:
            c["crm_id"] = crm.create_company({"name": c["name"], "domain": c["domain"]})
        ctx.log("companies_created", count=len(new))
    ctx.save()
    return f"{len(new)} new, {sum(1 for c in _companies(ctx) if c.get('existing'))} already in CRM ({skipped} skipped as someone else's account)"


def _task(ctx, c) -> dict:
    s = ctx.settings
    p = s["company_profile"]
    sig = s["signals"]
    prompt = ctx.agent.prompt("research.md").format(
        seller=p["seller"], offer=p["offer"], ideal_customer=p["ideal_customer"],
        why_signals_matter=p.get("why_signals_matter", ""),
        company_name=c["name"], domain=c["domain"],
        lookback_days=s["research"]["lookback_days"], today=date.today().isoformat(),
        signals_block="\n".join(f"- {x['type']}: {x['look_for']}" for x in sig),
        signal_types=", ".join(x["type"] for x in sig),
    )
    return {"id": c["domain"], "prompt": prompt, "web_search": True,
            "max_searches": s["research"].get("max_searches", 5), "max_tokens": 2000}


def step_research(ctx):
    research = ctx.data.setdefault("research", {})
    todo = [c for c in _companies(ctx) if not c.get("skip") and c["domain"] not in research]
    if not todo:
        return "nothing new to research"
    batch_state = ctx.state.setdefault("research_batch", {})
    if not batch_state.get("batch_id"):
        est = len(todo) * ctx.settings["research"].get("est_cost_per_company", 0.06)
        ctx.require("research", f"research {len(todo)} companies with Claude web search", est)
    results = ctx.llm.run([_task(ctx, c) for c in todo], batch_state, ctx.log)
    ok = 0
    for tid, r in results.items():
        if r["ok"]:
            research[tid] = r
            ok += 1
    usage = [r["usage"] for r in results.values() if r["ok"]]
    ctx.add_cost("research", estimate_cost(usage, ctx.llm.cfg, ctx.llm.cfg.get("use_batch", True)),
                 f"{ok} companies")
    ctx.state["research_batch"] = {}  # next run can resubmit anything that failed
    failed = [t for t, r in results.items() if not r["ok"]]
    ctx.data["research_failed"] = failed
    ctx.save()
    return f"{ok} researched, {len(failed)} failed (rerun to retry them)"


def step_verify(ctx):
    allowed = {x["type"] for x in ctx.settings["signals"]}
    lookback = ctx.settings["research"]["lookback_days"]
    verified, audit = {}, []
    for dom, r in ctx.data.get("research", {}).items():
        j = r.get("json")
        if not isinstance(j, dict):
            audit.append({"domain": dom, "problem": "answer was not valid JSON"})
            continue
        errs = validate(j, RESULT_SCHEMA)
        if errs:
            audit.append({"domain": dom, "problem": "; ".join(errs[:3])})
            j.setdefault("signals", [])
            j["signals"] = [s for s in j.get("signals") or [] if isinstance(s, dict)]
        kept, dropped = verify_sources(j.get("signals", []), r.get("search_urls", []))
        final = []
        for s in kept:
            if s.get("type") not in allowed:
                dropped.append({**s, "_reason": "unknown signal type"})
            elif (days_ago(s.get("date")) or 0) > lookback:
                dropped.append({**s, "_reason": f"older than {lookback} days"})
            else:
                final.append(s)
        for d in dropped:
            audit.append({"domain": dom, "problem": d["_reason"], "signal": d.get("summary"), "url": d.get("source_url")})
        verified[dom] = {**j, "signals": final}
    ctx.data["verified"] = verified
    ctx.run.save_json("verify_audit.json", audit)
    n_drop = sum(1 for a in audit if "signal" in a)
    return f"{len(verified)} checked, {n_drop} signals thrown out (see verify_audit.json)"


def step_score(ctx):
    s = ctx.settings
    rules = {**s["scoring"], "points": {x["type"]: x["points"] for x in s["signals"]}}
    for c in _companies(ctx):
        v = ctx.data.get("verified", {}).get(c["domain"])
        if not v:
            continue
        total, breakdown = score_items(v["signals"], rules)
        c["score"] = total
        c["tier"] = tier(total, s["scoring"]["tiers"])
        c["breakdown"] = breakdown
        confs = [x.get("confidence", "low") for x in v["signals"]]
        c["confidence"] = "high" if "high" in confs else ("medium" if "medium" in confs else "low")
    scored = [c for c in _companies(ctx) if "score" in c]
    by = {}
    for c in scored:
        by[c["tier"]] = by.get(c["tier"], 0) + 1
    ctx.save()
    return f"{len(scored)} scored: {by}"


def step_contacts(ctx):
    cs = ctx.settings["contacts"]
    targets = sorted([c for c in _companies(ctx) if c.get("tier") in cs["for_tiers"] and not c.get("contacts")],
                     key=lambda c: -c["score"])
    if not targets:
        return "no companies need contacts"
    cap = cs["credit_cap"]
    est_credits = min(cap, len(targets) * cs["per_company"])
    ctx.require("contacts", f"find contacts at {len(targets)} companies and reveal up to {est_credits} emails "
                            f"(Apollo credits, cap {cap})")
    apollo, used = ctx.conn("enrichment"), 0
    for c in targets:
        people = apollo.search_people(c["domain"], cs["titles"], cs["per_company"])
        found = []
        for p in people:
            if used >= cap:
                break
            email = apollo.reveal_email(p)
            used += 1
            if email:
                found.append({**p, "email": email})
        c["contacts"] = found
        if used >= cap:
            ctx.log("credit_cap_reached", cap=cap)
            break
    ctx.save()
    n = sum(len(c.get("contacts", [])) for c in targets)
    return f"{n} verified contacts found, {used} credits used (cap {cap})"


def _props(ctx, c) -> dict:
    v = ctx.data["verified"][c["domain"]]
    return {
        "ai_signal_score": c["score"],
        "ai_signal_tier": c["tier"],
        "ai_signal_types": ", ".join(sorted({s["type"] for s in v["signals"]})),
        "ai_signal_summary": v.get("summary", ""),
        "ai_signal_reasoning": v.get("reasoning", ""),
        "ai_signal_sources": "\n".join(s["source_url"] for s in v["signals"]),
        "ai_signal_confidence": c.get("confidence", "low"),
        "ai_signal_checked": date.today().isoformat(),
        "ai_buyer_role": v.get("buyer_role", ""),
    }


def step_write(ctx):
    todo = [c for c in _companies(ctx) if "score" in c and c.get("crm_id") and not c.get("written")]
    if not todo:
        return "nothing to write"
    n_contacts = sum(len(c.get("contacts", [])) for c in todo)
    ctx.require("write", f"update AI fields on {len(todo)} CRM companies and add up to {n_contacts} contacts")
    crm = ctx.conn("crm")
    fields = [f["name"] for f in ctx.agent.manifest["crm_fields"]["company"]]
    ctx.run.backup("companies_before", [crm.get_company(c["crm_id"], fields) for c in todo])
    added = dup = 0
    for c in todo:
        crm.update_company(c["crm_id"], _props(ctx, c))
        for p in c.get("contacts", []):
            if crm.find_contact_by_email(p["email"]):
                dup += 1
                continue
            crm.create_contact({"first_name": p["first_name"], "last_name": p["last_name"], "email": p["email"],
                                "title": p["title"]}, c["crm_id"])
            added += 1
        c["written"] = True
        ctx.save()
    return f"{len(todo)} companies updated, {added} contacts added, {dup} already existed"


def step_dashboard(ctx):
    s = ctx.settings
    labels = {x["type"]: x["label"] for x in s["signals"]}
    rows = []
    for c in _companies(ctx):
        if "score" not in c:
            continue
        v = ctx.data["verified"][c["domain"]]
        rows.append({
            "_id": c["domain"], "name": c["name"], "domain": c["domain"], "score": c["score"], "tier": c["tier"],
            "signals": ", ".join(labels.get(x["type"], x["type"]) for x in v["signals"]) or "None found",
            "industry": c.get("industry") or "", "contacts_n": len(c.get("contacts", [])),
            "summary": v.get("summary", ""),
            "_detail": [
                {"heading": "Why now", "kind": "text", "text": v.get("summary", "")},
                {"heading": "Signals and sources", "kind": "links", "empty": "No verified signals",
                 "items": [{"text": f"{labels.get(x['type'], x['type'])}: {x['summary']}", "url": x["source_url"],
                            "note": f"{x.get('date', '')} · {x.get('confidence', '')}"} for x in v["signals"]]},
                {"heading": "Who to call", "kind": "table", "cols": ["Name", "Title", "Email"],
                 "empty": "No contacts (tier too low or credit cap reached)",
                 "rows": [[f"{p['first_name']} {p['last_name']}", p.get("title", ""), p.get("email", "")]
                          for p in c.get("contacts", [])]},
                {"heading": "Talk track", "kind": "list", "empty": "No signal-specific talk track",
                 "items": [f"{labels.get(t, t)}: {s['battlecards'][t]}" for t in
                           sorted({x['type'] for x in v['signals']}) if t in s.get("battlecards", {})]},
                {"heading": "Score breakdown", "kind": "table", "cols": ["Signal", "Points", "Base", "Multiplier"],
                 "rows": [[labels.get(b["type"], b["type"]), b["points"], b["base"], b["multiplier"]] for b in c.get("breakdown", [])]},
                {"heading": "Reasoning", "kind": "text", "text": v.get("reasoning", "")},
            ],
        })
    rows.sort(key=lambda r: -r["score"])
    hot = sum(r["tier"] == "Hot" for r in rows)
    warm = sum(r["tier"] == "Warm" for r in rows)
    cost = sum(x.get("usd", 0) for x in ctx.costs)
    data = {
        "kpis": [
            {"label": "Companies researched", "value": len(rows)},
            {"label": "Hot", "value": hot, "note": f"score {s['scoring']['tiers'][0]['min']}+"},
            {"label": "Warm", "value": warm},
            {"label": "Contacts found", "value": sum(r["contacts_n"] for r in rows)},
            {"label": "Est. usage cost", "value": f"${cost:,.2f}",
             "note": f"${cost / max(len(rows), 1):,.3f} per company"},
        ],
        "columns": [
            {"key": "name", "label": "Company"},
            {"key": "score", "label": "Score", "kind": "score"},
            {"key": "tier", "label": "Tier", "kind": "badge"},
            {"key": "signals", "label": "Signals", "hide_sm": True},
            {"key": "industry", "label": "Industry", "kind": "muted", "hide_sm": True},
            {"key": "contacts_n", "label": "Contacts", "hide_sm": True},
        ],
        "filters": [{"key": "tier", "label": "Tier", "options": ["Hot", "Warm", "Cold"]},
                    {"key": "industry", "label": "Industry", "options": sorted({r["industry"] for r in rows if r["industry"]})}],
        "badges": {"Hot": "hot", "Warm": "warm", "Cold": "cold"},
        "search_keys": ["name", "domain", "signals", "summary", "industry"],
        "sort": {"key": "score", "dir": "desc"},
        "rows": rows,
    }
    out = render(HERE, "base.html.j2", ctx.run.dir / "dashboard.html",
                 title="Who to call this week", eyebrow="Signal Prospector",
                 subtitle=f"Companies showing buying signals for {s['company_profile']['seller']}. Click a row for sources, contacts and a talk track.",
                 client=ctx.client.config.get("client", ctx.client.name), data=data)
    with open(ctx.run.dir / "results.csv", "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["company", "domain", "score", "tier", "signals", "summary", "contacts"])
        for r in rows:
            w.writerow([r["name"], r["domain"], r["score"], r["tier"], r["signals"], r["summary"], r["contacts_n"]])
    latest = ctx.client.runs_dir / f"{ctx.agent.name}-dashboard.html"
    latest.write_text(out.read_text(encoding="utf-8"), encoding="utf-8")
    return f"dashboard: {latest}"


def test_prompt(ctx, record):
    """Research one company live (by domain), show the raw answer and what the checks keep. Nothing written."""
    dom = norm_domain(record)
    c = {"name": dom.split(".")[0].replace("-", " ").title(), "domain": dom}
    r = ctx.llm.run([_task(ctx, c)], {}, ctx.log)[dom]
    j = r.get("json") if isinstance(r.get("json"), dict) else {}
    kept, dropped = verify_sources(j.get("signals", []), r.get("search_urls", []))
    rules = {**ctx.settings["scoring"], "points": {x["type"]: x["points"] for x in ctx.settings["signals"]}}
    score, _ = score_items(kept, rules)
    return {"answer": j or r.get("text"), "links_claude_saw": r.get("search_urls"), "kept": kept,
            "thrown_out": dropped, "score": score, "tier": tier(score, ctx.settings["scoring"]["tiers"]),
            "error": r.get("error")}


def status_summary(state):
    comps = (state.get("data") or {}).get("companies", [])
    tiers = {}
    for c in comps:
        if "tier" in c:
            tiers[c["tier"]] = tiers.get(c["tier"], 0) + 1
    hot = sorted([c for c in comps if c.get("tier") == "Hot"], key=lambda c: -c["score"])[:5]
    out = [f"tiers: {tiers}"] if tiers else []
    if hot:
        out.append("hottest: " + ", ".join(f"{c['name']} ({c['score']})" for c in hot))
    failed = (state.get("data") or {}).get("research_failed") or []
    if failed:
        out.append(f"{len(failed)} companies failed research; rerun with --resume --only research to retry")
    return out


# ---------------------------------------------------------------- demo mode
def fake_responder(task: dict):
    """Pretend to be Claude with web search, using sample_data/news.json.
    One made-up link is slipped in so the demo shows the source check catching it."""
    news = json.loads((HERE / "sample_data" / "news.json").read_text(encoding="utf-8"))
    dom = task["id"]
    items = news.get(dom, [])
    today = date.today()
    signals = [{"type": n["type"], "summary": n["summary"], "source_url": n["url"],
                "date": (today - timedelta(days=n["days_ago"])).isoformat(), "confidence": n["confidence"]}
               for n in items]
    urls = [n["url"] for n in items] + [f"https://directory.example/{dom}"]
    if dom == "ironleaf-mfg.example":  # a hallucinated signal the check should remove
        signals.append({"type": "funding", "summary": "Raised $25M from a growth fund.",
                        "source_url": "https://made-up.example/ironleaf-funding",
                        "date": (today - timedelta(days=5)).isoformat(), "confidence": "high"})
    name = dom.split(".")[0].replace("-", " ").title()
    if signals:
        kinds = ", ".join(sorted({s["type"].replace("_", " ") for s in signals}))
        summary = f"{name} shows {kinds} in recent news. Timing is good for an outreach while priorities are being reset."
        reasoning = "Recent, well-sourced change events usually mean new budget owners and a short window to get in."
    else:
        summary = f"No buying signals found for {name} in the lookback window."
        reasoning = "Nothing recent suggests change; keep on a quarterly re-check."
    out = {"company": name, "signals": signals, "summary": summary, "reasoning": reasoning,
           "buyer_role": "Chief Operating Officer"}
    return "```json\n" + json.dumps(out, indent=1) + "\n```", urls
