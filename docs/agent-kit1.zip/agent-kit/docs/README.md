# PlAIceholder documentation

| Area | Document | What it's for |
|---|---|---|
| Business | [Business plan and sales playbook](business/LIVE_DOCS.md) | Model, market, forecast; how to sell (live docs) |
| Business | [Price sheet](business/PRICE_SHEET.md) | The one source of truth for prices and terms |
| Business | [Brand guide](business/BRAND_GUIDE.md) | Name, voice, colors, type, logo, naming |
| Business | [Catalog](CATALOG.md) | All 13 agents and build notes |
| Legal (templates; attorney review first) | [Master Services Agreement](legal/MASTER_SERVICES_AGREEMENT.md) | License, payment, AI outputs, liability |
| | [Statement of Work](legal/STATEMENT_OF_WORK.md) | Per-agent scope, pilot acceptance, fees |
| | [Care Plan Terms](legal/CARE_PLAN_TERMS.md) | What the monthly plan covers; lapse and reactivation |
| | [Data Handling and Security](legal/DATA_HANDLING_AND_SECURITY.md) | Keys, access, deletion, incidents |
| SOPs | [01 Client onboarding](sop/SOP-01_CLIENT_ONBOARDING.md) | Signed to ready-to-build |
| | [02 Building an agent](sop/SOP-02_BUILDING_AN_AGENT.md) | One builder, catalog and custom agents |
| | [03 AI platform portability](sop/SOP-03_AI_PLATFORM_PORTABILITY.md) | Claude, ChatGPT, Perplexity, Grok, Gemini, Copilot |
| | [04 Testing and QA](sop/SOP-04_TESTING_AND_QA.md) | Kit tests, build tests, live trials, pilots |
| | [05 Delivery and handover](sop/SOP-05_DELIVERY_AND_HANDOVER.md) | Sending the agent; why we can hand it over |
| | [06 Maintenance and changes](sop/SOP-06_MAINTENANCE_AND_CHANGES.md) | Client isolation, versions, upgrades |
| | [07 Offboarding](sop/SOP-07_OFFBOARDING.md) | Cancellation, non-payment, reactivation |
| Setup | [Keys](KEYS.md) | Where to get every key |
