---
description: Build a new preset agent from the catalog on the shared core
argument-hint: <agent-name> "<what it does>"
---
Build a new agent template: `$ARGUMENTS`.

1. Ask (briefly) for: the job it does, which tools it reads from and writes to, what a person must approve,
   and what "a wrong answer" would look like. Fill gaps from the catalog in docs/CATALOG.md.
2. Pick the closest existing template in `agents/` and copy its structure:
   `agent.yaml` (steps with kinds read/local/spend/write, crm_fields), `settings.yaml` (generic defaults),
   `prompts/*.md`, `steps.py`, `interview.md`, `sample_data/world.json`.
3. Use only `core` connectors (`ctx.conn("crm")`, etc.) and `ctx.llm`. If a new tool is needed, add a connector
   in `core/connectors/` following the base classes, plus stub routes in `tests/stub_server.py`.
4. Keep the safety pattern: rules first; Claude's output validated and tied to real evidence; `ctx.require()`
   before every paid or writing step; backups before writes.
5. Add a `fake_responder` and sample data so `python kit.py demo <agent>` works without accounts.
   Add `portable.md.j2` (copy the structure of an existing one: Your role, What you work on, Procedure,
   Rules you must follow, Scoring, Output format, Stop and ask) so chat-mode files can be generated.
   Set `version: 1.0.0` and `needs_web_search` in agent.yaml.
6. For a one-off custom agent, still build it as a template, then deliver with `/agent-build`.
7. Add an end-to-end test in `tests/run_tests.py`; run all tests; run the demo and look at the dashboard.
